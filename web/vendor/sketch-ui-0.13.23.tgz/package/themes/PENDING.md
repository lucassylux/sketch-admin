# 主题待实现清单（PENDING）

设计稿 → 主题映射（8 套，组件库统一 61 个 Sk* 组件，主题差异全部在 token + 皮肤层）：

| 设计稿 | 主题 | 明暗 | 独有元素 |
|---|---|---|---|
| 1.html | sketch 线框纸 | 浅 | 手绘抖动边、硬投影、斜纹填充、格纸 |
| 2.html | marker 记号纸 | 浅 | 黄记号高亮、灰格纸、等宽数字列（已做） |
| 3.html | highlight 荧光纸 | 浅 | 荧光黄选中、全框线表格、双字体（已做） |
| 4.html | bold 粗线纸 | 浅 | 2px 粗边、反白按钮、大写页头（已做） |
| 5.html | night 暗夜紫 | 深 | 柔和深投影、紫/青图表色、卡片紫晕高光（已做） |
| 6.html | atelier 暖木坊 | 浅 | 暖木色板、深咖啡侧栏（已做） |
| 7.html | lumina 鎏金夜 | 深 | 金底黑字按钮、大写表头、玻璃拟态浮层（已做） |
| 8.html | indigo 靛蓝云 | 浅 | 极轻投影、深导航侧栏（已做） |

组件覆盖审计结论（2026-09-21，逐 class 比对 1~8.html）：8 个设计稿的功能性组件
**已全部在库内**。btn-ghost（4.html）≈ SkButton default 变体；chrome-dot / status-bar /
logo-box 属于线框稿的窗口装饰，非组件，不做。

## 已完成（0.5.0，2026-09-21 第二轮）

- [x] F 暗色质检：night/lumina 全组件全页截图审计，零对比度问题
- [x] B1 marker 激活页签黄色下划记号条；B2 表格外框 1.5px + 硬投影 + 全框线 + 表头底 + 数字等宽
- [x] B3 highlight 双字体（徽章/标签/键名/表头等宽）；B4 logo 盒（--sk-sidebar-logo-border）
- [x] B5 bold 大写页头 + 2.5px 底线；B6 用户区圆头像（--sk-sidebar-avatar-radius）
- [x] D1 深色侧栏专项：8 主题统一 --sk-sidebar-* token，MainLayout / demo 导航已消费
- [x] D2 lumina 玻璃拟态浮层（blur 16 + 半透明深底）；D3 金色左竖线激活导航
- [x] D4 night 卡片顶部紫晕高光；D5 .sk-live-dot / .sk-trend 工具类
- [x] A1 SkDateRange 日期范围选择器（预设 + 双月历 + 自动向上翻转）
- [x] A2 图表 hover tooltip：SkChart（柱）/ SkChartLine（参考线 + 数值气泡）/ SkChartDonut（分段联动）
- [x] A3 SkTable mono 列（等宽 + 表格数字，2.html td-mono）
- [x] E demo 补 SkCheckbox / SkRadioGroup / SkTextarea / SkDateRange / live-dot / trend / mono 列演示
- [x] 修复：0.4.0 图表色板注入时误删 4 个旧主题 --sk-focus-outline 定义（已按 git 原值恢复）

## 待补（下轮）

### 已补（0.6.0）

- [x] SkSidebar / SkSidebarGroup / SkSidebarItem 侧边栏组件族（此前侧栏为应用层手写单一实现）：
      品牌区 + 分组 + 导航项（图标/徽标计数/纸系对勾）+ 底部用户区 + 折叠窄栏；
      docgoose MainLayout 已接入，视觉走 8 主题 --sk-sidebar-* token

### 组件能力缺口（按需排期）

- [ ] 雷达图 Radar（8.html bundle 含 recharts Radar，业务暂未用到）
- [ ] 批量选择工具条（8.html OrdersTable "Bulk Action (n)" 选中态工具条）
- [ ] SkChartLine tooltip 极值边缘的窄屏溢出微调（现为固定 158px 翻转，够用）

### C 组：新组件在旧纸系主题下的手绘风调优（token 兜底可用，属还原度精修）

- [ ] SkChartLine：旧主题面积填充未接 --sk-fill-pattern 斜纹/网点
- [ ] SkChartDonut：旧主题分段描边无手绘感
- [ ] SkProgressRing：旧主题环底可用纹理填充
- [ ] SkRating：sketch 主题可换手绘五角星路径
- [ ] SkFab：旧主题形状可再方正
- [ ] SkSwatch：旧主题色块可加 1.5px 墨线描边
- [ ] SkChatPanel：旧主题气泡可用虚线描边
- [ ] SkDateRange：纸系主题面板可用虚线边 + 手绘月历格（现通用 token 风格）

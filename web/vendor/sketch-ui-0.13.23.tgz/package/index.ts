/**
 * sketch 组件库入口。
 * - install：全局注册全部组件与图标（模板直接使用，无需 import）
 * - 命令式 API：skMessage / skDialog
 * - 主题工具：useSkTheme / SK_THEMES
 * 样式只引用 token（themes/*.css 定义），新增主题只加 token 文件 + theme.ts 注册。
 */
import type { Component, Plugin } from 'vue'
import './styles/base.css'
import './themes/sketch.css'
import './themes/marker.css'
import './themes/highlight.css'
import './themes/bold.css'
import './themes/night.css'
import './themes/atelier.css'
import './themes/lumina.css'
import './themes/indigo.css'

import SkButton from './components/SkButton.vue'
import SkInput from './components/SkInput.vue'
import SkTextarea from './components/SkTextarea.vue'
import SkSelect from './components/SkSelect.vue'
import SkCheckbox from './components/SkCheckbox.vue'
import SkRadioGroup from './components/SkRadioGroup.vue'
import SkDivider from './components/SkDivider.vue'
import SkTag from './components/SkTag.vue'
import SkLink from './components/SkLink.vue'
import SkCard from './components/SkCard.vue'
import SkStatCard from './components/SkStatCard.vue'
import SkSectionLabel from './components/SkSectionLabel.vue'
import SkAnnotation from './components/SkAnnotation.vue'
import SkNote from './components/SkNote.vue'
import SkTable from './components/SkTable.vue'
import SkPagination from './components/SkPagination.vue'
import SkEmpty from './components/SkEmpty.vue'
import SkSpin from './components/SkSpin.vue'
import SkAvatar from './components/SkAvatar.vue'
import SkTabs from './components/SkTabs.vue'
import SkProgress from './components/SkProgress.vue'
import SkTimeline from './components/SkTimeline.vue'
import SkSteps from './components/SkSteps.vue'
import SkPageHeader from './components/SkPageHeader.vue'
import SkModal from './components/SkModal.vue'
import SkDrawer from './components/SkDrawer.vue'
import SkDropdown from './components/SkDropdown.vue'
import SkPopconfirm from './components/SkPopconfirm.vue'
import SkContextMenu from './components/SkContextMenu.vue'
import SkForm from './components/SkForm.vue'
import SkSearchForm from './components/SkSearchForm.vue'
import SkFormField from './components/SkFormField.vue'
import SkTree from './components/SkTree.vue'
import SkDescriptions from './components/SkDescriptions.vue'
import SkDescriptionsItem from './components/SkDescriptionsItem.vue'
import SkFilterBar from './components/SkFilterBar.vue'
import SkUpload from './components/SkUpload.vue'
import SkThumb from './components/SkThumb.vue'
import SkDetailList from './components/SkDetailList.vue'
import SkBadge from './components/SkBadge.vue'
import SkPlaceholder from './components/SkPlaceholder.vue'
import SkSwitch from './components/SkSwitch.vue'
import SkStatusSwitch from './components/SkStatusSwitch.vue'
import SkChip from './components/SkChip.vue'
import SkAlert from './components/SkAlert.vue'
import SkPriorityDot from './components/SkPriorityDot.vue'
import SkNavBadge from './components/SkNavBadge.vue'
import SkSkeleton from './components/SkSkeleton.vue'
import SkChart from './components/SkChart.vue'
import SkComment from './components/SkComment.vue'
import SkMemberChip from './components/SkMemberChip.vue'
import SkMemberCard from './components/SkMemberCard.vue'
import SkTaskItem from './components/SkTaskItem.vue'
import SkSettingsRow from './components/SkSettingsRow.vue'
import SkChatBubble from './components/SkChatBubble.vue'
import SkChannelList from './components/SkChannelList.vue'
import SkKanban from './components/SkKanban.vue'
import SkCalendar from './components/SkCalendar.vue'
import SkChartLine from './components/SkChartLine.vue'
import SkChartDonut from './components/SkChartDonut.vue'
import SkProgressRing from './components/SkProgressRing.vue'
import SkRating from './components/SkRating.vue'
import SkFab from './components/SkFab.vue'
import SkSwatch from './components/SkSwatch.vue'
import SkChatPanel from './components/SkChatPanel.vue'
import SkDateRange from './components/SkDateRange.vue'
import SkSidebar from './components/SkSidebar.vue'
import SkInputNumber from './components/SkInputNumber.vue'
import SkCollapse from './components/SkCollapse.vue'
import SkBreadcrumb from './components/SkBreadcrumb.vue'
import SkTooltip from './components/SkTooltip.vue'
import SkTabPane from './components/SkTabPane.vue'
import SkCollapsePanel from './components/SkCollapsePanel.vue'
import SkThemeSwitch from './components/SkThemeSwitch.vue'
import SkSidebarGroup from './components/SkSidebarGroup.vue'
import SkSidebarItem from './components/SkSidebarItem.vue'
import * as icons from './icons'

export { useSkTheme, setDefaultTheme, SK_THEMES } from './theme'
export type { SkThemeDef } from './theme'
export { skMessage } from './feedback/message'
export { skDialog } from './feedback/dialog'
export type { SkConfirmOptions, SkPromptOptions, SkSelectDialogOptions } from './feedback/dialog'
export type { SkDropdownItem } from './components/SkDropdown.vue'
export type { SkTimelineItem } from './components/SkTimeline.vue'
export type { SkTableColumn } from './components/SkTable.vue'
export type { SkTreeNode } from './components/SkTree.vue'

const components: Record<string, Component> = {
  SkButton,
  SkInput,
  SkTextarea,
  SkSelect,
  SkCheckbox,
  SkRadioGroup,
  SkDivider,
  SkTag,
  SkLink,
  SkCard,
  SkStatCard,
  SkSectionLabel,
  SkAnnotation,
  SkNote,
  SkTable,
  SkPagination,
  SkEmpty,
  SkSpin,
  SkAvatar,
  SkTabs,
  SkProgress,
  SkTimeline,
  SkSteps,
  SkPageHeader,
  SkModal,
  SkDrawer,
  SkDropdown,
  SkPopconfirm,
  SkContextMenu,
  SkForm,
  SkSearchForm,
  SkFormField,
  SkTree,
  SkDescriptions,
  SkDescriptionsItem,
  SkFilterBar,
  SkUpload,
  SkThumb,
  SkDetailList,
  SkBadge,
  SkPlaceholder,
  SkSwitch,
  SkStatusSwitch,
  SkChip,
  SkAlert,
  SkPriorityDot,
  SkNavBadge,
  SkSkeleton,
  SkChart,
  SkComment,
  SkMemberChip,
  SkMemberCard,
  SkTaskItem,
  SkSettingsRow,
  SkChatBubble,
  SkChannelList,
  SkKanban,
  SkCalendar,
  SkChartLine,
  SkChartDonut,
  SkProgressRing,
  SkRating,
  SkFab,
  SkSwatch,
  SkChatPanel,
  SkDateRange,
  SkSidebar,
  SkInputNumber,
  SkCollapse,
  SkBreadcrumb,
  SkTooltip,
  SkTabPane,
  SkCollapsePanel,
  SkThemeSwitch,
  SkSidebarGroup,
  SkSidebarItem,
  // 图标全量注册为全局组件；getIcon 是按名解析的工具函数而非组件，剔出注册表
  ...Object.fromEntries(Object.entries(icons).filter(([, c]) => (c as { displayName?: unknown }).displayName != null)),
}

const sketchUI: Plugin = {
  install(app) {
    for (const [name, comp] of Object.entries(components)) {
      app.component(name, comp)
    }
  },
}

export default sketchUI

# sketch-ui（@xzsoft/sketch-ui）

手绘线框纸风的 Vue 3 组件库。源自 docgoose 前端换装，抽为独立库供内部项目复用。

## 特性

- **token 主题架构**：组件视觉只消费 `var(--sk-*)`，主题 = 一份 CSS 变量赋值文件。
  内置四套：`sketch` 线框纸 / `marker` 记号纸 / `highlight` 荧光纸 / `bold` 粗线纸，
  新增主题只加 `themes/<name>.css` + `theme.ts` 注册一行，不改组件。
- **36+ 组件**：基础控件、表格/分页/弹层/右键菜单、时间线/步骤/看板/日历/图表等
  （完整清单与演示见 docgoose 的 `/components` 组件总览页）。
- **命令式 API**：`skMessage`（含 loading）、`skDialog`（confirm/prompt/select）。
- **源码形态发布**（不做构建）：消费方 Vite 直接编译 `.vue`，无构建流水线负担。

## 文档

- [docs/开发约定.md](docs/开发约定.md)——承重样式清单、整数像素高度约定、SkTree/SkTable 契约、发布流程。改组件前必读。

## 使用

```ts
// main.ts
import { createApp } from 'vue'
import sketchUI from '@xzsoft/sketch-ui'
import '@xzsoft/sketch-ui/index.css'   // 无需：样式随组件注入（见下方说明）

const app = createApp(App)
app.use(sketchUI)   // 全局注册全部组件与图标
```

样式入口随 `@xzsoft/sketch-ui` 的 JS import 自动注入（base.css + 全部主题 css），
无需单独引样式文件。主题切换：

```ts
import { useSkTheme } from '@xzsoft/sketch-ui'
const { theme, setTheme } = useSkTheme()
setTheme('marker')
```

消费方需在 `vite.config.ts` 排除预打包（源码形态包的标准处理）：

```ts
optimizeDeps: { exclude: ['@xzsoft/sketch-ui'] }
```

模板全局组件类型：把包内 `global.d.ts` 的声明复制或引用到应用（见文件头注释）。

## 目录

```
components/   36 个 Sk* 组件（.vue，样式内联非 scoped、sk- 前缀）
icons/        39 个手写 SVG 线性图标（函数式组件）
themes/       主题 token 文件 + PENDING.md 待实现清单
feedback/     skMessage / skDialog 命令式 API
styles/       base.css（reset + 全局工具类 + 内容宽度唯一设置点）
theme.ts      主题注册表与切换（html[data-theme] 单一事实源）
```

## 版本纪律

- token 契约新增（向后兼容）→ minor
- 契约变更 / 组件 API 破坏性调整 → major
- 当前 0.x：随时可能有调整，消费方钉死精确版本

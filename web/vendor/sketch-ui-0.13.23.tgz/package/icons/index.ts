/**
 * 手写 SVG 线性图标集：viewBox 24 / stroke 2 / currentColor，尺寸跟随字号（1em）。
 * 全部为函数式组件，可全局注册也可按需 import。
 */
import { h, type FunctionalComponent } from 'vue'

const SVG_BASE = {
  class: 'sk-icon',
  viewBox: '0 0 24 24',
  fill: 'none',
  stroke: 'currentColor',
  'stroke-width': 2,
  'stroke-linecap': 'round',
  'stroke-linejoin': 'round',
  'aria-hidden': 'true',
} as const

/** 名称注册表：key = 组件名（与导出名/displayName 一致），icon() 工厂自动登记，新增图标无需两处维护 */
const REGISTRY: Record<string, FunctionalComponent> = {}

function icon(displayName: string, children: () => ReturnType<typeof h>[], extra?: Record<string, unknown>) {
  const c: FunctionalComponent = () => h('svg', { ...SVG_BASE, ...extra }, children())
  c.displayName = displayName
  REGISTRY[displayName] = c
  return c
}
const p = (d: string) => h('path', { d })
const dot = (cx: number, cy: number, r = 1.1) => h('circle', { cx, cy, r, fill: 'currentColor', stroke: 'none' })

/**
 * 按组件名取图标：未配置、下架或存量数据里的失效 key 一律返回兜底图标（默认 SkIconFileText），
 * 恒返回可用组件——消费方不再各自 ?? 兜底。兜底由本库统一承诺。
 */
export function getIcon(name?: string, fallback: FunctionalComponent = SkIconFileText): FunctionalComponent {
  return (name ? REGISTRY[name] : undefined) ?? fallback
}

/* ── 方向 / 通用 ── */
export const SkIconArrowLeft = icon('SkIconArrowLeft', () => [p('M19 12H5'), p('M12 19l-7-7 7-7')])
export const SkIconArrowRight = icon('SkIconArrowRight', () => [p('M5 12h14'), p('M12 5l7 7-7 7')])
export const SkIconChevronDown = icon('SkIconChevronDown', () => [p('M6 9l6 6 6-6')])
export const SkIconChevronLeft = icon('SkIconChevronLeft', () => [p('M15 18l-6-6 6-6')])

export const SkIconChevronRight = icon('SkIconChevronRight', () => [p('M9 18l6-6-6-6')])
/* 侧栏面板收起/展开（面板轮廓 + 分隔线 + 指示箭头） */
export const SkIconPanelClose = icon('SkIconPanelClose', () => [
  h('rect', { x: 3, y: 3, width: 18, height: 18, rx: 2 }),
  p('M9 3v18'),
  p('M16 15l-3-3 3-3'),
])
export const SkIconPanelOpen = icon('SkIconPanelOpen', () => [
  h('rect', { x: 3, y: 3, width: 18, height: 18, rx: 2 }),
  p('M9 3v18'),
  p('M14 9l3 3-3 3'),
])

export const SkIconCheck = icon('SkIconCheck', () => [p('M20 6L9 17l-5-5')])
export const SkIconClose = icon('SkIconClose', () => [p('M18 6L6 18'), p('M6 6l12 12')])
export const SkIconPlus = icon('SkIconPlus', () => [p('M12 5v14'), p('M5 12h14')])
export const SkIconMore = icon('SkIconMore', () => [dot(5, 12), dot(12, 12), dot(19, 12)])
export const SkIconSearch = icon('SkIconSearch', () => [h('circle', { cx: 11, cy: 11, r: 7 }), p('M21 21l-4.35-4.35')])
export const SkIconInfo = icon('SkIconInfo', () => [h('circle', { cx: 12, cy: 12, r: 9 }), p('M12 8v.5'), p('M12 11.5V16')])
export const SkIconAlert = icon('SkIconAlert', () => [p('M10.3 3.9L1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z'), p('M12 9v4'), p('M12 17v.5')])
export const SkIconCheckCircle = icon('SkIconCheckCircle', () => [p('M22 11.1V12a10 10 0 1 1-5.9-9.1'), p('M22 4L12 14l-3-3')])

/* ── 导航 / 布局 ── */
export const SkIconHome = icon('SkIconHome', () => [p('M3 10.5L12 3l9 7.5'), p('M5 9.5V21h14V9.5'), p('M10 21v-6h4v6')])
export const SkIconMenu = icon('SkIconMenu', () => [p('M4 6h16'), p('M4 12h16'), p('M4 18h16')])

/* ── 文件与文件夹 ── */
const FILE_OUTLINE = [p('M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z'), p('M14 2v6h6')]
export const SkIconFile = icon('SkIconFile', () => FILE_OUTLINE)
export const SkIconFileText = icon('SkIconFileText', () => [...FILE_OUTLINE, p('M9 13h6'), p('M9 17h6')])
export const SkIconFileZip = icon('SkIconFileZip', () => [...FILE_OUTLINE, p('M12 9v1.5'), p('M12 12.5V14'), p('M12 16v1.5')])
export const SkIconFolder = icon('SkIconFolder', () => [p('M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z')])
export const SkIconFolderOpen = icon('SkIconFolderOpen', () => [p('M3 7a2 2 0 0 1 2-2h4l2 2h6'), p('M3 7l1.8 12.2A2 2 0 0 0 6.8 21H19a2 2 0 0 0 2-1.6L22.5 9H11l-2-2z')])
export const SkIconFolderPlus = icon('SkIconFolderPlus', () => [p('M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z'), p('M12 11v6'), p('M9 14h6')])

/* ── 操作 ── */
export const SkIconUpload = icon('SkIconUpload', () => [p('M12 16V4'), p('M6 10l6-6 6 6'), p('M4 20h16')])
export const SkIconDownload = icon('SkIconDownload', () => [p('M12 4v12'), p('M6 12l6 6 6-6'), p('M4 20h16')])
export const SkIconEdit = icon('SkIconEdit', () => [p('M17 3l4 4L8 20l-5 1 1-5z')])
export const SkIconTrash = icon('SkIconTrash', () => [p('M4 7h16'), p('M9 7V4h6v3'), p('M6 7l1 14h10l1-14'), p('M10 11v6'), p('M14 11v6')])
export const SkIconMove = icon('SkIconMove', () => [p('M12 2v20'), p('M2 12h20'), p('M8 6l4-4 4 4'), p('M8 18l4 4 4-4'), p('M6 8l-4 4 4 4'), p('M18 8l4 4-4 4')])
export const SkIconCopy = icon('SkIconCopy', () => [h('rect', { x: 9, y: 9, width: 12, height: 12, rx: 2 }), p('M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1')])
export const SkIconLink = icon('SkIconLink', () => [p('M10 13a5 5 0 0 0 7.5.5l3-3a5 5 0 0 0-7-7l-1.7 1.7'), p('M14 11a5 5 0 0 0-7.5-.5l-3 3a5 5 0 0 0 7 7l1.7-1.7')])
export const SkIconShare = icon('SkIconShare', () => [h('circle', { cx: 18, cy: 5, r: 3 }), h('circle', { cx: 6, cy: 12, r: 3 }), h('circle', { cx: 18, cy: 19, r: 3 }), p('M8.6 13.5l6.8 4'), p('M15.4 6.5l-6.8 4')])
export const SkIconEye = icon('SkIconEye', () => [p('M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z'), h('circle', { cx: 12, cy: 12, r: 3 })])
export const SkIconEyeOff = icon('SkIconEyeOff', () => [p('M2 2l20 20'), p('M6.7 6.7C3.6 8.8 1 12 1 12s4 8 11 8c2 0 3.7-.5 5.2-1.3'), p('M10.6 5.2C11 5.1 11.5 5 12 5c7 0 11 7 11 7s-1 1.9-2.8 3.7')])
export const SkIconHistory = icon('SkIconHistory', () => [h('circle', { cx: 12, cy: 12, r: 9 }), p('M12 7v5l3 3')])
export const SkIconStar = icon('SkIconStar', () => [p('M12 2l3.1 6.3 6.9 1-5 4.9 1.2 6.8-6.2-3.2-6.2 3.2 1.2-6.8-5-4.9 6.9-1z')])
export const SkIconStarFill = icon('SkIconStarFill', () => [p('M12 2l3.1 6.3 6.9 1-5 4.9 1.2 6.8-6.2-3.2-6.2 3.2 1.2-6.8-5-4.9 6.9-1z')], { fill: 'currentColor', stroke: 'none' })

/* ── 用户 / 状态 ── */
export const SkIconUser = icon('SkIconUser', () => [h('circle', { cx: 12, cy: 8, r: 4 }), p('M4 21c0-4 3.6-6 8-6s8 2 8 6')])
export const SkIconUserPlus = icon('SkIconUserPlus', () => [h('circle', { cx: 10, cy: 8, r: 4 }), p('M2 21c0-4 3.6-6 8-6 1.5 0 2.9.2 4 .7'), p('M19 8v6'), p('M16 11h6')])
export const SkIconLock = icon('SkIconLock', () => [h('rect', { x: 5, y: 11, width: 14, height: 10, rx: 2 }), p('M8 11V7a4 4 0 0 1 8 0v4')])
export const SkIconLogout = icon('SkIconLogout', () => [p('M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4'), p('M16 17l5-5-5-5'), p('M21 12H9')])
export const SkIconBulb = icon('SkIconBulb', () => [p('M12 3a6 6 0 0 0-4 10.5c.7.6 1 1.6 1 2.5h6c0-.9.3-1.9 1-2.5A6 6 0 0 0 12 3z'), p('M9 19h6'), p('M10 22h4')])
export const SkIconPalette = icon('SkIconPalette', () => [p('M12 22a1 1 0 0 1 0-20 10 9 0 0 1 10 9 5 5 0 0 1-5 5h-2.25a1.75 1.75 0 0 0-1.4 2.8l.3.4a1.75 1.75 0 0 1-1.4 2.8z'), dot(13.5, 6.5), dot(17.5, 10.5), dot(6.5, 12.5), dot(8.5, 7.5)])
export const SkIconClock = icon('SkIconClock', () => [h('circle', { cx: 12, cy: 12, r: 9 }), p('M12 7v5l3 3')])
export const SkIconKey = icon('SkIconKey', () => [h('circle', { cx: 7.5, cy: 15.5, r: 4.5 }), p('M10.3 12.7 20 3'), p('M16 7l3 3'), p('M13 10l2 2')])
export const SkIconChart = icon('SkIconChart', () => [p('M18 20V10'), p('M12 20V4'), p('M6 20v-6')])
export const SkIconMoon = icon('SkIconMoon', () => [p('M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z')])
export const SkIconSun = icon('SkIconSun', () => [h('circle', { cx: 12, cy: 12, r: 4 }), p('M12 2v2'), p('M12 20v2'), p('M4.9 4.9l1.4 1.4'), p('M17.7 17.7l1.4 1.4'), p('M2 12h2'), p('M20 12h2'), p('M4.9 19.1l1.4-1.4'), p('M17.7 6.3l1.4-1.4')])
export const SkIconReload = icon('SkIconReload', () => [p('M21 12a9 9 0 1 1-2.6-6.4'), p('M21 3v6h-6')])

/* ── 品牌标识 ── */
/** 简笔鹅（鸟形侧影）：logo 与品牌位使用 */
export const SkIconGoose = icon('SkIconGoose', () => [
  p('M16 7h.01'),
  p('M3.4 18H12a8 8 0 0 0 8-8V7a4 4 0 0 0-7.28-2.3L2 20'),
  p('M20 7l2 .5-2 .5'),
  p('M10 18v3'),
  p('M14 17.75V21'),
  p('M7 18a6 6 0 0 0 3.84-10.61'),
])

/**
 * skMessage：全局轻提示（顶部居中堆叠的线框便签）。
 * 用法：skMessage.success('已保存')；loading 返回关闭函数：
 *   const hide = skMessage.loading('上传中…')；完成后 hide()。
 */
import { createApp, h, reactive } from 'vue'

type SkMessageType = 'success' | 'error' | 'warning' | 'info' | 'loading'

interface SkMessageItem {
  id: number
  type: SkMessageType
  content: string
  leaving: boolean
}

const items = reactive<SkMessageItem[]>([])
let app: ReturnType<typeof createApp> | null = null
let root: HTMLElement | null = null
let seq = 0

const GLYPH: Record<SkMessageType, string> = {
  success: '✓',
  error: '✕',
  warning: '⚠',
  info: 'ℹ',
  loading: '⧗',
}

function ensureRoot() {
  if (app) return
  root = document.createElement('div')
  root.className = 'sk-message-root'
  document.body.appendChild(root)
  app = createApp({
    setup: () => () =>
      h(
        'div',
        { class: 'sk-message-list' },
        items.map(i =>
          h('div', { key: i.id, class: ['sk-message', `sk-message-${i.type}`, { 'is-leaving': i.leaving }] }, [
            h('span', { class: 'sk-message-glyph' }, GLYPH[i.type]),
            h('span', { class: 'sk-message-content' }, i.content),
          ]),
        ),
      ),
  })
  app.mount(root)
}

function remove(id: number) {
  const item = items.find(i => i.id === id)
  if (!item || item.leaving) return
  item.leaving = true
  setTimeout(() => {
    const idx = items.findIndex(i => i.id === id)
    if (idx >= 0) items.splice(idx, 1)
  }, 180)
}

function show(type: SkMessageType, content: string, duration = 3): () => void {
  ensureRoot()
  const id = ++seq
  items.push({ id, type, content, leaving: false })
  if (duration > 0) setTimeout(() => remove(id), duration * 1000)
  return () => remove(id)
}

export const skMessage = {
  success: (content: string, duration?: number) => show('success', content, duration),
  error: (content: string, duration?: number) => show('error', content, duration),
  warning: (content: string, duration?: number) => show('warning', content, duration),
  info: (content: string, duration?: number) => show('info', content, duration),
  /** 持续提示：返回关闭函数 */
  loading: (content: string) => show('loading', content, 0),
}

// 提示样式随库注入（一次性 <style>）
if (typeof document !== 'undefined') {
  const style = document.createElement('style')
  style.textContent = `
.sk-message-root { position: fixed; top: 18px; left: 0; right: 0; z-index: 3000; display: flex; justify-content: center; pointer-events: none; }
.sk-message-list { display: flex; flex-direction: column; align-items: center; gap: 8px; }
.sk-message {
  display: flex; align-items: center; gap: 8px; max-width: min(86vw, 480px);
  font-family: var(--sk-font); font-size: var(--sk-font-size-sm); color: var(--sk-text);
  background: var(--sk-surface); border: var(--sk-border-thin); border-radius: var(--sk-radius);
  box-shadow: var(--sk-shadow-pop); padding: 7px 14px;
  animation: sk-message-in 0.16s ease-out; transition: opacity 0.18s, transform 0.18s;
}
.sk-message.is-leaving { opacity: 0; transform: translateY(-6px); }
.sk-message-glyph { font-weight: 700; font-size: var(--sk-font-size-base); }
.sk-message-success .sk-message-glyph { color: var(--sk-success); }
.sk-message-error .sk-message-glyph { color: var(--sk-danger); }
.sk-message-warning .sk-message-glyph { color: var(--sk-warning); }
.sk-message-info .sk-message-glyph { color: var(--sk-info); }
.sk-message-loading .sk-message-glyph { color: var(--sk-accent-line); animation: sk-message-spin 1s linear infinite; display: inline-block; }
@keyframes sk-message-in { from { opacity: 0; transform: translateY(-8px); } }
@keyframes sk-message-spin { to { transform: rotate(360deg); } }
`
  document.head.appendChild(style)
}

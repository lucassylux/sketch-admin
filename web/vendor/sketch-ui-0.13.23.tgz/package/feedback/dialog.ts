/**
 * skDialog：命令式对话框（confirm / prompt / select），Promise 风格。
 *   const ok = await skDialog.confirm({ title: '删除？', danger: true })   // boolean
 *   const name = await skDialog.prompt({ title: '新建文件夹' })            // string | null
 *   const dir = await skDialog.select({ title: '移动到…', options })       // string | null（'' = 根/未选）
 * 取消一律 resolve(null) / false，不 reject —— 调用处无需 try/catch。
 */
import { createApp, h, nextTick, ref } from 'vue'
import sketchUI from '../index'
import SkModal from '../components/SkModal.vue'
import SkInput from '../components/SkInput.vue'
import SkSelect from '../components/SkSelect.vue'
import SkButton from '../components/SkButton.vue'
import { skMessage } from './message'

interface Host {
  close: (result: unknown) => void
}

function mountDialog(render: (host: Host) => ReturnType<typeof h>): Promise<unknown> {
  return new Promise(resolve => {
    const div = document.createElement('div')
    document.body.appendChild(div)
    const app = createApp({
      render: () =>
        render({
          close: (result: unknown) => {
            app.unmount()
            div.remove()
            resolve(result)
          },
        }),
    })
    // 独立 app 上下文装插件：confirm 的 content 里按名字引用的组件（如业务组件模板里的 SkInput）
    // 依赖全局注册，不装插件则解析不到、渲染为空（插件仅在运行时 use，模块级循环引用安全）
    app.use(sketchUI)
    app.mount(div)
  })
}

export interface SkConfirmOptions {
  title: string
  /** 确认内容：字符串或返回 VNode 的工厂 */
  content?: string | (() => any)
  danger?: boolean
  okText?: string
  /** 确认回调（可选）：成功（resolve）才关窗并返回 true；抛错/reject 保持打开由用户修正后重试。
   *  此前版本忽略该选项——确认只是关窗，携带异步提交的调用方（如重置密码）请求根本不会发出 */
  onOk?: () => unknown
}

export function skDialogConfirm(opts: SkConfirmOptions): Promise<boolean> {
  return mountDialog(host => {
    const busy = ref(false)
    const onOk = async () => {
      if (!opts.onOk) {
        host.close(true)
        return
      }
      busy.value = true
      try {
        await opts.onOk()
        host.close(true)
      } catch {
        busy.value = false // 失败保持打开（提示由调用方/请求拦截器负责）
      }
    }
    return h(
      SkModal,
      { open: true, title: opts.title, maskClosable: true, 'onUpdate:open': (v: boolean) => !v && host.close(false) },
      {
        // content 支持 字符串 / VNode 工厂：字符串包段落样式，VNode 直挂（避免 p 里嵌块级元素的脆弱结构）
        default: () => {
          if (typeof opts.content === 'function') return opts.content()
          return opts.content ? h('p', { class: 'sk-dialog-text' }, opts.content) : undefined
        },
        footer: () => [
          h(SkButton, { disabled: busy.value, onClick: () => host.close(false) }, () => '取消'),
          h(
            SkButton,
            { variant: opts.danger ? 'danger' : 'primary', loading: busy.value, onClick: onOk },
            () => opts.okText ?? '确定',
          ),
        ],
      },
    )
  }) as Promise<boolean>
}

export interface SkPromptOptions {
  title: string
  label?: string
  placeholder?: string
  value?: string
  required?: boolean
  okText?: string
}

export function skDialogPrompt(opts: SkPromptOptions): Promise<string | null> {
  const val = ref(opts.value ?? '')
  const submit = (host: Host) => {
    const v = val.value.trim()
    if (opts.required !== false && !v) return skMessage.warning('内容不能为空')
    host.close(v)
  }
  return mountDialog(host =>
    h(
      SkModal,
      { open: true, title: opts.title, 'onUpdate:open': (v: boolean) => !v && host.close(null) },
      {
        default: () =>
          h('div', { class: 'sk-dialog-form' }, [
            opts.label ? h('div', { class: 'sk-dialog-label' }, opts.label) : null,
            h(SkInput, {
              modelValue: val.value,
              placeholder: opts.placeholder ?? '',
              'onUpdate:modelValue': (v: string) => (val.value = v),
              onKeyup: (e: KeyboardEvent) => e.key === 'Enter' && submit(host),
            }),
          ]),
        footer: () => [
          h(SkButton, { onClick: () => host.close(null) }, () => '取消'),
          h(SkButton, { variant: 'primary', onClick: () => submit(host) }, () => opts.okText ?? '确定'),
        ],
      },
    ),
  ).then(async v => {
    if (v != null) await nextTick()
    return v as string | null
  }) as Promise<string | null>
}

export interface SkSelectDialogOptions {
  title: string
  /** 顶层空选项文案（值为 ''），默认“（根目录）” */
  placeholder?: string
  options: { value: string | number; label: string }[]
  okText?: string
}

export function skDialogSelect(opts: SkSelectDialogOptions): Promise<string | null> {
  const val = ref('')
  return mountDialog(host =>
    h(
      SkModal,
      { open: true, title: opts.title, 'onUpdate:open': (v: boolean) => !v && host.close(null) },
      {
        default: () =>
          h('div', { class: 'sk-dialog-form' }, [
            h(SkSelect, {
              modelValue: val.value,
              options: opts.options,
              placeholder: opts.placeholder ?? '（根目录）',
              clearable: true,
              'onUpdate:modelValue': (v: string | number | (string | number)[]) => (val.value = String(v)),
            }),
          ]),
        footer: () => [
          h(SkButton, { onClick: () => host.close(null) }, () => '取消'),
          h(SkButton, { variant: 'primary', onClick: () => host.close(val.value) }, () => opts.okText ?? '确定'),
        ],
      },
    ),
  ) as Promise<string | null>
}

export const skDialog = {
  confirm: skDialogConfirm,
  prompt: skDialogPrompt,
  select: skDialogSelect,
}

/** dialog 内部布局样式（命令式挂载，样式随本文件注入） */
if (typeof document !== 'undefined') {
  const style = document.createElement('style')
  style.textContent = `
.sk-dialog-text { font-family: var(--sk-font); font-size: var(--sk-font-size-base); line-height: 1.7; color: var(--sk-text); margin: 0; }
.sk-dialog-form { display: flex; flex-direction: column; gap: 6px; }
.sk-dialog-form .sk-input, .sk-dialog-form .sk-select { width: 100%; }
.sk-dialog-label { font-size: var(--sk-font-size-xs); color: var(--sk-text-muted); text-transform: uppercase; letter-spacing: 0.07em; }
`
  document.head.appendChild(style)
}

<template>
  <div class="sk-skeleton">
    <template v-if="type === 'line'">
      <div v-for="(w, i) in lineWidths" :key="i" class="sk-skeleton-line" :style="{ width: w }"></div>
    </template>
    <div v-else class="sk-skeleton-block" :style="{ height: blockHeight + 'px' }"></div>
  </div>
</template>

<script setup lang="ts">
/** 加载骨架（4.html ph-line/ph-block）：lines 条灰线宽度循环 100/75/55%，或整块灰块。 */
const props = withDefaults(
  defineProps<{
    type?: 'line' | 'block'
    lines?: number
    blockHeight?: number
  }>(),
  { type: 'line', lines: 3, blockHeight: 90 },
)
const PATTERN = ['100%', '75%', '55%']
const lineWidths = Array.from({ length: props.lines }, (_, i) => PATTERN[i % PATTERN.length])
</script>

<style>
.sk-skeleton { width: 100%; }
.sk-skeleton-line {
  height: 8px; border-radius: 3px;
  background: var(--sk-muted-soft2); margin-bottom: 5px;
}
.sk-skeleton-block {
  border: 1.5px dashed var(--sk-line-faint); border-radius: var(--sk-radius);
  background: var(--sk-surface-dim);
}
</style>

<template>
  <div class="sk-daterange" ref="rootEl">
    <button type="button" class="sk-daterange-trigger" :class="{ 'is-open': open }" @click="toggle">
      <svg viewBox="0 0 24 24" class="sk-daterange-icon"><rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/></svg>
      <span v-if="text" class="sk-daterange-text">{{ text }}</span>
      <span v-else class="sk-daterange-ph">{{ placeholder }}</span>
    </button>

    <div v-if="open" class="sk-daterange-panel" :class="{ 'is-up': flipUp, 'is-single': single }">
      <div v-if="presets && presetList.length && !single" class="sk-daterange-presets">
        <button v-for="p in presetList" :key="p.label" type="button" class="sk-daterange-preset" @click="applyPreset(p)">{{ p.label }}</button>
      </div>
      <div class="sk-daterange-calendars" :class="{ 'is-single': single }">
        <div v-for="offset in (single ? [0] : [0, 1])" :key="offset" class="sk-daterange-cal">
          <div class="sk-daterange-cal-head">
            <button v-if="offset === 0" type="button" class="sk-daterange-nav" @click="view = shiftMonth(view, -1)" aria-label="上个月">‹</button>
            <span class="sk-daterange-month">{{ monthLabel(shiftMonth(view, offset)) }}</span>
            <button v-if="single || offset === 1" type="button" class="sk-daterange-nav" @click="view = shiftMonth(view, 1)" aria-label="下个月">›</button>
          </div>
          <div class="sk-daterange-week">
            <span v-for="w in ['一', '二', '三', '四', '五', '六', '日']" :key="w">{{ w }}</span>
          </div>
          <div class="sk-daterange-grid">
            <button
              v-for="(d, i) in gridOf(shiftMonth(view, offset))"
              :key="i"
              type="button"
              class="sk-daterange-day"
              :class="{
                'is-blank': !d,
                'is-start': d && iso(d) === start,
                'is-end': d && iso(d) === end,
                'in-range': d && inRange(d),
              }"
              :disabled="!d"
              @click="pick(d!)"
            >{{ d?.getDate() }}</button>
          </div>
        </div>
      </div>
      <div class="sk-daterange-foot">
        <span class="sk-daterange-hint">{{ footHint }}</span>
        <span class="sk-daterange-ops">
          <button type="button" class="sk-daterange-btn" @click="clear">清空</button>
          <button type="button" class="sk-daterange-btn is-primary" :disabled="!start || !end" @click="confirm">确定</button>
        </span>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
/**
 * 日期范围选择器（7/8.html 顶栏 "Jun 1 - Jun 30" 日期段按钮）：
 * 触发按钮 + 弹层面板（预设 + 双月历 + 清空/确定）；点两次日期定区间（起点→终点），
 * 空间不足自动向上翻转。值为 [start, end]（YYYY-MM-DD）。
 */
import { computed, onBeforeUnmount, onMounted, ref } from 'vue'

const props = withDefaults(
  defineProps<{
    modelValue?: [string, string] | null
    placeholder?: string
    presets?: boolean
    /** 单日模式：只显示一个月历，点选即确认，值仍为 [d, d] */
    single?: boolean
  }>(),
  { modelValue: null, placeholder: '选择日期范围', presets: true, single: false },
)
const emit = defineEmits<{
  (e: 'update:modelValue', v: [string, string] | null): void
  (e: 'change', v: [string, string] | null): void
}>()

const open = ref(false)
const flipUp = ref(false)
const start = ref<string | null>(null)
const end = ref<string | null>(null)
const pickingEnd = ref(false)
const view = ref(monthOf(new Date()))
const rootEl = ref<HTMLElement | null>(null)

const presetList = [
  { label: '今天', range: daysOffset(0, 0) },
  { label: '最近 7 天', range: daysOffset(-6, 0) },
  { label: '最近 30 天', range: daysOffset(-29, 0) },
  { label: '本月', range: monthRange(0) },
  { label: '上月', range: monthRange(-1) },
]

const text = computed(() => {
  if (props.modelValue && props.modelValue[0]) {
    const [a, b] = props.modelValue
    return props.single ? a : `${a}${b ? ' ~ ' + b : ''}`
  }
  return ''
})
const footHint = computed(() => {
  if (props.single) return start.value || '请选择日期'
  if (!start.value) return '请选择开始日期'
  if (!end.value) return '请选择结束日期'
  return `${start.value} ~ ${end.value}`
})

function toggle() {
  open.value ? close() : show()
}
function show() {
  if (props.modelValue) {
    start.value = props.modelValue[0]
    end.value = props.modelValue[1] ?? null
    view.value = monthOf(new Date(props.modelValue[0] + 'T00:00:00'))
  } else {
    start.value = null
    end.value = null
  }
  pickingEnd.value = false
  open.value = true
  requestAnimationFrame(() => {
    const el = rootEl.value?.querySelector('.sk-daterange-panel')
    const r = el?.getBoundingClientRect()
    flipUp.value = !!r && r.bottom > window.innerHeight - 8
  })
}
function close() {
  open.value = false
}
function pick(d: Date) {
  const v = iso(d)
  if (props.single) {
    start.value = v
    end.value = v
    pickingEnd.value = false
    confirm()
    return
  }
  if (!pickingEnd.value) {
    start.value = v
    end.value = null
    pickingEnd.value = true
  } else {
    if (start.value && v < start.value) {
      end.value = start.value
      start.value = v
    } else {
      end.value = v
    }
    pickingEnd.value = false
  }
}
function inRange(d: Date) {
  const v = iso(d)
  return !!start.value && !!end.value && v > start.value && v < end.value
}
function applyPreset(p: { label: string; range: [string, string] }) {
  start.value = p.range[0]
  end.value = p.range[1]
  pickingEnd.value = false
  confirm()
}
function confirm() {
  if (!start.value || !end.value) return
  emit('update:modelValue', [start.value, end.value])
  emit('change', [start.value, end.value])
  close()
}
function clear() {
  start.value = null
  end.value = null
  pickingEnd.value = false
  emit('update:modelValue', null)
  emit('change', null)
}

/* ── 日期工具 ── */
function iso(d: Date) {
  const p = (x: number) => String(x).padStart(2, '0')
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`
}
function monthOf(d: Date) {
  return { y: d.getFullYear(), m: d.getMonth() }
}
function shiftMonth({ y, m }: { y: number; m: number }, delta: number) {
  const d = new Date(y, m + delta, 1)
  return monthOf(d)
}
function monthLabel({ y, m }: { y: number; m: number }) {
  return `${y} 年 ${m + 1} 月`
}
function gridOf({ y, m }: { y: number; m: number }) {
  const first = new Date(y, m, 1)
  const startWeek = (first.getDay() + 6) % 7  // 周一为首
  const days = new Date(y, m + 1, 0).getDate()
  const cells: (Date | null)[] = Array(startWeek).fill(null)
  for (let i = 1; i <= days; i++) cells.push(new Date(y, m, i))
  return cells
}
function daysOffset(a: number, b: number): [string, string] {
  const to = new Date()
  const from = new Date()
  from.setDate(to.getDate() + a)
  const t = new Date()
  t.setDate(to.getDate() + b)
  return [iso(from), iso(t)]
}
function monthRange(delta: number): [string, string] {
  const base = new Date()
  const first = new Date(base.getFullYear(), base.getMonth() + delta, 1)
  const last = new Date(base.getFullYear(), base.getMonth() + delta + 1, 0)
  return [iso(first), iso(last)]
}

/* ── 外点关闭 ── */
function onDoc(e: MouseEvent) {
  if (open.value && rootEl.value && !rootEl.value.contains(e.target as Node)) close()
}
onMounted(() => document.addEventListener('mousedown', onDoc))
onBeforeUnmount(() => document.removeEventListener('mousedown', onDoc))
</script>

<style>
.sk-daterange { position: relative; display: inline-block; }
.sk-daterange-trigger {
  display: inline-flex; align-items: center; gap: 7px;
  height: var(--sk-control-h); padding: 0 var(--sk-control-px);
  border: var(--sk-border-input); border-radius: var(--sk-radius-btn, var(--sk-radius));
  background: var(--sk-surface); color: var(--sk-text);
  font-size: var(--sk-font-size-base); cursor: pointer; white-space: nowrap;
}
.sk-daterange-trigger:hover { border-color: var(--sk-accent-line); }
.sk-daterange-trigger.is-open { border-color: var(--sk-accent-line); }
.sk-daterange-icon { width: 14px; height: 14px; stroke: var(--sk-text-muted); stroke-width: 1.8; fill: none; stroke-linecap: round; }
.sk-daterange-ph { color: var(--sk-text-faint); }
.sk-daterange-text { font-variant-numeric: tabular-nums; }
.sk-daterange-panel {
  position: absolute; top: calc(100% + 6px); left: 0; z-index: 60;
  background: var(--sk-surface); border: var(--sk-border-thin);
  border-radius: var(--sk-radius-card, var(--sk-radius)); box-shadow: var(--sk-shadow-overlay);
  padding: 10px; width: 470px;
}
.sk-daterange-panel.is-up { top: auto; bottom: calc(100% + 6px); }
.sk-daterange-presets { display: flex; gap: 6px; flex-wrap: wrap; margin-bottom: 10px; }
.sk-daterange-preset {
  font-size: var(--sk-font-size-xs); padding: 3px 9px; cursor: pointer;
  border: var(--sk-border-input); border-radius: 999px; background: var(--sk-surface);
  color: var(--sk-text-muted);
}
.sk-daterange-preset:hover { color: var(--sk-text); background: var(--sk-hover); }
.sk-daterange-panel.is-single { width: 250px; }
.sk-daterange-calendars.is-single { grid-template-columns: 1fr; }
.sk-daterange-calendars { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
.sk-daterange-cal-head { display: flex; align-items: center; justify-content: space-between; margin-bottom: 6px; }
.sk-daterange-month { font-size: var(--sk-font-size-sm); font-weight: 700; }
.sk-daterange-nav {
  width: 22px; height: 22px; border: var(--sk-border-input); border-radius: var(--sk-radius-btn, var(--sk-radius));
  background: var(--sk-surface); cursor: pointer; color: var(--sk-text-muted);
  font-size: 14px; line-height: 1; display: inline-flex; align-items: center; justify-content: center;
}
.sk-daterange-nav:hover { color: var(--sk-text); background: var(--sk-hover); }
.sk-daterange-week { display: grid; grid-template-columns: repeat(7, 1fr); margin-bottom: 2px; }
.sk-daterange-week span { text-align: center; font-size: var(--sk-font-size-xs); color: var(--sk-text-faint); padding: 2px 0; }
.sk-daterange-grid { display: grid; grid-template-columns: repeat(7, 1fr); gap: 1px; }
.sk-daterange-day {
  height: 26px; border: none; background: none; cursor: pointer;
  font-size: var(--sk-font-size-xs); color: var(--sk-text); border-radius: var(--sk-radius-card, var(--sk-radius));
  font-variant-numeric: tabular-nums;
}
.sk-daterange-day:hover { background: var(--sk-hover); }
.sk-daterange-day.is-blank { cursor: default; }
.sk-daterange-day.in-range { background: var(--sk-accent-faint); border-radius: 0; }
.sk-daterange-day.is-start, .sk-daterange-day.is-end {
  background: var(--sk-primary); color: var(--sk-on-primary); font-weight: 700;
}
.sk-daterange-day.is-start { border-radius: var(--sk-radius-card, var(--sk-radius)) 0 0 var(--sk-radius-card, var(--sk-radius)); }
.sk-daterange-day.is-end { border-radius: 0 var(--sk-radius-card, var(--sk-radius)) var(--sk-radius-card, var(--sk-radius)) 0; }
.sk-daterange-foot {
  display: flex; align-items: center; justify-content: space-between;
  margin-top: 10px; padding-top: 8px; border-top: var(--sk-border-divider);
}
.sk-daterange-hint { font-size: var(--sk-font-size-xs); color: var(--sk-text-faint); font-variant-numeric: tabular-nums; }
.sk-daterange-ops { display: flex; gap: 6px; }
.sk-daterange-btn {
  height: 24px; padding: 0 10px; font-size: var(--sk-font-size-xs); cursor: pointer;
  border: var(--sk-border-input); border-radius: var(--sk-radius-btn, var(--sk-radius));
  background: var(--sk-surface); color: var(--sk-text);
}
.sk-daterange-btn:hover { background: var(--sk-hover); }
.sk-daterange-btn.is-primary { background: var(--sk-primary); color: var(--sk-on-primary); border-color: transparent; }
.sk-daterange-btn.is-primary:disabled { opacity: 0.45; cursor: not-allowed; }
@media (max-width: 520px) {
  .sk-daterange-panel { width: 320px; }
  .sk-daterange-calendars { grid-template-columns: 1fr; }
}
</style>

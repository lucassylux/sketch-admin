<template>
  <div class="sk-empty">
    <span class="sk-empty-glyph" aria-hidden="true">⌀</span>
    <div class="sk-empty-text"><slot>{{ description }}</slot></div>
    <div v-if="$slots.extra" class="sk-empty-extra"><slot name="extra" /></div>
  </div>
</template>

<script setup lang="ts">
/** 空状态：虚线框 + 弱化说明 + 可选操作区（#extra）。 */
defineProps<{ description?: string }>()
</script>

<style>
.sk-empty {
  display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 8px;
  padding: 30px 16px; color: var(--sk-text-faint); font-size: var(--sk-font-size-sm);
}
.sk-empty-glyph { font-size: 22px; opacity: 0.5; }
.sk-empty-text { text-align: center; line-height: 1.7; }
.sk-empty-text a { color: var(--sk-link); }
.sk-empty-extra { margin-top: 6px; }
</style>

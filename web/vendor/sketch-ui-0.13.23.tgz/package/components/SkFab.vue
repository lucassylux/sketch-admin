<template>
  <button type="button" class="sk-fab" :class="[`sk-fab-${tone}`, { 'sk-fab-open': open }]" :title="label" :aria-label="label" @click="$emit('update:open', !open)">
    <span v-if="label && !open" class="sk-fab-label">{{ label }}</span>
    <slot>
      <svg viewBox="0 0 24 24" class="sk-fab-icon"><path d="M12 5v14M5 12h14" /></svg>
    </slot>
  </button>
</template>

<script setup lang="ts">
/**
 * 悬浮操作按钮 FAB（5.html FloatingActionButton 新建交易）：
 * 固定右下角；label 存在时为扩展型（文字 + 图标）；可作为展开菜单的触发器（v-model:open）。
 */
withDefaults(
  defineProps<{
    label?: string
    tone?: 'primary' | 'accent'
    open?: boolean
  }>(),
  { tone: 'primary', open: false },
)
defineEmits<{ (e: 'update:open', v: boolean): void }>()
</script>

<style>
.sk-fab {
  position: fixed; right: 24px; bottom: 24px; z-index: 90;
  display: inline-flex; align-items: center; gap: 8px;
  height: 46px; min-width: 46px; padding: 0 14px;
  border: none; border-radius: 999px; cursor: pointer;
  box-shadow: var(--sk-shadow-overlay);
  transition: transform 0.15s, box-shadow 0.15s;
}
.sk-fab:hover { transform: translateY(-2px); }
.sk-fab:active { transform: translateY(0); }
.sk-fab-primary { background: var(--sk-primary); color: var(--sk-on-primary); }
.sk-fab-accent { background: var(--sk-accent); color: var(--sk-on-primary); }
.sk-fab-icon { width: 20px; height: 20px; stroke: currentColor; stroke-width: 2.2; fill: none; stroke-linecap: round; }
.sk-fab-label { font-size: var(--sk-font-size-md); font-weight: 600; white-space: nowrap; }
</style>

<template>
  <!-- 单选与多选共用一套自绘触发器 + 弹层（单选原生 select 方案已废弃：下拉无样式且无法搜索） -->
  <div class="sk-select-multi" :class="{ 'is-open': open, 'is-disabled': disabled, 'has-value': hasSelection }" ref="rootEl">
    <button
      type="button" class="sk-select sk-select-trigger"
      :class="[size === 'sm' ? 'sk-select-sm' : '', { 'is-placeholder': !hasSelection }]"
      :disabled="disabled" @click="toggleOpen"
    >
      <span v-if="multiple" class="sk-select-multi-tags">
        <span v-if="!selected.length" class="sk-select-multi-ph">{{ placeholder || '全部' }}</span>
        <template v-else>
          <span v-for="v in shownTags" :key="String(v)" class="sk-select-multi-tag">{{ labelOf(v) }}</span>
          <span v-if="selected.length > shownTags.length" class="sk-select-multi-tag is-more">+{{ selected.length - shownTags.length }}</span>
        </template>
      </span>
      <span v-else class="sk-select-single-label">{{ hasSelection ? labelOf(modelValue as string | number) : (placeholder || '全部') }}</span>
      <span class="sk-select-caret" aria-hidden="true"></span>
      <span v-if="hasSelection && !disabled" class="sk-select-clear" title="清空" @click.stop="clearAll">×</span>
    </button>
    <div v-if="open" class="sk-select-multi-panel" :class="{ 'is-up': flipUp }">
      <div v-if="options.length >= SEARCH_THRESHOLD" class="sk-select-search">
        <input
          ref="searchEl" v-model="keyword" type="text" class="sk-select-search-input"
          placeholder="搜索…" @keydown.esc="open = false"
        >
      </div>
      <div class="sk-select-list">
        <button
          v-for="o in filteredOptions" :key="String(o.value)" type="button"
          class="sk-select-multi-item" :class="{ 'is-on': isSelected(o.value) }"
          @click="pick(o.value)"
        >
          <span class="sk-select-multi-label">{{ o.label }}</span>
        </button>
        <div v-if="!filteredOptions.length" class="sk-select-empty">无匹配项</div>
      </div>
      <div class="sk-select-multi-ops">
        <button type="button" class="sk-select-multi-op" :disabled="!hasSelection" @click="clearAll">清空</button>
        <button type="button" class="sk-select-multi-op is-done" @click="open = false">完成</button>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
/**
 * 下拉选择（单选/多选同一套自绘触发器 + 弹层）：
 * - 清空：触发器悬停出现 ×，弹层操作区恒有“清空”（选填场景无需逐处配置 clearable）；
 * - 多选（multiple）：值为数组，触发器以标签展示；maxTagCount 控制标签数；
 * - 选项 ≥ SEARCH_THRESHOLD 个时弹层顶部自动出现搜索框（按 label 包含匹配，不分大小写）；
 * - 弹层空间不足自动向上翻转。
 */
import { computed, nextTick, onBeforeUnmount, onMounted, ref } from 'vue'

export interface SkSelectOption { value: string | number; label: string }

/** 选项达到该数量才显示搜索框（小列表不需要） */
const SEARCH_THRESHOLD = 8

const props = withDefaults(
  defineProps<{
    modelValue?: string | number | null | (string | number)[]
    options: SkSelectOption[]
    placeholder?: string
    clearable?: boolean
    disabled?: boolean
    size?: 'sm' | 'md'
    multiple?: boolean
    maxTagCount?: number
  }>(),
  { size: 'md', maxTagCount: 3 },
)
const emit = defineEmits<{
  'update:modelValue': [v: string | number | (string | number)[]]
  'change': [v: string | number | (string | number)[]]
}>()

const selected = computed<(string | number)[]>(() => (Array.isArray(props.modelValue) ? props.modelValue : []))
const hasSelection = computed(() =>
  props.multiple ? selected.value.length > 0 : props.modelValue != null && props.modelValue !== '')
const shownTags = computed(() => selected.value.slice(0, props.maxTagCount))

function labelOf(v: string | number) {
  return props.options.find(o => o.value === v)?.label ?? String(v)
}
function isSelected(v: string | number) {
  return props.multiple ? selected.value.includes(v) : props.modelValue === v
}
function pick(v: string | number) {
  if (props.multiple) {
    const next = isSelected(v) ? selected.value.filter(x => x !== v) : [...selected.value, v]
    emit('update:modelValue', next)
    emit('change', next)
  } else {
    emit('update:modelValue', v)
    emit('change', v)
    open.value = false
  }
}
function clearAll() {
  emit('update:modelValue', props.multiple ? [] : '')
  emit('change', props.multiple ? [] : '')
}

/* ── 弹层：开合/搜索/翻转/外点关闭 ── */
const open = ref(false)
const flipUp = ref(false)
const keyword = ref('')
const rootEl = ref<HTMLElement | null>(null)
const searchEl = ref<HTMLInputElement | null>(null)
const filteredOptions = computed(() => {
  const k = keyword.value.trim().toLowerCase()
  return k ? props.options.filter(o => String(o.label).toLowerCase().includes(k)) : props.options
})

async function toggleOpen() {
  open.value = !open.value
  if (open.value) {
    keyword.value = ''
    await nextTick()
    searchEl.value?.focus()
  }
}
function onDoc(e: MouseEvent) {
  if (open.value && rootEl.value && !rootEl.value.contains(e.target as Node)) open.value = false
}
function onScroll() {
  if (!open.value) return
  const el = rootEl.value?.querySelector('.sk-select-multi-panel')
  const r = el?.getBoundingClientRect()
  flipUp.value = !!r && r.bottom > window.innerHeight - 8
}
onMounted(() => {
  document.addEventListener('mousedown', onDoc)
  window.addEventListener('scroll', onScroll, true)
})
onBeforeUnmount(() => {
  document.removeEventListener('mousedown', onDoc)
  window.removeEventListener('scroll', onScroll, true)
})
</script>

<style>
.sk-select {
  font-family: var(--sk-font); font-size: var(--sk-font-size-base); color: var(--sk-text);
  height: var(--sk-control-h); padding: 0 24px 0 var(--sk-control-px);
  border: var(--sk-border-input); border-radius: var(--sk-radius-btn, var(--sk-radius));
  background: var(--sk-surface); cursor: pointer; min-width: 0;
}
.sk-select:disabled { background-color: var(--sk-muted-soft2); color: var(--sk-text-faint); cursor: not-allowed; }
.sk-select-trigger.is-placeholder { color: var(--sk-text-faint); }
.sk-select-sm { height: var(--sk-control-h-sm); font-size: var(--sk-font-size-sm); padding-left: var(--sk-control-px-sm); }

/* ── 触发器（单/多选共用；flex:1 撑满字段宽，caret 锚定右缘） ── */
.sk-select-multi { position: relative; display: flex; min-width: 0; }
.sk-select-trigger {
  display: inline-flex; align-items: center; gap: 8px; text-align: left;
  flex: 1; min-width: 0; position: relative;
  padding-right: 30px;
}
.sk-select-trigger .sk-select-caret {
  position: absolute; right: 10px; top: 50%; width: 7px; height: 7px;
  border-right: 1.5px solid var(--sk-text-muted); border-bottom: 1.5px solid var(--sk-text-muted);
  transform: translateY(-70%) rotate(45deg); transition: transform 0.15s;
}
.sk-select-multi.is-open .sk-select-caret { transform: translateY(-20%) rotate(225deg); }
/* 清空钮：有值时悬停显示并顶替箭头位置 */
.sk-select-clear {
  position: absolute; right: 6px; top: 50%; transform: translateY(-50%);
  width: 16px; height: 16px; display: inline-flex; align-items: center; justify-content: center;
  font-size: 14px; line-height: 1; color: var(--sk-text-muted); cursor: pointer;
  opacity: 0; border-radius: 50%;
}
.sk-select-clear:hover { color: var(--sk-text); background: var(--sk-hover); }
.sk-select-multi.has-value:hover:not(:disabled) .sk-select-clear { opacity: 1; }
.sk-select-multi.has-value:hover .sk-select-caret { opacity: 0; }
.sk-select-multi-op:disabled { opacity: 0.45; cursor: not-allowed; }
.sk-select-single-label { flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.sk-select-multi-tags { display: inline-flex; gap: 4px; flex-wrap: nowrap; overflow: hidden; min-width: 0; }
.sk-select-multi-ph { color: var(--sk-text-faint); }
.sk-select-multi-tag {
  font-size: var(--sk-font-size-xs); padding: 1px 7px; white-space: nowrap; flex-shrink: 0;
  background: var(--sk-muted-soft2); border-radius: 999px; color: var(--sk-text-muted);
}
.sk-select-multi-tag.is-more { background: var(--sk-accent-faint); color: var(--sk-accent-line); }

/* ── 弹层（单/多选共用） ── */
.sk-select-multi-panel {
  position: absolute; top: calc(100% + 5px); left: 0; z-index: 60;
  min-width: 100%; max-height: 264px;
  display: flex; flex-direction: column; overflow: hidden;
  background: var(--sk-surface); border: var(--sk-border-thin);
  border-radius: var(--sk-radius-card, var(--sk-radius)); box-shadow: var(--sk-shadow-overlay);
  padding: 5px;
}
/* 滚动只发生在选项区：搜索框与操作区固定，滚动条不出现在它们旁边 */
.sk-select-list { flex: 1; min-height: 0; overflow-y: auto; display: flex; flex-direction: column; }
.sk-select-multi-panel.is-up { top: auto; bottom: calc(100% + 5px); }
.sk-select-search { padding: 2px 2px 6px; }
.sk-select-search-input {
  width: 100%; font-family: var(--sk-font); font-size: var(--sk-font-size-base); color: var(--sk-text);
  height: var(--sk-control-h-sm); padding: 0 8px;
  border: var(--sk-border-input); border-radius: var(--sk-radius-btn, var(--sk-radius));
  background: var(--sk-surface);
}
.sk-select-search-input:focus { outline: none; border-color: var(--sk-primary); }
.sk-select-multi-item {
  display: flex; align-items: center; gap: 8px; width: 100%;
  padding: 6px 9px; border: none; background: none; cursor: pointer; text-align: left;
  font-size: var(--sk-font-size-base); color: var(--sk-text); border-radius: var(--sk-radius-btn, var(--sk-radius));
}
.sk-select-multi-item:hover { background: var(--sk-hover); }
/* 选中态：整行高亮（单/多选同一表达，无勾选图标） */
.sk-select-multi-item.is-on { background: var(--sk-accent-soft); font-weight: 600; }
.sk-select-multi-label { flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.sk-select-empty { padding: 10px 9px; font-size: var(--sk-font-size-xs); color: var(--sk-text-faint); }
.sk-select-multi-ops {
  display: flex; justify-content: flex-end; gap: 6px;
  padding: 6px 4px 2px;
  background: var(--sk-surface); border-top: var(--sk-border-divider); margin-top: 4px;
}
.sk-select-multi-op {
  font-size: var(--sk-font-size-xs); padding: 2px 10px; cursor: pointer;
  border: var(--sk-border-input); border-radius: var(--sk-radius-btn, var(--sk-radius));
  background: var(--sk-surface); color: var(--sk-text-muted);
}
.sk-select-multi-op:hover { color: var(--sk-text); background: var(--sk-hover); }
.sk-select-multi-op.is-done { background: var(--sk-primary); color: var(--sk-on-primary); border-color: transparent; }
</style>

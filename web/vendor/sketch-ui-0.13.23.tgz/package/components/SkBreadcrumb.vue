<template>
  <nav class="sk-breadcrumb" aria-label="面包屑">
    <template v-for="(item, i) in items" :key="i">
      <span class="sk-breadcrumb-sep" v-if="i > 0">/</span>
      <span v-if="i === items.length - 1" class="sk-breadcrumb-item is-current">{{ item.label }}</span>
      <a v-else-if="item.to" class="sk-breadcrumb-item is-link" @click="$emit('select', item, i)">{{ item.label }}</a>
      <span v-else class="sk-breadcrumb-item is-plain">{{ item.label }}</span>
    </template>
  </nav>
</template>

<script setup lang="ts">
/**
 * 面包屑：items 数组；最后一项为当前位置（纯文本），
 * 其余可点击（emit select）；无路由依赖，由调用方决定跳转。
 */
export interface SkBreadcrumbItem {
  label: string
  to?: string
}

defineProps<{ items: SkBreadcrumbItem[] }>()
defineEmits<{ (e: 'select', item: SkBreadcrumbItem, index: number): void }>()
</script>

<style>
.sk-breadcrumb { display: inline-flex; align-items: center; gap: 6px; flex-wrap: wrap; font-size: var(--sk-font-size-sm); }
.sk-breadcrumb-sep { color: var(--sk-text-faint); }
.sk-breadcrumb-item { color: var(--sk-text-muted); }
.sk-breadcrumb-item.is-link { cursor: pointer; }
.sk-breadcrumb-item.is-link:hover { color: var(--sk-link); }
.sk-breadcrumb-item.is-current { color: var(--sk-text); font-weight: 600; }
.sk-breadcrumb-item.is-plain { color: var(--sk-text-muted); }
</style>

<template>
  <div v-show="isActive" class="sk-tab-pane">
    <slot />
  </div>
</template>

<script setup lang="ts">
/**
 * 页签内容面板：作为 SkTabs 子组件使用。
 * 父组件通过 provide/inject 控制显隐；也支持独立 v-model:active。
 */
import { computed, inject, ref } from 'vue'

const props = withDefaults(
  defineProps<{
    tab?: string
    disabled?: boolean
  }>(),
  {},
)

// 从父级 SkTabs 注入当前激活 key（如果存在）
const activeKey = inject<import('vue').Ref<string | number>>('skTabsActive', ref(''))
const tabKey = ref(props.tab ?? '')

// 若父级用了 :tabs 数组 + pane 子组件混合模式，key 由 tab prop 提供
const isActive = computed(() => String(activeKey?.value) === String(tabKey.value))
</script>

<style>
.sk-tab-pane { min-height: 0; }
</style>

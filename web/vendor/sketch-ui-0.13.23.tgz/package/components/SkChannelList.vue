<template>
  <ul class="sk-channels">
    <li
      v-for="c in channels"
      :key="c.key"
      :class="{ 'is-active': c.key === modelValue }"
      @click="$emit('update:modelValue', c.key)"
    >
      <span class="sk-channels-hash">#</span>
      <span class="sk-channels-name">{{ c.name }}</span>
      <SkNavBadge v-if="c.count" :count="c.count" warn />
    </li>
  </ul>
</template>

<script setup lang="ts">
/** 频道列表（4.html channel-list）：“# 名字 + 未读数”，选中黄底。 */
export interface SkChannel { key: string | number; name: string; count?: number }

defineProps<{
  channels: SkChannel[]
  modelValue?: string | number
}>()
defineEmits<{ 'update:modelValue': [v: string | number] }>()
</script>

<style>
.sk-channels { list-style: none; padding: 0; }
.sk-channels li {
  display: flex; align-items: center; gap: 6px;
  padding: 6px 14px; font-size: var(--sk-font-size-base);
  color: var(--sk-text-muted); cursor: pointer; user-select: none;
}
.sk-channels li:hover { background: var(--sk-hover); }
.sk-channels li.is-active { background: var(--sk-accent); color: var(--sk-text); font-weight: 700; }
.sk-channels-hash { color: var(--sk-text-faint); font-size: var(--sk-font-size-md); }
.sk-channels-name { flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
</style>

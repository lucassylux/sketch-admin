<template>
  <div class="sk-task" :class="{ 'is-priority': priority, 'is-done': done }" @click="$emit('toggle')">
    <span class="sk-task-check" :class="{ 'is-done': done }" aria-hidden="true"></span>
    <div class="sk-task-main">
      <div class="sk-task-title">{{ title }}</div>
      <div v-if="meta || tags?.length" class="sk-task-meta">
        <SkTag v-for="t in tags" :key="t" color="muted">{{ t }}</SkTag>
        <span v-if="meta">{{ meta }}</span>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
/** 任务行（4.html task-item）：方形勾选框 + 标题 + 标签/元信息，priority 左粗边。 */
defineProps<{
  title: string
  done?: boolean
  priority?: boolean
  meta?: string
  tags?: string[]
}>()
defineEmits<{ toggle: [] }>()
</script>

<style>
.sk-task {
  display: flex; align-items: flex-start; gap: 9px;
  border: 1.5px solid var(--sk-line-cell); border-radius: var(--sk-radius);
  padding: 8px 11px; background: var(--sk-surface);
  cursor: pointer; margin-bottom: 6px;
}
.sk-task.is-priority { border-color: var(--sk-ink); border-left: 4px solid var(--sk-ink); }
.sk-task-check {
  width: 14px; height: 14px; border: 2px solid var(--sk-line-input);
  border-radius: 3px; flex-shrink: 0; margin-top: 1px; position: relative;
}
.sk-task-check.is-done { background: var(--sk-text-muted); border-color: var(--sk-text-muted); }
.sk-task-check.is-done::after {
  content: ''; position: absolute; left: 2px; top: 1px; width: 6px; height: 4px;
  border-left: 1.5px solid var(--sk-surface); border-bottom: 1.5px solid var(--sk-surface);
  transform: rotate(-45deg);
}
.sk-task-main { flex: 1; min-width: 0; }
.sk-task-title { font-size: var(--sk-font-size-base); font-weight: 600; }
.is-done .sk-task-title { text-decoration: line-through; color: var(--sk-text-faint); }
.sk-task-meta {
  display: flex; align-items: center; gap: 4px; flex-wrap: wrap;
  font-size: var(--sk-font-size-xs); color: var(--sk-text-faint); margin-top: 2px;
}
</style>

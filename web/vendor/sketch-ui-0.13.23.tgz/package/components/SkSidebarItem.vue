<template>
  <div
    class="sk-sidebar-item"
    :class="{ 'is-active': active, 'is-collapsed': collapsed }"
    :title="collapsed ? String(label ?? '') : undefined"
    role="menuitem"
    :aria-current="active ? 'page' : undefined"
    @click="$emit('click')"
  >
    <span v-if="checkmark" class="sk-sidebar-item-check" aria-hidden="true">{{ active ? '✓' : '' }}</span>
    <component :is="icon" v-if="icon" class="sk-sidebar-item-icon" aria-hidden="true" />
    <span class="sk-sidebar-item-label"><slot>{{ label }}</slot></span>
    <span v-if="badge != null && !collapsed" class="sk-sidebar-item-badge">{{ badge }}</span>
    <span v-else-if="badge != null && collapsed" class="sk-sidebar-item-badge is-dot"></span>
  </div>
</template>

<script setup lang="ts">
/**
 * 侧边栏导航项：icon + 文案 + 可选徽标计数（7/8.html Orders 12）；
 * checkmark 为纸系主题的对勾小方框（1.html nav-checkbox）；
 * 折叠时仅显示图标（徽标退化为圆点），title 提示全名。
 */
import { inject, ref, type Ref, type Component } from 'vue'

defineProps<{
  label?: string
  icon?: Component
  badge?: string | number
  active?: boolean
  checkmark?: boolean
}>()
defineEmits<{ (e: 'click'): void }>()

const collapsed = inject<Ref<boolean>>('skSidebarCollapsed', ref(false))
</script>

<style>
.sk-sidebar-item {
  display: flex; align-items: center; gap: 7px;
  padding: 7px 12px 7px 9px; font-size: var(--sk-font-size-sm);
  cursor: pointer; border-left: 3px solid transparent;
  color: var(--sk-sidebar-fg); user-select: none; white-space: nowrap;
  overflow: hidden;
}
.sk-sidebar-item:hover { background: var(--sk-sidebar-hover); }
.sk-sidebar-item.is-active {
  background: var(--sk-sidebar-active-bg); border-left-color: var(--sk-sidebar-active-line);
  color: var(--sk-sidebar-active-fg); font-weight: 600;
}
.sk-sidebar-item-icon { width: 14px; height: 14px; color: var(--sk-sidebar-muted); flex-shrink: 0; }
.sk-sidebar-item.is-active .sk-sidebar-item-icon { color: var(--sk-sidebar-active-fg); }
.sk-sidebar-item-label { flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; }
.sk-sidebar-item-badge {
  font-size: var(--sk-font-size-xs); padding: 0 6px; border-radius: 999px; flex-shrink: 0;
  background: var(--sk-primary); color: var(--sk-on-primary); line-height: 16px;
}
.sk-sidebar-item-badge.is-dot { width: 6px; height: 6px; padding: 0; flex: 0 0 6px; line-height: 0; }
.sk-sidebar-item-check {
  width: 12px; height: 12px; border: 1.5px solid var(--sk-sidebar-muted); flex-shrink: 0;
  border-radius: var(--sk-radius-btn, var(--sk-radius)); display: inline-flex;
  align-items: center; justify-content: center; font-size: 9px; line-height: 1;
  background: var(--sk-sidebar-bg); color: var(--sk-sidebar-active-line);
}
.sk-sidebar-item.is-active .sk-sidebar-item-check { background: var(--sk-sidebar-active-line); color: var(--sk-surface); }
.sk-sidebar-item.is-collapsed { justify-content: center; padding-inline: 0; }
.sk-sidebar-item.is-collapsed .sk-sidebar-item-label { display: none; }
.sk-sidebar-item.is-collapsed .sk-sidebar-item-check { display: none; }
</style>

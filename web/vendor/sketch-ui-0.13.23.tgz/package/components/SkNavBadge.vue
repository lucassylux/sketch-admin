<template>
  <span class="sk-navbadge" :class="{ 'is-warn': warn }">{{ count }}</span>
</template>

<script setup lang="ts">
/** 导航计数徽章（2/3/4.html nav-badge）：深底反白圆角胶囊；warn 为弱化灰。 */
defineProps<{ count: number | string; warn?: boolean }>()
</script>

<style>
.sk-navbadge {
  font-size: var(--sk-font-size-xs);
  background: var(--sk-ink); color: var(--sk-surface);
  border-radius: var(--sk-radius-pill); padding: 1px 6px;
  line-height: 1.5; flex-shrink: 0;
}
.sk-navbadge.is-warn { background: var(--sk-text-muted); }
</style>

<template>
  <span ref="triggerRef" class="sk-popconfirm-trigger" @click.stop="toggle">
    <slot />
  </span>
  <Teleport to="body">
    <div v-if="open" ref="popRef" class="sk-popconfirm" :style="pos" @click.stop>
      <div class="sk-popconfirm-title">{{ title }}</div>
      <div class="sk-popconfirm-ops">
        <button type="button" class="sk-btn sk-btn-sm" @click="close">取消</button>
        <button type="button" class="sk-btn sk-btn-sm" :class="danger ? 'sk-btn-danger' : 'sk-btn-primary'" @click="confirm">
          {{ confirmText }}
        </button>
      </div>
    </div>
  </Teleport>
</template>

<script setup lang="ts">
/**
 * 气泡确认框：轻量危险操作二次确认；确认/取消后关闭，confirm 事件交给业务。
 */
import { nextTick, onBeforeUnmount, ref } from 'vue'

withDefaults(
  defineProps<{
    title: string
    confirmText?: string
    danger?: boolean
  }>(),
  { confirmText: '确定' },
)
const emit = defineEmits<{ confirm: [] }>()

const open = ref(false)
const triggerRef = ref<HTMLElement>()
const popRef = ref<HTMLElement>()
const pos = ref<{ left: string; top: string }>({ left: '0px', top: '0px' })

async function toggle() {
  open.value ? close() : await show()
}
async function show() {
  open.value = true
  await nextTick()
  const rect = triggerRef.value?.getBoundingClientRect()
  const popW = popRef.value?.offsetWidth ?? 200
  const popH = popRef.value?.offsetHeight ?? 0
  if (!rect) return
  let left = rect.left
  if (left + popW + 8 > window.innerWidth) left = Math.max(8, window.innerWidth - popW - 8)
  let top = rect.bottom + 6
  // 下方空间不足时向上弹出
  if (top + popH > window.innerHeight - 8) top = Math.max(8, rect.top - popH - 6)
  pos.value = { left: `${Math.round(left)}px`, top: `${Math.round(top)}px` }
  document.addEventListener('mousedown', onDocDown, true)
  window.addEventListener('scroll', close, true)
  window.addEventListener('resize', close)
}
function close() {
  if (!open.value) return
  open.value = false
  document.removeEventListener('mousedown', onDocDown, true)
  window.removeEventListener('scroll', close, true)
  window.removeEventListener('resize', close)
}
function onDocDown(e: MouseEvent) {
  const t = e.target as Node
  if (popRef.value?.contains(t) || triggerRef.value?.contains(t)) return
  close()
}
function confirm() {
  close()
  emit('confirm')
}
onBeforeUnmount(close)
</script>

<style>
.sk-popconfirm-trigger { display: inline-flex; }
.sk-popconfirm {
  position: fixed; z-index: 2100; max-width: 280px; padding: 10px 12px;
  background: var(--sk-surface); border: var(--sk-border); border-radius: var(--sk-radius-card, var(--sk-radius));
  box-shadow: var(--sk-shadow-overlay);
}
.sk-popconfirm-title { font-size: var(--sk-font-size-sm); color: var(--sk-text); line-height: 1.6; margin-bottom: 8px; }
.sk-popconfirm-ops { display: flex; justify-content: flex-end; gap: 8px; }
</style>

<template>
  <div class="sk-annotation"><slot /></div>
</template>

<script setup lang="ts">
/** 批注行：↳ 前缀的弱化说明文字。 */
</script>

<style>
.sk-annotation {
  font-size: var(--sk-font-size-xs); color: var(--sk-text-faint);
  font-style: italic; margin-top: 4px;
  display: flex; align-items: center; gap: 5px;
}
.sk-annotation::before { content: '↳'; color: var(--sk-line-faint); }
</style>

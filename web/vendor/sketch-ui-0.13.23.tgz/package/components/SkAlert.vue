<template>
  <div class="sk-alert" :class="`sk-alert-${tone}`">
    <span class="sk-alert-icon" aria-hidden="true">{{ glyph[tone] }}</span>
    <div class="sk-alert-text"><slot /></div>
    <span v-if="count != null" class="sk-alert-count">{{ count }}</span>
  </div>
</template>

<script setup lang="ts">
/** 横幅告警条（2.html alert-banner）：图标 + 文案 + 可选计数角标。 */
withDefaults(
  defineProps<{
    tone?: 'warning' | 'info' | 'success' | 'danger'
    count?: number | string
  }>(),
  { tone: 'warning' },
)
const glyph = { warning: '!', info: 'i', success: '✓', danger: '✕' } as Record<string, string>
</script>

<style>
.sk-alert {
  display: flex; align-items: center; gap: 10px;
  padding: 9px 14px; border-radius: var(--sk-radius-card, var(--sk-radius));
  /* 单行盒高锁整数（边框3+内距18+内容20=41）：字形度量会把盒子撑出小数，
   * 页签在提示条下方时会继承这个亚像素相位（接入文档页实录），任意缩放下线粗不一致 */
  min-height: 41px;
  border: 1.5px solid var(--sk-warning-line); background: var(--sk-warning-soft2);
  font-size: var(--sk-font-size-base); color: var(--sk-text);
}
.sk-alert-icon {
  width: 18px; height: 18px; border-radius: 50%; flex-shrink: 0;
  border: 2px solid currentColor; display: inline-flex; align-items: center; justify-content: center;
  font-size: 11px; font-weight: 900;
}
.sk-alert-icon {
  /* 图标是文字字形（i/!），默认行高≈21.6 小数会撑高整条；盒高锁 20 与文本行高对齐 */
  height: 20px; line-height: 1; display: inline-flex; align-items: center; justify-content: center;
}
.sk-alert-text { flex: 1; line-height: 20px; } /* 整数行高：不把下方元素推进亚像素相位 */
.sk-alert-count {
  font-size: var(--sk-font-size-xs); padding: 1px 6px; border-radius: var(--sk-radius-card, var(--sk-radius));
  background: var(--sk-ink); color: var(--sk-surface); flex-shrink: 0;
}
.sk-alert-info { border-color: var(--sk-info-line); background: var(--sk-info-soft2); }
.sk-alert-success { border-color: var(--sk-success-line); background: var(--sk-success-soft2); }
.sk-alert-danger { border-color: var(--sk-danger-line); background: var(--sk-danger-soft2); }
</style>

<template>
  <aside
    class="sk-sidebar"
    :class="{ 'is-collapsed': collapsed }"
    :style="{ width: (collapsed ? collapsedWidth : width) + 'px' }"
  >
    <div class="sk-sidebar-top">
      <div v-if="$slots.brand" class="sk-sidebar-brand">
        <slot name="brand" />
      </div>
    </div>
    <div class="sk-sidebar-body">
      <slot />
    </div>
    <div class="sk-sidebar-bottom">
      <div v-if="$slots.footer" class="sk-sidebar-foot">
        <slot name="footer" />
      </div>
      <button
        v-if="collapsible"
        type="button"
        class="sk-sidebar-toggle"
        :title="collapsed ? '展开侧栏' : '收起侧栏'"
        :aria-expanded="!collapsed"
        @click="toggle"
      >
        <component :is="collapsed ? SkIconPanelOpen : SkIconPanelClose" class="sk-sidebar-toggle-icon" />
        <span v-if="!collapsed" class="sk-sidebar-toggle-text">收起</span>
      </button>
    </div>
  </aside>
</template>

<script setup lang="ts">
/**
 * 侧边栏容器（1~8.html sidebar 的抽象）：
 * - 插槽：#brand 品牌区 / 默认（SkSidebarGroup + SkSidebarItem）/ #footer 底部用户区（自动沉底）
 * - 折叠：v-model:collapsed + collapsible（底部内置收起/展开按钮，5.html 形态）；
 *   品牌文案用 .sk-sidebar-brand-text、用户区用 .sk-sidebar-user、图标按钮用 .sk-sidebar-tool，
 *   折叠态自动隐藏文字只留图标 —— 应用层零自定义 CSS。
 * - 视觉全部走 --sk-sidebar-* 主题 token。
 */
import { provide, ref, watch } from 'vue'
import { SkIconPanelClose, SkIconPanelOpen } from '../icons'

const props = withDefaults(
  defineProps<{
    width?: number
    collapsedWidth?: number
    collapsed?: boolean
    collapsible?: boolean
  }>(),
  { width: 200, collapsedWidth: 60, collapsed: false, collapsible: false },
)
const emit = defineEmits<{ (e: 'update:collapsed', v: boolean): void }>()

const collapsedRef = ref(props.collapsed)
provide('skSidebarCollapsed', collapsedRef)

function toggle() {
  collapsedRef.value = !collapsedRef.value
  emit('update:collapsed', collapsedRef.value)
}
/** 受控同步：外部改 props.collapsed 时跟随 */
watch(() => props.collapsed, v => (collapsedRef.value = v))
</script>

<style>
.sk-sidebar {
  display: flex; flex-direction: column; flex-shrink: 0;
  background: var(--sk-sidebar-bg); color: var(--sk-sidebar-fg);
  border-right: var(--sk-sidebar-border);
  overflow-y: auto; overflow-x: hidden;
  transition: width 0.18s ease;
}
.sk-sidebar-top { display: flex; align-items: center; gap: 4px; }
.sk-sidebar-brand {
  flex: 1; min-width: 0;
  padding: 10px 12px; display: flex; align-items: center; gap: 8px;
  border-bottom: var(--sk-border-divider); margin-bottom: 6px;
  font-weight: 700; font-size: var(--sk-font-size-md);
  white-space: nowrap; overflow: hidden; cursor: pointer;
}
/* 品牌文案：折叠态自动隐藏（应用直接写 <span class="sk-sidebar-brand-text">） */
.sk-sidebar.is-collapsed .sk-sidebar-brand { justify-content: center; padding-inline: 0; }
.sk-sidebar.is-collapsed .sk-sidebar-brand-text { display: none; }
.sk-sidebar-body { display: flex; flex-direction: column; flex: 1; min-height: 0; }
/* 底部区沉底：footer 插槽内容 + 折叠按钮共用一条分隔线；列布局使折叠钮恒居中 */
.sk-sidebar-bottom { margin-top: auto; border-top: var(--sk-border-divider); display: flex; flex-direction: column; align-items: center; padding: 6px 0 10px; }
.sk-sidebar-foot {
  align-self: stretch;
  padding: 10px 10px 6px; display: flex; align-items: center; gap: 6px;
}
.sk-sidebar.is-collapsed .sk-sidebar-foot { flex-direction: column; gap: 8px; }

/* ── 折叠按钮（collapsible）：沉底恒居中；展开态图标+「收起」文字胶囊，折叠态仅图标 ── */
.sk-sidebar-toggle {
  flex-shrink: 0; margin: 0 auto; padding: 0 8px; gap: 6px;
  min-width: 24px; height: 24px; width: auto;
  display: inline-flex; align-items: center; justify-content: center;
  border: var(--sk-border-input); border-radius: var(--sk-radius-btn, var(--sk-radius));
  background: var(--sk-sidebar-hover); color: var(--sk-sidebar-muted); cursor: pointer;
}
.sk-sidebar-toggle:hover { color: var(--sk-sidebar-fg); }
.sk-sidebar-toggle-icon { width: 13px; height: 13px; }
.sk-sidebar-toggle-text { font-size: var(--sk-font-size-xs); letter-spacing: 0.05em; }
.sk-sidebar.is-collapsed .sk-sidebar-top { flex-direction: column; }

/* ── 用户区（#footer 内现成行）：头像 + 昵称 + 下拉箭头，折叠只留头像 ── */
.sk-sidebar-user {
  flex: 1; min-width: 0; display: flex; align-items: center; gap: 6px;
  padding: 4px 6px; cursor: pointer;
  border: 1px solid transparent; border-radius: var(--sk-radius-btn, var(--sk-radius));
}
.sk-sidebar-user:hover { background: var(--sk-sidebar-hover); border-color: var(--sk-line-faint); }
.sk-sidebar-user-name {
  flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
  font-size: var(--sk-font-size-xs);
}
.sk-sidebar-user-caret { width: 11px; height: 11px; color: var(--sk-sidebar-muted); flex-shrink: 0; }
.sk-sidebar.is-collapsed .sk-sidebar-user { justify-content: center; padding-inline: 0; }
.sk-sidebar.is-collapsed .sk-sidebar-user > :not(.sk-avatar) { display: none; }

/* ── 工具按钮（#footer 内图标按钮，如主题切换） ── */
.sk-sidebar-tool {
  height: 26px; padding: 0 5px; flex-shrink: 0;
  display: inline-flex; align-items: center; gap: 1px;
  border: var(--sk-border-input); border-radius: var(--sk-radius-btn, var(--sk-radius));
  background: var(--sk-sidebar-hover); color: var(--sk-sidebar-muted); cursor: pointer;
}
.sk-sidebar-tool:hover { color: var(--sk-sidebar-fg); box-shadow: var(--sk-shadow-press); }
.sk-sidebar-tool .sk-icon { width: 14px; height: 14px; }
</style>

<template>
  <span class="sk-priority-dot" :class="`sk-priority-${level}`" :title="title || level" aria-hidden="true"></span>
</template>

<script setup lang="ts">
/** 优先级圆点（3.html priority-dot）：high 红 / mid 黄 / low 绿。 */
withDefaults(
  defineProps<{ level?: 'high' | 'mid' | 'low'; title?: string }>(),
  { level: 'mid' },
)
</script>

<style>
.sk-priority-dot {
  width: 8px; height: 8px; border-radius: 50%; display: inline-block;
  border: 1.5px solid var(--sk-line-input); vertical-align: middle; flex-shrink: 0;
}
.sk-priority-high { background: var(--sk-danger-soft2); border-color: var(--sk-danger); }
.sk-priority-mid { background: var(--sk-warning-soft2); border-color: var(--sk-warning); }
.sk-priority-low { background: var(--sk-success-soft2); border-color: var(--sk-success); }
</style>

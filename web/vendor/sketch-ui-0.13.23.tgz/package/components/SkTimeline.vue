<template>
  <div class="sk-timeline">
    <div v-for="(item, i) in items" :key="i" class="sk-timeline-item">
      <div class="sk-timeline-dot" :class="`sk-timeline-dot-${item.state || 'done'}`">
        {{ dotChar(item.state) }}
      </div>
      <div class="sk-timeline-content" :class="{ 'is-pending': item.state === 'pending' }">
        <div class="sk-timeline-title" :class="{ 'is-current': item.state === 'current' }">{{ item.title }}</div>
        <div v-if="item.meta" class="sk-timeline-meta">{{ item.meta }}</div>
        <slot name="extra" :item="item" :index="i" />
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
/**
 * 时间线（对应线框稿 timeline）：虚线连接线 + 状态点。
 * state：done ✓（实心）/ current ⬤（黄）/ pending ○（空心灰）/ error !（红）。
 */
export interface SkTimelineItem {
  state?: 'done' | 'current' | 'pending' | 'error'
  title: string
  meta?: string
}

defineProps<{ items: SkTimelineItem[] }>()

function dotChar(state?: string) {
  switch (state) {
    case 'current': return '⬤'
    case 'pending': return '○'
    case 'error': return '!'
    default: return '✓'
  }
}
</script>

<style>
.sk-timeline { padding: 6px 0; }
.sk-timeline-item { display: flex; gap: 12px; margin-bottom: 14px; position: relative; }
.sk-timeline-item:last-child { margin-bottom: 0; }
.sk-timeline-item:not(:last-child)::before {
  content: ''; position: absolute; left: 9px; top: 22px; width: 1.5px; height: calc(100% - 12px);
  background: repeating-linear-gradient(to bottom, var(--sk-line-faint) 0px, var(--sk-line-faint) 4px, transparent 4px, transparent 8px);
}
.sk-timeline-dot {
  width: 20px; height: 20px; border: 2px solid var(--sk-ink); border-radius: 50%;
  background: var(--sk-surface); color: var(--sk-on-primary);
  display: flex; align-items: center; justify-content: center;
  font-size: 9px; flex-shrink: 0; position: relative; z-index: 1;
}
.sk-timeline-dot-done { background: var(--sk-ink); color: var(--sk-on-primary); }
.sk-timeline-dot-current { background: var(--sk-accent); border-color: var(--sk-accent-line); color: var(--sk-accent-line); font-size: 8px; }
.sk-timeline-dot-pending { color: var(--sk-line-faint); }
.sk-timeline-dot-error { background: var(--sk-danger); border-color: var(--sk-danger); color: var(--sk-surface); }
.sk-timeline-content { flex: 1; min-width: 0; }
.sk-timeline-title { font-size: var(--sk-font-size-base); font-weight: 600; margin-bottom: 2px; }
.sk-timeline-title.is-current { color: var(--sk-accent-line); }
.sk-timeline-meta { font-size: var(--sk-font-size-xs); color: var(--sk-text-faint); line-height: 1.6; }
.sk-timeline-content.is-pending { opacity: 0.55; }
</style>

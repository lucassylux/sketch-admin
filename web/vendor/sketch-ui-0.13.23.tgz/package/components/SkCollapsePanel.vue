<template>
  <div class="sk-collapse-p" :class="{ 'is-open': localOpen }">
    <button type="button" class="sk-collapse-p-head" :aria-expanded="localOpen" @click="toggle">
      <span class="sk-collapse-p-arrow" aria-hidden="true">›</span>
      <span class="sk-collapse-p-title">{{ header }}</span>
      <slot name="extra" />
    </button>
    <div v-show="localOpen" class="sk-collapse-p-body">
      <slot />
    </div>
  </div>
</template>

<script setup lang="ts">
/**
 * 折叠面板内容：作为 SkCollapse 子组件使用。
 * 也支持独立使用（v-model:open 控制自身开合）。
 */
import { ref, watch } from 'vue'

const props = withDefaults(
  defineProps<{
    header?: string
    open?: boolean
    disabled?: boolean
  }>(),
  { open: false },
)
const emit = defineEmits<{ 'update:open': [v: boolean] }>()

const localOpen = ref(props.open)
watch(() => props.open, (v) => (localOpen.value = v))

function toggle() {
  if (props.disabled) return
  localOpen.value = !localOpen.value
  emit('update:open', localOpen.value)
}
</script>

<style>
.sk-collapse-p { border: var(--sk-border-thin); border-radius: var(--sk-radius-card, var(--sk-radius)); background: var(--sk-surface); overflow: hidden; }
.sk-collapse-p-head {
  width: 100%; display: flex; align-items: center; gap: 8px;
  padding: 9px 12px; cursor: pointer; border: none; background: none;
  font-family: var(--sk-font); font-size: var(--sk-font-size-base); color: var(--sk-text); text-align: left;
}
.sk-collapse-p-head:hover { background: var(--sk-hover); }
.sk-collapse-p-arrow { display: inline-block; transition: transform 0.18s; color: var(--sk-text-faint); font-size: 13px; }
.sk-collapse-p.is-open .sk-collapse-p-arrow { transform: rotate(90deg); }
.sk-collapse-p-title { font-weight: 600; flex: 1; min-width: 0; }
.sk-collapse-p-body { padding: 4px 12px 12px; border-top: var(--sk-border-divider); }
</style>

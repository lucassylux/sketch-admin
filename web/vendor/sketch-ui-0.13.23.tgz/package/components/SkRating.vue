<template>
  <div class="sk-rating" :class="{ 'is-readonly': readonly }" role="radiogroup" :aria-label="ariaLabel">
    <button
      v-for="n in max"
      :key="n"
      type="button"
      class="sk-rating-star"
      :class="{ 'is-on': n <= modelValue, 'is-half': halfAt === n }"
      :style="{ width: size + 'px', height: size + 'px' }"
      :tabindex="readonly ? -1 : 0"
      :aria-checked="n <= modelValue"
      @click="pick(n)"
      @mousemove="hovering = n"
      @mouseleave="hovering = 0"
    >
      <svg viewBox="0 0 24 24" fill="none">
        <path d="M12 2.6l2.9 5.9 6.5.9-4.7 4.6 1.1 6.5L12 17.4l-5.8 3.1 1.1-6.5L2.6 9.4l6.5-.9L12 2.6z" />
      </svg>
    </button>
    <span v-if="text" class="sk-rating-text">{{ text }}</span>
  </div>
</template>

<script setup lang="ts">
/**
 * 星级评分（8.html Reviews 评论星级）：
 * 点击打分（v-model:modelValue），readonly 只读展示；支持半星（allowHalf + .5 步进）。
 */
import { computed, ref } from 'vue'

const props = withDefaults(
  defineProps<{
    modelValue: number
    max?: number
    size?: number
    readonly?: boolean
    allowHalf?: boolean
    text?: string
    ariaLabel?: string
  }>(),
  { max: 5, size: 16, readonly: false, allowHalf: false, ariaLabel: '评分' },
)
const emit = defineEmits<{ (e: 'update:modelValue', v: number): void }>()

const hovering = ref(0)

const halfAt = computed(() => {
  if (!props.allowHalf) return 0
  const v = props.modelValue
  return v % 1 !== 0 ? Math.ceil(v) : 0
})

function pick(n: number) {
  if (props.readonly) return
  emit('update:modelValue', n)
}
</script>

<style>
.sk-rating { display: inline-flex; align-items: center; gap: 2px; }
.sk-rating-star {
  display: inline-flex; padding: 0; border: none; background: none; cursor: pointer;
  color: var(--sk-muted-line); border-radius: 2px;
}
.sk-rating-star svg { width: 100%; height: 100%; stroke: currentColor; stroke-width: 1.6; fill: none; }
.sk-rating-star.is-on { color: var(--sk-warning); }
.sk-rating-star.is-on svg path { fill: currentColor; }
.sk-rating-star.is-half { color: var(--sk-warning); }
.sk-rating-star.is-half svg path { fill: var(--sk-warning); opacity: 0.45; }
.sk-rating.is-readonly .sk-rating-star { cursor: default; }
.sk-rating-star:not(.is-on):hover svg path { fill: var(--sk-warning); opacity: 0.3; }
.sk-rating-text { margin-left: 6px; font-size: var(--sk-font-size-sm); color: var(--sk-text-muted); }
</style>

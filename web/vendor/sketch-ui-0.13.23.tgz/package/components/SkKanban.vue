<template>
  <div class="sk-kanban">
    <div v-for="col in columns" :key="col.title" class="sk-kanban-col">
      <div class="sk-kanban-head">
        <span class="sk-kanban-title">{{ col.title }}</span>
        <span class="sk-kanban-count">{{ col.cards.length }}</span>
      </div>
      <div
        v-for="(card, i) in col.cards"
        :key="i"
        class="sk-kanban-card"
        :class="{ 'is-highlight': card.highlight }"
        @click="$emit('cardClick', col, card)"
      >
        <div class="sk-kanban-card-title">
          <SkPriorityDot v-if="card.priority" :level="card.priority" />
          {{ card.title }}
        </div>
        <div v-if="card.meta" class="sk-kanban-card-meta">{{ card.meta }}</div>
      </div>
      <button type="button" class="sk-kanban-add" @click="$emit('add', col)">+ 添加卡片</button>
    </div>
  </div>
</template>

<script setup lang="ts">
/** 看板（3.html kanban-board）：虚线列 + 卡片（悬停投影加深）+ 加卡占位。 */
import SkPriorityDot from './SkPriorityDot.vue'

export interface SkKanbanCard {
  title: string
  meta?: string
  highlight?: boolean
  priority?: 'high' | 'mid' | 'low'
}
export interface SkKanbanColumn {
  title: string
  cards: SkKanbanCard[]
}

defineProps<{ columns: SkKanbanColumn[] }>()
defineEmits<{
  add: [col: SkKanbanColumn]
  cardClick: [col: SkKanbanColumn, card: SkKanbanCard]
}>()
</script>

<style>
.sk-kanban { display: flex; gap: 12px; overflow-x: auto; padding-bottom: 8px; }
.sk-kanban-col {
  min-width: 186px; max-width: 186px; flex-shrink: 0;
  border: 2px dashed var(--sk-line-faint); border-radius: var(--sk-radius);
  background: var(--sk-surface-alt); padding: 10px 8px;
}
.sk-kanban-head {
  display: flex; align-items: center; justify-content: space-between;
  margin-bottom: 8px; border-bottom: 2px solid var(--sk-line-cell); padding-bottom: 5px;
}
.sk-kanban-title {
  font-size: var(--sk-font-size-xs); font-weight: 700;
  text-transform: uppercase; letter-spacing: 0.08em; color: var(--sk-text-muted);
}
.sk-kanban-count {
  font-size: var(--sk-font-size-xs); background: var(--sk-muted-soft2);
  border: 1px solid var(--sk-line-faint); border-radius: var(--sk-radius-pill);
  padding: 0 5px; color: var(--sk-text-muted);
}
.sk-kanban-card {
  background: var(--sk-surface); border: 1.5px solid var(--sk-line-faint);
  border-radius: var(--sk-radius); padding: 8px 9px; margin-bottom: 7px;
  cursor: pointer; box-shadow: var(--sk-shadow-pop); transition: box-shadow 0.12s;
}
.sk-kanban-card:hover { box-shadow: var(--sk-shadow-press); }
.sk-kanban-card.is-highlight { background: var(--sk-accent-faint); }
.sk-kanban-card-title {
  font-size: var(--sk-font-size-base); font-weight: 600;
  display: flex; align-items: center; gap: 5px;
}
.sk-kanban-card-meta {
  font-size: var(--sk-font-size-xs); color: var(--sk-text-faint); margin-top: 3px;
}
.sk-kanban-add {
  width: 100%; font-family: var(--sk-font); font-size: var(--sk-font-size-xs);
  color: var(--sk-text-faint); text-align: center;
  border: 1.5px dashed var(--sk-line-cell); border-radius: var(--sk-radius);
  padding: 5px; cursor: pointer; background: transparent; margin-top: 2px;
}
.sk-kanban-add:hover { background: var(--sk-hover); color: var(--sk-text-muted); }
</style>

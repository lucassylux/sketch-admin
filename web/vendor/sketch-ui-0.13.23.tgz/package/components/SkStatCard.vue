<template>
  <div class="sk-stat" :class="{ 'is-clickable': clickable }" @click="clickable && $emit('click')">
    <div class="sk-stat-label">{{ label }}</div>
    <div class="sk-stat-value">{{ value }}</div>
    <div v-if="sub || $slots.sub" class="sk-stat-sub"><slot name="sub">{{ sub }}</slot></div>
    <span v-if="badge" class="sk-stat-badge" :class="`sk-stat-badge-${tone}`">{{ badge }}</span>
  </div>
</template>

<script setup lang="ts">
/**
 * 指标卡（对应线框稿 kpi-card）：label/value/sub + 右上角状态角标。
 */
withDefaults(
  defineProps<{
    label: string
    value: string | number
    sub?: string
    badge?: string
    tone?: 'success' | 'warning' | 'danger' | 'info' | 'muted'
    clickable?: boolean
  }>(),
  { tone: 'muted' },
)
defineEmits<{ click: [] }>()
</script>

<style>
.sk-stat {
  position: relative; border: var(--sk-border); border-radius: var(--sk-radius-card, var(--sk-radius));
  background: var(--sk-surface); padding: 12px 14px;
}
.sk-stat.is-clickable { cursor: pointer; }
.sk-stat.is-clickable:hover { box-shadow: var(--sk-shadow-press); transform: translate(-1px, -1px); }
.sk-stat-label {
  font-size: var(--sk-font-size-xs); color: var(--sk-text-muted);
  text-transform: uppercase; letter-spacing: 0.08em; margin-bottom: 6px;
}
.sk-stat-value { font-size: var(--sk-font-size-num); font-weight: 700; line-height: 1; }
.sk-stat-sub { font-size: var(--sk-font-size-xs); color: var(--sk-text-faint); margin-top: 4px; }
.sk-stat-badge {
  position: absolute; top: 6px; right: 6px;
  font-size: var(--sk-font-size-xs); padding: 1px 5px;
  border: 1px solid currentColor; border-radius: var(--sk-radius-card, var(--sk-radius));
}
.sk-stat-badge-success { color: var(--sk-success); background: var(--sk-success-soft); }
.sk-stat-badge-warning { color: var(--sk-warning); background: var(--sk-warning-soft2); }
.sk-stat-badge-danger { color: var(--sk-danger); background: var(--sk-danger-soft2); }
.sk-stat-badge-info { color: var(--sk-info); background: var(--sk-info-soft); }
.sk-stat-badge-muted { color: var(--sk-muted); background: var(--sk-muted-soft); }
</style>

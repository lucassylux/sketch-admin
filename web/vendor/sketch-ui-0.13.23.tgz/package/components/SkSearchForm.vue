<template>
  <SkForm class="sk-search-form" :style="vars" @submit.prevent>
    <slot />
  </SkForm>
</template>

<script setup lang="ts">
/**
 * 搜索表单容器（管理后台列表页搜索区）：
 *  - 子项用 <SkFormField label="xx"> 平铺传入，响应式网格（minCol 起自动填充列数）、装不下自动换行
 *  - 无 label 的子项（通常是查询/重置按钮组）在格子内沉底，与相邻字段"控件底边"对齐
 *  - 窄屏自动切两列紧凑布局
 * 数值可配（minCol/gap/rowGap），缺省为通用默认。
 */
import { computed } from 'vue'
import SkForm from './SkForm.vue'

const props = withDefaults(
  defineProps<{
    /** 单列最小宽（px）：决定一行放几列 */
    minCol?: number
    /** 列间距（px） */
    gap?: number
    /** 行间距（px） */
    rowGap?: number
  }>(),
  { minCol: 220, gap: 24, rowGap: 12 },
)

const vars = computed(() => ({
  '--sk-search-min-col': props.minCol + 'px',
  '--sk-search-gap': props.gap + 'px',
  '--sk-search-row-gap': props.rowGap + 'px',
}))
</script>

<style>
.sk-search-form {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(var(--sk-search-min-col, 220px), 1fr));
  gap: var(--sk-search-row-gap, 12px) var(--sk-search-gap, 24px);
  margin-bottom: 12px;
}
.sk-search-form .sk-field { min-width: 0; }
/* 无 label 项（按钮组）：网格默认拉伸行高，沉底后与带 label 项的控件底边对齐 */
.sk-search-form .sk-field:not(:has(> .sk-field-label)) { justify-content: flex-end; }
/* 窄屏两列紧凑：一行一项太占竖向空间；按钮项跟随第二列沉底 */
@media (max-width: 768px) {
  .sk-search-form { grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 10px 12px; }
}
</style>

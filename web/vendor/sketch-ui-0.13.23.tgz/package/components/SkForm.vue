<template>
  <form class="sk-form" @submit.prevent="$emit('submit')">
    <slot />
  </form>
</template>

<script setup lang="ts">
/**
 * 表单容器：收集子 SkFormField，提供 validate/clearValidate。
 * 轻量校验：required / min / max / pattern / validator（触发时机 blur + 整体 validate）。
 */
import { provide } from 'vue'

export interface SkFormRule {
  required?: boolean
  min?: number
  max?: number
  pattern?: RegExp
  /** 自定义校验：入参为控件当前值，返回错误文案（不合规）或 null（通过） */
  validator?: (value: string) => string | null
  message: string
}

interface FieldCtx {
  name: string
  validate: () => string | null
  clear: () => void
}

// 字段表必须是普通数组（不能用 ref）：深响应式会代理数组元素，读出来的是
// 代理对象，unregister 按原始对象恒不相等 → 卸载的字段永远注销不掉
// （僵尸字段把后续 validate 全部拦下）。该表只在 validate/clearValidate
// 调用时读取，无模板依赖，不需要响应式。
const fields: FieldCtx[] = []
provide('sk-form', {
  register(f: FieldCtx) {
    fields.push(f)
  },
  unregister(f: FieldCtx) {
    const i = fields.indexOf(f)
    if (i >= 0) fields.splice(i, 1)
  },
})

async function validate(): Promise<void> {
  const errors = fields.map(f => f.validate()).filter(Boolean) as string[]
  if (errors.length) throw new Error(errors[0])
}
function clearValidate() {
  fields.forEach(f => f.clear())
}
defineExpose({ validate, clearValidate })
defineEmits<{ submit: [] }>()
</script>

<style>
.sk-form { display: flex; flex-direction: column; gap: 12px; }
</style>

<template>
  <label class="sk-checkbox" :class="{ 'is-disabled': disabled }">
    <input
      type="checkbox"
      :checked="!!modelValue"
      :disabled="disabled"
      @change="$emit('update:modelValue', ($event.target as HTMLInputElement).checked)"
    />
    <span v-if="$slots.default || label" class="sk-checkbox-label"><slot>{{ label }}</slot></span>
  </label>
</template>

<script setup lang="ts">
/**
 * 复选框：原生 checkbox + 主题 accent-color，文字走默认插槽或 label 属性。
 */
withDefaults(defineProps<{ modelValue?: boolean; label?: string; disabled?: boolean }>(), {})
defineEmits<{ 'update:modelValue': [v: boolean] }>()
</script>

<style>
.sk-checkbox {
  display: inline-flex; align-items: center; gap: 6px;
  font-family: var(--sk-font); font-size: var(--sk-font-size-sm); color: var(--sk-text);
  cursor: pointer; user-select: none;
}
.sk-checkbox input[type='checkbox'] {
  width: 13px; height: 13px; accent-color: var(--sk-primary); cursor: pointer; flex-shrink: 0;
}
.sk-checkbox.is-disabled { color: var(--sk-text-faint); cursor: not-allowed; }
.sk-checkbox.is-disabled input { cursor: not-allowed; }
</style>

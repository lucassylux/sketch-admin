<template>
  <span class="sk-input" :class="[sizeClass, { 'is-disabled': disabled }]">
    <input
      ref="el"
      class="sk-input-el"
      :class="{ 'sk-input-dashed': dashed }"
      :type="actualType"
      :value="modelValue"
      :placeholder="placeholder"
      :disabled="disabled"
      :readonly="readonly"
      :autocomplete="autocomplete"
      v-bind="attrs"
      @input="onInput"
    />
    <button v-if="clearable && modelValue && !disabled && !readonly" type="button" class="sk-input-clear" tabindex="-1"
      title="清空" @click="clear"
    >
      <SkIconClose />
    </button>
    <button v-if="type === 'password'" type="button" class="sk-input-eye" tabindex="-1"
      :title="showPwd ? '隐藏密码' : '显示密码'" @click="showPwd = !showPwd"
    >
      <SkIconEye v-if="showPwd" />
      <SkIconEyeOff v-else />
    </button>
  </span>
</template>

<script setup lang="ts">
/**
 * 输入框：type=text/password（带可见切换）；dashed 用于搜索/筛选场景；
 * clearable 显示清空钮；未列出的 attrs（placeholder/class/事件等）透传给内部 input。
 */
import { computed, ref, useAttrs } from 'vue'
import { SkIconClose, SkIconEye, SkIconEyeOff } from '../icons'

const props = withDefaults(
  defineProps<{
    modelValue?: string | number
    type?: string
    placeholder?: string
    size?: 'sm' | 'md' | 'lg'
    disabled?: boolean
    readonly?: boolean
    dashed?: boolean
    clearable?: boolean
    autocomplete?: string
  }>(),
  { type: 'text', size: 'md', autocomplete: 'off' },
)
const emit = defineEmits<{ 'update:modelValue': [v: string] }>()

const attrs = useAttrs()
const el = ref<HTMLInputElement>()
const showPwd = ref(false)
const actualType = computed(() => (props.type === 'password' && showPwd.value ? 'text' : props.type))
const sizeClass = computed(() => (props.size === 'md' ? '' : `sk-input-${props.size}`))

function onInput(e: Event) {
  emit('update:modelValue', (e.target as HTMLInputElement).value)
}
function clear() {
  emit('update:modelValue', '')
  el.value?.focus()
}
function focus() {
  el.value?.focus()
}
defineExpose({ focus })
</script>

<style>
.sk-input { position: relative; display: inline-flex; vertical-align: middle; }
.sk-input-el {
  width: 100%; min-width: 0;
  font-family: var(--sk-font); font-size: var(--sk-font-size-base); color: var(--sk-text);
  height: var(--sk-control-h); padding: 0 var(--sk-control-px);
  border: var(--sk-border-input); border-radius: var(--sk-radius-btn, var(--sk-radius));
  background: var(--sk-surface);
}
.sk-input-el::placeholder { color: var(--sk-text-faint); }
.sk-input-el:disabled, .sk-input.is-disabled .sk-input-el { background: var(--sk-muted-soft2); color: var(--sk-text-faint); cursor: not-allowed; }
.sk-input-dashed { border: var(--sk-border-input-dashed) !important; }
.sk-input-sm .sk-input-el { height: var(--sk-control-h-sm); font-size: var(--sk-font-size-sm); padding: 0 var(--sk-control-px-sm); }
.sk-input-lg .sk-input-el { height: var(--sk-control-h-lg); font-size: var(--sk-font-size-md); padding: 0 12px; }

.sk-input-clear, .sk-input-eye {
  position: absolute; right: 4px; top: 50%; transform: translateY(-50%);
  width: 20px; height: 20px; display: inline-flex; align-items: center; justify-content: center;
  border: none; background: transparent; color: var(--sk-text-faint); cursor: pointer; font-size: 13px;
  border-radius: var(--sk-radius-btn, var(--sk-radius));
}
.sk-input-clear:hover, .sk-input-eye:hover { color: var(--sk-text); background: var(--sk-hover); }
.sk-input .sk-input-el[type='password'], .sk-input .sk-input-el:has(+ .sk-input-clear), .sk-input .sk-input-el:has(+ .sk-input-eye) {
  padding-right: 26px;
}
</style>

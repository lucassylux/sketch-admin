<template>
  <div class="sk-chat-panel" :style="{ height: height + 'px' }">
    <div ref="listEl" class="sk-chat-panel-list">
      <div v-for="(m, i) in messages" :key="i" class="sk-chat-panel-row" :class="m.role === 'user' ? 'is-user' : 'is-ai'">
        <div v-if="m.role !== 'user'" class="sk-chat-panel-avatar" aria-hidden="true">
          <svg viewBox="0 0 24 24"><path d="M12 2a4 4 0 0 1 4 4v1h1a3 3 0 0 1 3 3v7a3 3 0 0 1-3 3H7a3 3 0 0 1-3-3v-7a3 3 0 0 1 3-3h1V6a4 4 0 0 1 4-4zm0 2a2 2 0 0 0-2 2v1h4V6a2 2 0 0 0-2-2z" /></svg>
        </div>
        <div class="sk-chat-panel-msg">
          <div class="sk-chat-panel-text">{{ m.text }}</div>
          <div v-if="m.time" class="sk-chat-panel-time">{{ m.time }}</div>
        </div>
      </div>
    </div>
    <div v-if="suggestions.length" class="sk-chat-panel-sugs">
      <button v-for="s in suggestions" :key="s" type="button" class="sk-chat-panel-sug" @click="$emit('suggestion', s)">{{ s }}</button>
    </div>
    <div class="sk-chat-panel-input">
      <input
        v-model="draft"
        class="sk-chat-panel-field"
        type="text"
        :placeholder="placeholder"
        @keydown.enter="send"
      />
      <button type="button" class="sk-chat-panel-send" :disabled="!draft.trim()" @click="send" aria-label="发送">
        <svg viewBox="0 0 24 24"><path d="M3 11.5 21 3l-8.5 18-2.4-7.1L3 11.5z" /></svg>
      </button>
    </div>
  </div>
</template>

<script setup lang="ts">
/**
 * AI 对话面板（5.html AI Insights：气泡 + 快捷指令 + 输入框）：
 * messages 驱动气泡列表（role: 'user' | 'ai'），输入回车或点发送 emit('send', text)。
 */
import { nextTick, ref, watch } from 'vue'

const props = withDefaults(
  defineProps<{
    messages: { role: 'user' | 'ai'; text: string; time?: string }[]
    suggestions?: string[]
    placeholder?: string
    height?: number
  }>(),
  { suggestions: () => [], placeholder: '输入问题…', height: 320 },
)
const emit = defineEmits<{ (e: 'send', v: string): void; (e: 'suggestion', v: string): void }>()

const draft = ref('')
const listEl = ref<HTMLElement | null>(null)

async function scrollBottom() {
  await nextTick()
  if (listEl.value) listEl.value.scrollTop = listEl.value.scrollHeight
}
watch(() => props.messages.length, scrollBottom)

function send() {
  const v = draft.value.trim()
  if (!v) return
  emit('send', v)
  draft.value = ''
}
</script>

<style>
.sk-chat-panel {
  display: flex; flex-direction: column;
  border: var(--sk-border); border-radius: var(--sk-radius-card, var(--sk-radius));
  background: var(--sk-surface); overflow: hidden;
}
.sk-chat-panel-list { flex: 1; overflow-y: auto; padding: 14px; display: flex; flex-direction: column; gap: 12px; }
.sk-chat-panel-row { display: flex; gap: 8px; align-items: flex-start; }
.sk-chat-panel-row.is-user { flex-direction: row-reverse; }
/* 头像与气泡首行文字光学对齐 */
.sk-chat-panel-avatar { margin-top: 2px; }
/* 气泡尾巴角：靠头像一侧的顶角收小 */
.is-ai .sk-chat-panel-text { border-top-left-radius: 3px; }
.is-user .sk-chat-panel-text { border-top-right-radius: 3px; }
.sk-chat-panel-avatar {
  width: 26px; height: 26px; flex-shrink: 0; border-radius: 999px;
  background: var(--sk-accent-soft); color: var(--sk-accent-line);
  display: flex; align-items: center; justify-content: center;
}
.sk-chat-panel-avatar svg { width: 14px; height: 14px; fill: currentColor; }
.sk-chat-panel-msg { max-width: 78%; }
.sk-chat-panel-text {
  padding: 8px 12px; border-radius: var(--sk-radius-card, var(--sk-radius)); font-size: var(--sk-font-size-base); line-height: 1.55;
  border: var(--sk-border-thin); background: var(--sk-muted-soft);
}
.is-user .sk-chat-panel-text { background: var(--sk-primary); color: var(--sk-on-primary); border-color: transparent; }
.sk-chat-panel-time { font-size: var(--sk-font-size-xs); color: var(--sk-text-faint); margin-top: 3px; }
.is-user .sk-chat-panel-time { text-align: right; }
.sk-chat-panel-sugs { display: flex; gap: 6px; flex-wrap: wrap; padding: 0 14px 10px; }
.sk-chat-panel-sug {
  font-size: var(--sk-font-size-xs); padding: 4px 10px; cursor: pointer;
  border: var(--sk-border-input); border-radius: 999px; background: var(--sk-surface);
  color: var(--sk-text-muted);
}
.sk-chat-panel-sug:hover { color: var(--sk-text); background: var(--sk-hover); }
.sk-chat-panel-input { display: flex; gap: 8px; padding: 10px 14px; border-top: var(--sk-border-divider); }
.sk-chat-panel-field {
  flex: 1; height: var(--sk-control-h); padding: 0 12px;
  border: var(--sk-border-input); border-radius: var(--sk-radius-card, var(--sk-radius));
  background: var(--sk-paper); color: var(--sk-text); font-size: var(--sk-font-size-base);
}
.sk-chat-panel-field:focus { outline: none; border-color: var(--sk-accent-line); }
.sk-chat-panel-send {
  width: var(--sk-control-h); height: var(--sk-control-h); flex-shrink: 0;
  display: flex; align-items: center; justify-content: center; cursor: pointer;
  border: none; border-radius: var(--sk-radius-card, var(--sk-radius));
  background: var(--sk-primary); color: var(--sk-on-primary);
}
.sk-chat-panel-send:disabled { opacity: 0.45; cursor: not-allowed; }
.sk-chat-panel-send svg { width: 16px; height: 16px; fill: currentColor; }
</style>

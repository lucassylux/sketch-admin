<template>
  <div ref="rootRef" class="sk-field" :class="{ 'is-error': !!error }">
    <label v-if="label" class="sk-field-label">
      {{ label }}<span v-if="isRequired" class="sk-field-req">*</span>
    </label>
    <div class="sk-field-control" @focusout="onBlur">
      <slot />
    </div>
    <div v-if="error" class="sk-field-error">! {{ error }}</div>
    <div v-else-if="hint" class="sk-field-hint">{{ hint }}</div>
  </div>
</template>

<script setup lang="ts">
/**
 * 表单项：label + 控件插槽 + 校验信息（向父 SkForm 注册，blur 时单校）。
 * 取值直接读插槽渲染出的 input/select/textarea DOM，控件组件零改造。
 */
import { computed, inject, onBeforeUnmount, ref } from 'vue'
import type { SkFormRule } from './SkForm.vue'

const props = withDefaults(
  defineProps<{
    name: string
    label?: string
    required?: boolean
    rules?: SkFormRule[]
    hint?: string
  }>(),
  { rules: () => [] },
)

const rootRef = ref<HTMLElement>()
const error = ref('')

const form = inject<{ register: (f: object) => void; unregister: (f: object) => void } | null>('sk-form', null)

const allRules = computed<SkFormRule[]>(() =>
  props.required && !props.rules.some(r => r.required)
    ? [{ required: true, message: `请输入${props.label ?? '该项'}` }, ...props.rules]
    : props.rules,
)
const isRequired = computed(() => allRules.value.some(r => r.required))

function inputValue(): string {
  const input = rootRef.value?.querySelector('input, select, textarea') as HTMLInputElement | null
  return input ? input.value : ''
}

function validate(): string | null {
  const v = inputValue()
  for (const r of allRules.value) {
    if (r.required && !v.trim()) { error.value = r.message; return r.message }
    if (r.min != null && v && v.length < r.min) { error.value = r.message; return r.message }
    if (r.max != null && v && v.length > r.max) { error.value = r.message; return r.message }
    if (r.pattern && v && !r.pattern.test(v)) { error.value = r.message; return r.message }
    if (r.validator && v) {
      const msg = r.validator(v)
      if (msg) { error.value = msg; return msg }
    }
  }
  error.value = ''
  return null
}
function onBlur() {
  if (allRules.value.length) validate()
}
function clear() {
  error.value = ''
}

const fieldCtx = { name: props.name, validate, clear }
form?.register(fieldCtx)
onBeforeUnmount(() => form?.unregister(fieldCtx))
</script>

<style>
.sk-field { display: flex; flex-direction: column; gap: 8px; margin-bottom: 12px; }
/* 间距挂在表单项自身（放进 SkCard 等任意容器不塌）；SkForm 容器已有 gap，归零避免双重间距 */
.sk-form .sk-field { margin-bottom: 0; }
.sk-field:last-child { margin-bottom: 0; }
.sk-field-label {
  font-size: var(--sk-font-size-xs); color: var(--sk-text-muted);
  text-transform: uppercase; letter-spacing: 0.07em;
}
.sk-field-req { color: var(--sk-danger); margin-left: 2px; }
/* 控制区：表单控件（输入/下拉/文本域/多选触发器）铺满字段宽度 */
.sk-field-control { display: flex; }
.sk-field-control > .sk-input,
.sk-field-control > .sk-select,
.sk-field-control > .sk-select-multi,
.sk-field-control > .sk-textarea { flex: 1; min-width: 0; }
.sk-field-error { font-size: var(--sk-font-size-xs); color: var(--sk-danger); }
.sk-field-hint { font-size: var(--sk-font-size-xs); color: var(--sk-text-faint); }
.sk-field.is-error .sk-input-el,
.sk-field.is-error .sk-textarea,
.sk-field.is-error .sk-select { border-color: var(--sk-danger); }
</style>

<template>
  <div class="sk-chart">
    <div v-if="title" class="sk-chart-title">
      {{ title }}
      <span v-if="tag" class="sk-chart-tag">{{ tag }}</span>
    </div>
    <div class="sk-chart-bars" :style="{ height: height + 'px' }">
      <div
        v-for="(v, i) in data"
        :key="i"
        class="sk-chart-bar"
        :class="{ 'is-accent': accentIndex != null ? i === accentIndex : v === max, 'is-hot': hover === i }"
        :style="{ height: Math.max(8, Math.round((v / max) * 100)) + '%' }"
        @mouseenter="hover = i"
        @mouseleave="hover = -1"
      ></div>
      <div v-if="hover >= 0" class="sk-chart-tip" :style="{ left: `calc(${(hover + 0.5) / data.length * 100}% )` }">
        <span v-if="labels?.[hover]">{{ labels[hover] }}：</span><b>{{ data[hover] }}</b>
      </div>
    </div>
    <div v-if="labels?.length" class="sk-chart-labels">
      <span v-for="(l, i) in labels" :key="i">{{ l }}</span>
    </div>
  </div>
</template>

<script setup lang="ts">
/**
 * 手绘风柱状图（2.html chart-box / 3.html chart-wrap）：
 * 斜纹柱体（跟随主题 --sk-fill-pattern），最大值或 accentIndex 指定柱为强调纹。
 */
const props = withDefaults(
  defineProps<{
    data: number[]
    labels?: string[]
    title?: string
    tag?: string
    height?: number
    accentIndex?: number
  }>(),
  { height: 130 },
)
import { ref } from 'vue'
const max = Math.max(...props.data, 1)
const hover = ref(-1)
</script>

<style>
.sk-chart { width: 100%; }
.sk-chart-title {
  font-size: var(--sk-font-size-base); font-weight: 700; margin-bottom: 8px;
  display: flex; align-items: center; gap: 6px;
}
.sk-chart-tag {
  font-size: var(--sk-font-size-xs); color: var(--sk-text-faint); font-weight: 400;
  border: 1px solid var(--sk-line-faint); padding: 1px 5px; border-radius: var(--sk-radius);
}
.sk-chart-bars {
  display: flex; align-items: flex-end; gap: 3px;
  border: 1px dashed var(--sk-line-cell); border-radius: var(--sk-radius);
  background: var(--sk-paper); padding: 8px 6px 0;
  position: relative;
}
.sk-chart-bar.is-hot { filter: brightness(1.15); }
.sk-chart-tip {
  position: absolute; bottom: calc(100% - 6px); transform: translateX(-50%);
  background: var(--sk-surface); border: var(--sk-border-thin); border-radius: var(--sk-radius);
  box-shadow: var(--sk-shadow-pop); padding: 3px 8px; white-space: nowrap;
  font-size: var(--sk-font-size-xs); color: var(--sk-text-muted); pointer-events: none; z-index: 2;
}
.sk-chart-tip b { color: var(--sk-text); font-variant-numeric: tabular-nums; }
.sk-chart-bar {
  flex: 1; border-radius: 2px 2px 0 0;
  border: 1px solid var(--sk-line-input);
  background: color-mix(in srgb, var(--sk-ink) 14%, transparent);
  min-height: 8px;
}
.sk-chart-bar.is-accent { background: var(--sk-fill-pattern); }
.sk-chart-labels {
  display: flex; justify-content: space-between; margin-top: 4px;
  font-size: var(--sk-font-size-xs); color: var(--sk-text-faint); padding: 0 4px;
}
</style>

<template>
  <div class="sk-progress-ring" :style="{ width: size + 'px', height: size + 'px' }">
    <svg :viewBox="`0 0 ${V} ${V}`" role="img">
      <circle :cx="C" :cy="C" :r="c" fill="none" stroke="var(--sk-muted-soft2)" :stroke-width="thickness" />
      <circle
        :cx="C" :cy="C" :r="c" fill="none"
        :stroke="ringColor"
        :stroke-width="thickness"
        stroke-linecap="round"
        :stroke-dasharray="`${(clamped / 100) * CIRC} ${CIRC}`"
        class="sk-progress-ring-bar"
      />
    </svg>
    <div class="sk-progress-ring-center">
      <span class="sk-progress-ring-value">{{ clamped }}<small v-if="showUnit">%</small></span>
      <span v-if="label" class="sk-progress-ring-label">{{ label }}</span>
    </div>
  </div>
</template>

<script setup lang="ts">
/**
 * 圆形进度环（5.html AI Insights 健康分 75）：
 * SVG stroke-dasharray 环 + 中心数值；tone 决定环色。
 */
import { computed } from 'vue'

const props = withDefaults(
  defineProps<{
    value: number
    size?: number
    thickness?: number
    label?: string
    tone?: 'accent' | 'success' | 'warning' | 'danger' | 'info'
    showUnit?: boolean
  }>(),
  { size: 96, thickness: 9, tone: 'accent', showUnit: true },
)

const V = 100
const C = 50
const c = 42
const CIRC = 2 * Math.PI * c

const clamped = computed(() => Math.max(0, Math.min(100, Math.round(props.value))))

const toneVar: Record<string, string> = {
  accent: 'var(--sk-accent-line)',
  success: 'var(--sk-success)',
  warning: 'var(--sk-warning)',
  danger: 'var(--sk-danger)',
  info: 'var(--sk-info)',
}
const ringColor = computed(() => toneVar[props.tone])
</script>

<style>
.sk-progress-ring { position: relative; display: inline-block; }
.sk-progress-ring svg { width: 100%; height: 100%; transform: rotate(-90deg); }
.sk-progress-ring-bar { transition: stroke-dasharray 0.3s; }
.sk-progress-ring-center {
  position: absolute; inset: 0; display: flex; flex-direction: column;
  align-items: center; justify-content: center; text-align: center;
}
.sk-progress-ring-value { font-size: var(--sk-font-size-xl); font-weight: 700; line-height: 1; }
.sk-progress-ring-value small { font-size: var(--sk-font-size-sm); font-weight: 400; margin-left: 1px; }
.sk-progress-ring-label { font-size: var(--sk-font-size-xs); color: var(--sk-text-muted); margin-top: 3px; }
</style>

<template>
  <div v-if="variant === 'tabs'" class="sk-tabs" v-bind="$attrs">
    <button
      v-for="t in tabs"
      :key="String(t.key)"
      type="button"
      class="sk-tabs-btn"
      :class="{ 'is-active': String(modelValue) === String(t.key) }"
      @click="$emit('update:modelValue', t.key)"
    >
      {{ t.label }}
    </button>
  </div>
  <div v-else class="sk-segmented" role="tablist" v-bind="$attrs">
    <button
      v-for="t in tabs"
      :key="String(t.key)"
      type="button"
      class="sk-segmented-item"
      role="tab"
      :class="{ 'is-active': String(modelValue) === String(t.key) }"
      @click="$emit('update:modelValue', t.key)"
    >
      {{ t.label }}
    </button>
  </div>
  <!-- 子组件模式：渲染 SkTabPane 子组件（v-show 由注入控制） -->
  <slot v-if="$slots.default" />
</template>

<script setup lang="ts">
/**
 * 页签：variant='tabs' 为文件夹页签（选中黄块压住底边），
 * variant='segmented' 复用连体按钮组（与 SkRadioGroup buttons 同视觉）。
 * 支持两种用法：
 * 1. :tabs 数组 + v-model（纯切换器）
 * 2. :tabs 数组 + <SkTabPane> 子组件（内容面板由本组件渲染）
 */
import { provide, ref, watch } from 'vue'

// 多根模板（v-if 分支 + 兄弟 slot 节点）：$attrs 不自动继承，样式/类透传须手动挂根节点
defineOptions({ inheritAttrs: false })

export interface SkTabItem { key: string | number; label: string }

const props = withDefaults(
  defineProps<{ modelValue: string | number; tabs: SkTabItem[]; variant?: 'tabs' | 'segmented' }>(),
  { variant: 'tabs' },
)
const emit = defineEmits<{ 'update:modelValue': [v: string | number] }>()

const activeRef = ref(props.modelValue)
watch(() => props.modelValue, (v) => (activeRef.value = v))
provide('skTabsActive', activeRef)
</script>

<style>
.sk-tabs { display: flex; flex-wrap: wrap; position: relative; }
/* 高度锁定整数 px（30）：底线相位随页面上方一串小数行高漂移，在 125%/150% 缩放下
 * 同一条 2px 线时粗时细；按钮自身高度固定后，页签条高度不再依赖字体行高 */
.sk-tabs-btn {
  font-family: var(--sk-font); font-size: var(--sk-font-size-sm); font-weight: 600; letter-spacing: 0.05em;
  height: 30px; padding: 0 16px; line-height: 1;
  display: inline-flex; align-items: center;
  border: 1.5px solid var(--sk-ink); border-bottom: none;
  background: var(--sk-surface-dim); color: var(--sk-text);
  cursor: pointer; margin-right: -1.5px; position: relative;
}
.sk-tabs-btn:first-child { border-top-left-radius: var(--sk-radius-btn, var(--sk-radius)); border-bottom-left-radius: var(--sk-radius-btn, var(--sk-radius)); }
.sk-tabs-btn:last-child { margin-right: 0; border-top-right-radius: var(--sk-radius-btn, var(--sk-radius)); border-bottom-right-radius: var(--sk-radius-btn, var(--sk-radius)); }
/* 选中页签底边与线同带精确覆盖（整 2px 对齐设备像素：无亚像素残缝、无外溢） */
/* 选中态只画黄块，不画自己的底边——底边线统一由容器 ::after 压在最上层绘制，
 * 避免 z 序上按钮盖线时（含圆角/亚像素边缘）黄色渗进线区 */
.sk-tabs-btn.is-active { background: var(--sk-accent); z-index: 1; }
.sk-tabs-btn:not(.is-active):hover { background: var(--sk-hover); }
/* 底线整条横贯（画在 tab 层后）：与 tab 底边同层对齐，选中 tab 底边（2px）整像素覆盖 */
.sk-tabs::after { content: ''; position: absolute; left: 0; right: 0; bottom: 0; height: 2px; background: var(--sk-ink); z-index: 2; }
</style>

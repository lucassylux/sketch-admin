<template>
  <span class="sk-input-number">
    <button type="button" class="sk-input-number-btn" :disabled="disabled || atMin" aria-label="减少" @click="step(-1)">−</button>
    <input
      class="sk-input-number-el"
      type="text"
      inputmode="numeric"
      :value="text"
      :disabled="disabled"
      :placeholder="placeholder"
      @input="onInput"
      @blur="onBlur"
      @keydown.up.prevent="step(1)"
      @keydown.down.prevent="step(-1)"
    />
    <button type="button" class="sk-input-number-btn" :disabled="disabled || atMax" aria-label="增加" @click="step(1)">＋</button>
    <span v-if="suffix" class="sk-input-number-suffix">{{ suffix }}</span>
  </span>
</template>

<script setup lang="ts">
/**
 * 数字输入：步进按钮 + 键盘上下调节；
 * min/max/step/precision；失焦与步进时规范回写。支持 v-model:number（数字）。
 */
import { computed, ref, watch } from 'vue'

const props = withDefaults(
  defineProps<{
    modelValue?: number | null
    min?: number
    max?: number
    step?: number
    precision?: number
    disabled?: boolean
    placeholder?: string
    suffix?: string
  }>(),
  { modelValue: null, step: 1, precision: undefined },
)
const emit = defineEmits<{ 'update:modelValue': [v: number | null] }>()

const text = ref(props.modelValue == null ? '' : String(props.modelValue))
watch(() => props.modelValue, (v) => (text.value = v == null ? '' : String(v)))

const clamp = (v: number) => {
  let n = v
  if (props.min != null && n < props.min) n = props.min
  if (props.max != null && n > props.max) n = props.max
  if (props.precision != null) n = Number(n.toFixed(props.precision))
  return n
}

const atMin = computed(() => props.min != null && Number(text.value) <= props.min)
const atMax = computed(() => props.max != null && Number(text.value) >= props.max)

function commit(v: number) {
  const n = clamp(v)
  text.value = String(n)
  emit('update:modelValue', n)
}

function onInput(e: Event) {
  const raw = (e.target as HTMLInputElement).value.trim()
  if (raw === '' || raw === '-') {
    text.value = raw
    emit('update:modelValue', null)
    return
  }
  const n = Number(raw)
  if (!Number.isNaN(n)) emit('update:modelValue', n)
}

function onBlur() {
  const n = Number(text.value)
  if (text.value === '' || Number.isNaN(n)) {
    emit('update:modelValue', null)
    text.value = ''
  } else {
    commit(n)
  }
}

function step(dir: 1 | -1) {
  const base = Number(text.value)
  const from = Number.isNaN(base) || text.value === '' ? (props.min ?? 0) : base
  commit(from + dir * props.step)
}
</script>

<style>
.sk-input-number { display: inline-flex; align-items: stretch; position: relative; }
.sk-input-number-el {
  width: 88px; min-width: 0; text-align: center;
  height: var(--sk-control-h); padding: 0 4px;
  font-family: var(--sk-font); font-size: var(--sk-font-size-base); color: var(--sk-text);
  border: var(--sk-border-input); border-radius: 0;
  background: var(--sk-surface);
  font-variant-numeric: tabular-nums;
}
.sk-input-number-el:focus { outline: none; border-color: var(--sk-accent-line); }
.sk-input-number-el:disabled { background: var(--sk-muted-soft2); color: var(--sk-text-faint); cursor: not-allowed; }
.sk-input-number-btn {
  width: 22px; flex-shrink: 0; cursor: pointer;
  border: var(--sk-border-input); background: var(--sk-muted-soft);
  color: var(--sk-text-muted); font-size: 12px; line-height: 1;
}
.sk-input-number-btn:first-child { border-radius: var(--sk-radius-btn, var(--sk-radius)) 0 0 var(--sk-radius-btn, var(--sk-radius)); border-right: none; }
.sk-input-number-btn:last-of-type { border-radius: 0 var(--sk-radius-btn, var(--sk-radius)) var(--sk-radius-btn, var(--sk-radius)) 0; border-left: none; }
.sk-input-number-btn:hover:not(:disabled) { background: var(--sk-hover); color: var(--sk-text); }
.sk-input-number-btn:disabled { opacity: 0.45; cursor: not-allowed; }
.sk-input-number-suffix {
  align-self: center; margin-left: 6px;
  font-size: var(--sk-font-size-xs); color: var(--sk-text-faint); white-space: nowrap;
}
</style>

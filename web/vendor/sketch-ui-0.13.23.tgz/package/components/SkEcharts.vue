<template>
  <div ref="el" :style="{ width: '100%', height }"></div>
</template>

<script setup lang="ts">
/**
 * ECharts 封装（主题 token 驱动）：
 * - init 时按当前 sketch 主题的 --sk-* token 注册 echarts 主题（坐标轴/网格线/图例/tooltip/文字色），
 *   主题切换自动 dispose 重建重绘；
 * - 调色板默认取 --sk-chart-1..5 循环，可用 colors 覆盖（数据系列固定色场景）；
 * - option 深度监听、窗口与容器 resize 自适应。
 * 注意：本组件不进全局注册（echarts 为可选依赖），按需 import：
 *   import { SkEcharts } from '@xzsoft/sketch-ui/echarts'
 */
import * as echarts from 'echarts'
import { onBeforeUnmount, onMounted, ref, watch } from 'vue'
import { useSkTheme } from '../theme'

const props = withDefaults(
  defineProps<{
    option?: Record<string, unknown> | null
    height?: string
    /** 系列调色板；默认取主题 --sk-chart-1..5 */
    colors?: string[]
  }>(),
  { height: '320px' },
)

const { theme } = useSkTheme()
const el = ref<HTMLDivElement | null>(null)
let chart: echarts.ECharts | null = null
let ro: ResizeObserver | null = null

const cssVar = (name: string, fb: string) => {
  const v = getComputedStyle(document.documentElement).getPropertyValue(name).trim()
  return v || fb
}

/** 按当前主题 token 注册 echarts 主题（同名重注册即覆盖），返回主题名 */
function registerSkTheme(): string {
  const t = {
    surface: cssVar('--sk-surface', '#ffffff'),
    text: cssVar('--sk-text', '#333333'),
    muted: cssVar('--sk-text-muted', '#888888'),
    line: cssVar('--sk-line-faint', '#dddddd'),
    lineInput: cssVar('--sk-line-input', '#999999'),
    cell: cssVar('--sk-line-cell', '#eeeeee'),
  }
  const name = 'sk-' + (theme.value || 'sketch')
  echarts.registerTheme(name, {
    backgroundColor: 'transparent',
    color: props.colors ?? [
      cssVar('--sk-chart-1', '#6366f1'),
      cssVar('--sk-chart-2', '#22c55e'),
      cssVar('--sk-chart-3', '#f59e0b'),
      cssVar('--sk-chart-4', '#ef4444'),
      cssVar('--sk-chart-5', '#a855f7'),
    ],
    textStyle: { color: t.muted },
    legend: { textStyle: { color: t.muted } },
    tooltip: {
      backgroundColor: t.surface,
      borderColor: t.lineInput,
      textStyle: { color: t.text },
    },
    categoryAxis: {
      axisLine: { lineStyle: { color: t.line } },
      axisTick: { lineStyle: { color: t.line } },
      axisLabel: { color: t.muted },
      splitLine: { show: false },
    },
    valueAxis: {
      axisLine: { show: false },
      axisTick: { show: false },
      axisLabel: { color: t.muted },
      splitLine: { lineStyle: { color: t.cell } },
    },
  })
  return name
}

function mount() {
  chart?.dispose()
  chart = null
  if (!el.value) return
  chart = echarts.init(el.value, registerSkTheme())
  render()
}

function render() {
  if (chart && props.option) chart.setOption(props.option, true)
}

const onResize = () => chart && chart.resize()

onMounted(() => {
  mount()
  window.addEventListener('resize', onResize)
  if (typeof ResizeObserver !== 'undefined' && el.value) {
    ro = new ResizeObserver(onResize)
    ro.observe(el.value)
  }
})
watch(() => props.option, render, { deep: true })
watch(theme, mount)
onBeforeUnmount(() => {
  window.removeEventListener('resize', onResize)
  ro?.disconnect()
  chart?.dispose()
  chart = null
})
</script>

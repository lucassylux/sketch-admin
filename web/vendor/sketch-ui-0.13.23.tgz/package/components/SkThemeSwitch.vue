<template>
  <SkDropdown :items="menuItems" @select="(k: string | number) => setTheme(String(k))">
    <button type="button" class="sk-theme-switch" :class="{ 'is-icon': !label }" :title="currentLabel" aria-label="切换主题">
      <SkIconPalette class="sk-theme-switch-icon" />
      <span v-if="label" class="sk-theme-switch-label">{{ currentLabel }}</span>
    </button>
  </SkDropdown>
</template>

<script setup lang="ts">
/**
 * 主题切换器（标准工具组件）：调色板图标（+ 可选当前主题名）+ 下拉菜单列出全部主题，
 * 当前项打 ✓。消费 useSkTheme，各应用放一个即可用，无需重复拼菜单逻辑。
 * label 开启时显示当前主题文字（顶栏场景）；纯图标模式适合紧凑角落。
 */
import { computed } from 'vue'
import SkDropdown from './SkDropdown.vue'
import { useSkTheme, SK_THEMES } from '../theme'
import { SkIconPalette } from '../icons'

withDefaults(defineProps<{ label?: boolean }>(), { label: false })

const { theme, setTheme } = useSkTheme()

const menuItems = computed(() =>
  SK_THEMES.map(t => ({ key: t.key, label: `${theme.value === t.key ? '✓ ' : ''}${t.label}` })),
)
const currentLabel = computed(() => SK_THEMES.find(t => t.key === theme.value)?.label ?? '')
</script>

<style>
.sk-theme-switch {
  display: inline-flex; align-items: center; gap: 6px;
  height: var(--sk-control-h-sm); padding: 0 10px; cursor: pointer;
  border: var(--sk-border-input); border-radius: var(--sk-radius-btn, var(--sk-radius));
  background: var(--sk-surface); color: var(--sk-text-muted);
  font-family: var(--sk-font); font-size: var(--sk-font-size-xs); white-space: nowrap;
}
.sk-theme-switch:hover { color: var(--sk-text); box-shadow: var(--sk-shadow-press); }
.sk-theme-switch-icon { width: 14px; height: 14px; }
/* 纯图标模式：正方形图标钮（无下拉箭头，点按出菜单） */
.sk-theme-switch.is-icon { padding: 0; width: var(--sk-control-h-sm); justify-content: center; }
</style>

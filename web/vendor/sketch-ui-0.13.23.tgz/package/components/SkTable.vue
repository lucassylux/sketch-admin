<template>
  <div class="sk-table-wrap" :style="scrollX ? { '--sk-table-min-w': scrollX + 'px' } : undefined">
    <!-- scrollY 模式：表头独立成表（纵向滚动只作用于表体，滚动条不再贯穿表头高度）。
         两处 thead/colgroup 标记保持同步改（列结构一致是列宽对齐的前提） -->
    <div v-if="scrollY" ref="headWrap" class="sk-table-headclip">
      <table ref="headTable" class="sk-table sk-table-fixed" :class="{ 'sk-table-sm': size === 'sm' }">
        <colgroup>
          <col v-if="selectable" class="sk-table-check" />
          <col v-for="c in columns" :key="c.key ?? c.dataIndex" :style="{ width: c.width ? c.width + 'px' : undefined }" />
        </colgroup>
        <thead>
          <tr>
            <th v-if="selectable" class="sk-table-check">
              <input
                ref="allRef"
                type="checkbox"
                :checked="allChecked"
                @change="toggleAll(($event.target as HTMLInputElement).checked)"
              />
            </th>            <th
              v-for="c in columns"
              :key="c.key ?? c.dataIndex"
              :style="{ width: c.width ? c.width + 'px' : undefined, textAlign: c.align }"
              :class="{ 'sk-th-ellipsis': c.ellipsis }"
            >
              {{ c.title }}
            </th>
          </tr>
        </thead>
      </table>
    </div>
    <div
      ref="bodyWrap"
      class="sk-table-scroll"
      :class="{ 'is-loading': loading, 'has-scroll-y': scrollY }"
      :style="scrollY ? { maxHeight: typeof scrollY === 'number' ? scrollY + 'px' : scrollY } : undefined"
      @scroll="onBodyScroll"
    >
      <table ref="bodyTable" class="sk-table" :class="{ 'sk-table-sm': size === 'sm', 'sk-table-fixed': scrollY }">
        <colgroup v-if="scrollY">
          <col v-if="selectable" class="sk-table-check" />
          <col v-for="c in columns" :key="c.key ?? c.dataIndex" :style="{ width: c.width ? c.width + 'px' : undefined }" />
        </colgroup>
        <thead v-if="!scrollY">
          <tr>
            <th v-if="selectable" class="sk-table-check">
              <input
                ref="allRef"
                type="checkbox"
                :checked="allChecked"
                @change="toggleAll(($event.target as HTMLInputElement).checked)"
              />
            </th>            <th
              v-for="c in columns"
              :key="c.key ?? c.dataIndex"
              :style="{ width: c.width ? c.width + 'px' : undefined, textAlign: c.align }"
              :class="{ 'sk-th-ellipsis': c.ellipsis }"
            >
              {{ c.title }}
            </th>
          </tr>
        </thead>
        <tbody>
          <tr
            v-for="({ row, depth }, idx) in flatRows"
            :key="String(row[rowKey])"
            :class="row.__state ? `sk-table-row-${row.__state}` : ''"
            v-bind="customRow ? customRow(row) : undefined"
            @contextmenu="$emit('rowContextmenu', row, $event)"
          >
            <td v-if="selectable" class="sk-table-check">
              <input
                v-if="isRowSelectable(row)"
                type="checkbox"
                :checked="selectedKeys.includes(String(row[rowKey]))"
                @change="toggleOne(String(row[rowKey]))"
              />
            </td>
            <td v-for="(c, ci) in columns" :key="c.key ?? c.dataIndex" :style="{ textAlign: c.align }" :class="{ 'sk-td-ellipsis': c.ellipsis, 'sk-td-mono': c.mono }">
              <!-- 树形模式：首列缩进 + 展开折叠符（数据含 children 即启用）；
                   叶子行补等宽占位符，保证同层兄弟行（有无子级）文字左缘对齐 -->
              <span v-if="treeMode && ci === 0" class="sk-table-indent" :style="{ width: depth * 18 + 'px' }"></span>
              <button
                v-if="treeMode && ci === 0 && row[childrenKey]?.length"
                type="button" class="sk-table-tree-toggle"
                :class="{ 'is-open': expanded.has(String(row[rowKey])) }"
                :aria-expanded="expanded.has(String(row[rowKey]))"
                @click.stop="toggleTree(row)"
              >▸</button>
              <span v-else-if="treeMode && ci === 0" class="sk-table-tree-toggle-ph" aria-hidden="true"></span>
              <slot name="bodyCell" :column="c" :record="row" :index="idx">
                {{ cellText(row, c) }}
              </slot>
            </td>
          </tr>
          <tr v-if="!data.length && !loading">
            <td :colspan="colCount" class="sk-table-empty-td">
              <slot name="empty">
                <SkEmpty description="暂无数据" />
              </slot>
            </td>
          </tr>
        </tbody>
      </table>
      <div v-if="loading" class="sk-table-mask"><SkSpin /></div>
    </div>
    <SkPagination
      v-if="pagination"
      v-bind="paginationPassthrough"
      :total="pagination.total"
      @change="onPageChange"
    />
  </div>
</template>

<script setup lang="ts">
/**
 * 表格（对应线框稿 sketch-table）：虚线单元格 + 墨线表头；
 * 可选行选择（checkbox 列）、loading 遮罩、空态、内嵌分页。
 * 单元格自定义：#bodyCell="{ column, record, index }"（index 为拍平后的显示行序号；未命中原样输出字段文本）。
 */
import { computed, nextTick, onBeforeUnmount, onMounted, ref, watch } from 'vue'
import SkEmpty from './SkEmpty.vue'
import SkPagination from './SkPagination.vue'

export interface SkTableColumn {
  title: string
  /** 列标识（也作为插槽区分用；无 dataIndex 时取字段） */
  key?: string
  /** 取值字段 */
  dataIndex?: string
  width?: number
  ellipsis?: boolean
  /** 数字列：等宽字体 + 表格数字（2.html td-mono，金额/序号/百分比列） */
  mono?: boolean
  /** 固定列标记（当前仅语义标注，不做吸附渲染） */
  fixed?: 'left' | 'right'
  align?: 'left' | 'center' | 'right'
}

const props = withDefaults(
  defineProps<{
    columns: SkTableColumn[]
    /** 行数据（字段宽松：插槽按列 key/dataIndex 取值）；含 children 字段自动进入树形模式 */
    data: Record<string, any>[]
    rowKey?: string
    loading?: boolean
    selectable?: boolean
    /** 可选行的过滤（如文件夹导航行不参与批量选择）；缺省全部可选 */
    selectableFilter?: (record: Record<string, any>) => boolean
    modelValue?: (string | number)[]
    pagination?: false | { page: number; pageSize: number; total: number }
    size?: 'md' | 'sm'
    /** 树形子行字段名 */
    childrenKey?: string
    /** 树形默认展开全部（default-expand-all 为简写） */
    defaultExpandAll?: boolean
    defaultExpandAllRows?: boolean
    /** 默认展开的行过滤（与 defaultExpandAll(Rows) 配合）：只有通过过滤且有子节点的行进入展开集，
     *  如菜单树只展开目录层（menuType==='M'），菜单层保持收起不露出按钮行；不传则全展开 */
    defaultExpandFilter?: (row: Record<string, any>) => boolean
    /** 横向最小宽度（列多时表格出横向滚动条而不是挤压列） */
    scrollX?: number
    /** 纵向限高（px 数值或 CSS 高度串）：表头独立固定，表体超出限高内部滚动；
     *  无宽列在两表间均分基准一致（fixed 布局 + 表头宽度跟随表体），列严格对齐 */
    scrollY?: number | string
    /** 行属性工厂：返回对象整绑到 tr，如 { onClick, class: 'is-selected', style: {cursor:'pointer'} } */
    customRow?: (record: Record<string, any>) => Record<string, unknown>
  }>(),
  { rowKey: 'id', modelValue: () => [], childrenKey: 'children' },
)
const emit = defineEmits<{
  'update:modelValue': [v: string[]]
  change: [p: { page: number; pageSize: number }]
  /** 行右键（不阻止默认，由使用方决定是否 preventDefault） */
  rowContextmenu: [record: Record<string, any>, e: MouseEvent]
}>()

const selectedKeys = computed(() => props.modelValue.map(String))
const colCount = computed(() => props.columns.length + (props.selectable ? 1 : 0))

// ── 内置分页：page 为当前页字段；onChange 可直接写在 pagination 对象内 ──
// usePager 这类"配置对象自带 onChange"的用法直接生效；无 onChange 时向上 emit change
const paginationPassthrough = computed(() => {
  // 始终返回完整形状（SkPagination 的 page/pageSize 必填；v-if 已保证无分页时不渲染，但类型上不能出 {} 分支）
  const { page, current, pageSize, onChange, total, ...rest } = (props.pagination ?? {}) as Record<string, any>
  return { page: page ?? current ?? 1, pageSize: pageSize ?? 20, ...rest }
})
function onPageChange(p: { page: number; pageSize: number }) {
  const cb = (props.pagination as Record<string, any> | false | undefined)
  if (cb && typeof (cb as Record<string, any>).onChange === 'function') {
    ;(cb as Record<string, any>).onChange(p.page, p.pageSize)
  } else {
    emit('change', p)
  }
}

// ── 树形模式：数据含非空 children 即启用；按展开集拍平成带深度的一维行序列 ──
const treeMode = computed(() =>
  props.data.some(r => Array.isArray(r[props.childrenKey]) && r[props.childrenKey].length))
const expanded = ref<Set<string>>(
  props.defaultExpandAll || props.defaultExpandAllRows
    ? new Set(collectIds(props.data))
    : new Set(),
)
// defaultExpandAll(Rows) 对异步数据失效：初始 data 为空时展开集为空、数据到达后不再重算，树保持全折叠。
// 数据每次替换（首载/搜索/刷新）时重建展开集；collectIds 只收"有子节点"的行，叶子行天然不在集合内
watch(() => props.data, (list) => {
  if ((props.defaultExpandAll || props.defaultExpandAllRows) && list.length) {
    expanded.value = new Set(collectIds(list))
  }
})
function collectIds(list: Record<string, any>[], out: string[] = []): string[] {
  for (const r of list) {
    const kids = r[props.childrenKey]
    if (Array.isArray(kids) && kids.length) {
      // defaultExpandFilter 过滤"哪些父行默认展开"：未通过的父行保持收起（子行隐藏，可手动展开）
      if (!props.defaultExpandFilter || props.defaultExpandFilter(r)) out.push(String(r[props.rowKey]))
      collectIds(kids, out)
    }
  }
  return out
}
const flatRows = computed(() => {
  if (!treeMode.value) return props.data.map(row => ({ row, depth: 0 }))
  const out: { row: Record<string, any>; depth: number }[] = []
  const walk = (list: Record<string, any>[], depth: number) => {
    for (const row of list) {
      out.push({ row, depth })
      const kids = row[props.childrenKey]
      if (Array.isArray(kids) && kids.length && expanded.value.has(String(row[props.rowKey]))) walk(kids, depth + 1)
    }
  }
  walk(props.data, 0)
  return out
})
function toggleTree(row: Record<string, any>) {
  const k = String(row[props.rowKey])
  expanded.value.has(k) ? expanded.value.delete(k) : expanded.value.add(k)
}
const selectableRows = computed(() => props.data.filter(r => isRowSelectable(r)))
const allChecked = computed(() =>
  selectableRows.value.length > 0 && selectableRows.value.every(r => selectedKeys.value.includes(String(r[props.rowKey]))),
)
function isRowSelectable(row: Record<string, any>) {
  return !props.selectableFilter || props.selectableFilter(row)
}

const allRef = ref<HTMLInputElement>()
watch(allChecked, v => nextTick(() => { if (allRef.value) allRef.value.indeterminate = !v && selectableRows.value.some(r => selectedKeys.value.includes(String(r[props.rowKey]))) }))

// ── scrollY 列宽/横向滚动对齐 ──
const headWrap = ref<HTMLElement>()
const headTable = ref<HTMLTableElement>()
const bodyWrap = ref<HTMLElement>()
const bodyTable = ref<HTMLTableElement>()

/** 表头表宽度钉到表体表的实际像素宽：表体滚动条占位（经典滚动条）会使两表可用宽不同，
 *  无宽列的均分随之错位；同步像素宽 + 两表同 colgroup + fixed 布局后列严格对齐 */
function syncHeadWidth() {
  if (!headTable.value || !bodyTable.value) return
  const w = bodyTable.value.getBoundingClientRect().width
  if (w > 0) headTable.value.style.width = w + 'px'
}

/** 表体横滚时表头跟随（scrollX 与 scrollY 组合场景） */
function onBodyScroll() {
  if (headWrap.value && bodyWrap.value) headWrap.value.scrollLeft = bodyWrap.value.scrollLeft
}

let headRO: ResizeObserver | undefined
onMounted(() => {
  if (!props.scrollY) return
  syncHeadWidth()
  // 表体表宽随容器/滚动条出现消失变化（数据量跨过限高、窗口缩放）时重新对齐
  headRO = new ResizeObserver(syncHeadWidth)
  if (bodyTable.value) headRO.observe(bodyTable.value)
})
onBeforeUnmount(() => headRO?.disconnect())
watch(
  () => [props.data, props.columns, props.selectable, props.loading, props.scrollY],
  () => nextTick(syncHeadWidth),
)

function toggleAll(checked: boolean) {
  const keys = checked ? selectableRows.value.map(r => String(r[props.rowKey])) : []
  emit('update:modelValue', keys)
}
function toggleOne(key: string) {
  const has = selectedKeys.value.includes(key)
  emit('update:modelValue', has ? selectedKeys.value.filter(k => k !== key) : [...selectedKeys.value, key])
}
function cellText(row: Record<string, any>, c: SkTableColumn) {
  const v = row[c.dataIndex ?? c.key ?? '']
  return v == null ? '' : String(v)
}
</script>

<style>
.sk-table-wrap { width: 100%; }
.sk-table-scroll { position: relative; overflow-x: auto; }
/* ── scrollY：表头独立成表（不参与纵向滚动，滚动条只在表体区）+ 表体限高内部滚动 ── */
.sk-table-headclip { overflow: hidden; }
.sk-table-scroll.has-scroll-y { overflow-y: auto; overscroll-behavior: contain; scrollbar-width: thin; }
.sk-table-fixed { table-layout: fixed; }
/* separate + spacing 0：collapse 下边框归表格整体绘制，粘性表头的边框会随内容滚走；
 * 本表边框全部单侧定义（bottom+right），separate 渲染结果与 collapse 逐像素一致 */
.sk-table { width: 100%; border-collapse: separate; border-spacing: 0; font-size: var(--sk-font-size-sm); min-width: var(--sk-table-min-w, auto); }
.sk-table th {
  font-size: var(--sk-font-size-xs); letter-spacing: 0.07em; text-transform: uppercase;
  color: var(--sk-text-muted); text-align: left; white-space: nowrap;
  padding: 8px 10px; background: var(--sk-bg);
  border-bottom: var(--sk-border); border-right: var(--sk-border-cell);
}
.sk-table td {
  padding: 7px 10px; vertical-align: middle;
  border-bottom: var(--sk-border-cell); border-right: var(--sk-border-cell);
}
.sk-table th:last-child, .sk-table td:last-child { border-right: none; }
.sk-table tbody tr:hover td { background: var(--sk-hover); }
/* 行状态底色（对应线框稿 row-urgent / row-critical），字段 __state: 'urgent' | 'critical' */
.sk-table tbody tr.sk-table-row-urgent td { background: var(--sk-row-urgent); }
.sk-table tbody tr.sk-table-row-critical td { background: var(--sk-row-critical); }
.sk-table-sm td { padding: 5px 8px; font-size: var(--sk-font-size-xs); }
.sk-table-sm th { padding: 6px 8px; }
.sk-table-check { width: 30px; }
.sk-table-check input { width: 13px; height: 13px; accent-color: var(--sk-primary); cursor: pointer; }
.sk-th-ellipsis, .sk-td-ellipsis { max-width: 220px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.sk-td-mono {
  font-family: ui-monospace, "Cascadia Mono", Consolas, "Courier New", monospace;
  font-variant-numeric: tabular-nums;
}
.sk-table-empty-td { padding: 0 !important; border-bottom: none !important; }
/* ── 树形模式：首列缩进占位 + 折叠符 ── */
.sk-table-indent { display: inline-block; vertical-align: bottom; }
.sk-table-tree-toggle {
  display: inline-flex; align-items: center; justify-content: center;
  width: 16px; height: 16px; margin-right: 4px; padding: 0;
  border: none; background: none; color: var(--sk-text-muted); cursor: pointer;
  font-size: 10px; line-height: 1; vertical-align: middle;
  transition: transform 0.15s;
}
.sk-table-tree-toggle.is-open { transform: rotate(90deg); }
.sk-table-tree-toggle:hover { color: var(--sk-text); }
/* 叶子行的折叠符占位：与折叠符同宽同距（16px + 4px），同层文字对齐 */
.sk-table-tree-toggle-ph { display: inline-block; width: 16px; height: 1px; margin-right: 4px; vertical-align: middle; }
.sk-table-mask {
  position: absolute; inset: 0; display: flex; align-items: center; justify-content: center;
  background: color-mix(in srgb, var(--sk-paper) 65%, transparent);
}
</style>

<template>
  <button
    class="sk-btn"
    :class="[
      variant !== 'default' ? `sk-btn-${variant}` : '',
      size === 'sm' ? 'sk-btn-sm' : '',
      size === 'lg' ? 'sk-btn-lg' : '',
      { 'sk-btn-block': block, 'sk-btn-icon': icon },
    ]"
    :type="htmlType"
    :disabled="disabled || loading"
    @click="$emit('click', $event)"
  >
    <span v-if="loading" class="sk-btn-spinner" aria-hidden="true"></span>
    <slot />
  </button>
</template>

<script setup lang="ts">
/**
 * 按钮：variant default/primary/warn/danger，size sm/md/lg，loading 时显示线框旋转方块。
 */
withDefaults(
  defineProps<{
    variant?: 'default' | 'primary' | 'warn' | 'danger'
    size?: 'sm' | 'md' | 'lg'
    loading?: boolean
    disabled?: boolean
    block?: boolean
    /** 纯图标方钮（无内边距收缩） */
    icon?: boolean
    htmlType?: 'button' | 'submit' | 'reset'
  }>(),
  { variant: 'default', size: 'md', htmlType: 'button' },
)

defineEmits<{ click: [e: MouseEvent] }>()
</script>

<style>
.sk-btn {
  display: inline-flex; align-items: center; justify-content: center; gap: 6px;
  font-family: var(--sk-font); font-size: var(--sk-font-size-base); letter-spacing: 0.04em;
  padding: 0 var(--sk-control-px); height: var(--sk-control-h);
  border: 1.5px solid var(--sk-ink); border-radius: var(--sk-radius-btn, var(--sk-radius));
  background: var(--sk-surface); color: var(--sk-text);
  cursor: pointer; white-space: nowrap; flex-shrink: 0;
  transition: box-shadow 0.1s, transform 0.1s;
}
.sk-btn:hover:not(:disabled) { box-shadow: var(--sk-shadow-press); }
.sk-btn:active:not(:disabled) { transform: translate(1px, 1px); box-shadow: none; }
.sk-btn:disabled { opacity: 0.45; cursor: not-allowed; }

.sk-btn-primary { background: var(--sk-primary); color: var(--sk-on-primary); }
.sk-btn-warn { background: var(--sk-accent); border-color: var(--sk-accent-line); color: var(--sk-text); }
.sk-btn-danger { background: var(--sk-danger-soft2); border-color: var(--sk-danger); color: var(--sk-danger); }

.sk-btn-sm { height: var(--sk-control-h-sm); padding: 0 var(--sk-control-px-sm); font-size: var(--sk-font-size-sm); }
.sk-btn-lg { height: var(--sk-control-h-lg); padding: 0 14px; font-size: var(--sk-font-size-md); }
.sk-btn-block { display: flex; width: 100%; }
.sk-btn-icon { padding: 0; width: var(--sk-control-h); }

.sk-btn .sk-icon { width: 1.05em; height: 1.05em; }

.sk-btn-spinner {
  width: 10px; height: 10px; border-radius: 50%;
  border: 2px dashed currentColor; animation: sk-spin 0.8s linear infinite;
}
@keyframes sk-spin { to { transform: rotate(360deg); } }
</style>

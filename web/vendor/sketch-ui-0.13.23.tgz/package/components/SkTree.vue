<template>
  <div class="sk-tree">
    <div v-for="node in nodeList" :key="node.id" class="sk-tree-branch">
      <div
        class="sk-tree-row"
        :class="{ 'is-active': selected != null && String(selected) === String(node.id) }"
        :style="{ paddingLeft: 4 + depth * 14 + 'px' }"
        @click="$emit('select', node)"
      >
        <button
          v-if="node.children?.length"
          type="button"
          class="sk-tree-expander"
          :title="expanded.has(node.id) ? '折叠' : '展开'"
          @click.stop="toggle(node.id)"
        >
          <SkIconChevronRight :class="{ 'is-open': expanded.has(node.id) }" />
        </button>
        <span v-else class="sk-tree-expander-placeholder"></span>
        <input
          v-if="checkable"
          type="checkbox" class="sk-tree-check"
          :checked="isChecked(node)"
          :indeterminate.prop="isIndeterminate(node)"
          @click.stop
          @change="toggleCheck(node)"
        />
        <SkIconFolder v-if="!expanded.has(node.id)" class="sk-tree-folder-icon" />
        <SkIconFolderOpen v-else class="sk-tree-folder-icon" />
        <span class="sk-tree-name">{{ node.name }}</span>
        <span class="sk-tree-ops" @click.stop>
          <slot name="ops" :node="node" />
        </span>
      </div>
      <div v-if="node.children?.length && expanded.has(node.id)" class="sk-tree-children">
        <SkTree
          :nodes="node.children"
          :selected="selected"
          :depth="depth + 1"
          :checkable="checkable"
          :checked="checked"
          :default-expand-all="defaultExpandAll"
          :default-expand-depth="defaultExpandDepth != null ? defaultExpandDepth - 1 : undefined"
          @select="n => $emit('select', n)"
          @update:checked="ids => $emit('update:checked', ids)"
        >
          <template #ops="{ node }: { node: SkTreeNode }"><slot name="ops" :node="node" /></template>
        </SkTree>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
/**
 * 树（文件树）：展开/折叠 + 选中高亮；#ops 插槽渲染行悬停操作。
 * 节点结构 { id, name, children? }；默认展开全部。
 */
import { computed, ref, watch } from 'vue'
import { SkIconChevronRight, SkIconFolder, SkIconFolderOpen } from '../icons'

export interface SkTreeNode {
  id: number | string
  name: string
  children?: SkTreeNode[]
}

const props = withDefaults(
  defineProps<{
    nodes?: SkTreeNode[]
    selected?: number | string | null
    depth?: number
    /** 默认全展开；false 且未给 defaultExpandDepth 时全部收起 */
    defaultExpandAll?: boolean
    /** 默认展开到第 N 层（1=展开根节点，子级可见；0=全收起）；优先于 defaultExpandAll。递归子树按整树口径逐层递减（减到 0 即子树全收起） */
    defaultExpandDepth?: number
    /** 可勾选模式：行前 checkbox，父子联动（勾父全选后代、父勾选态由子代推导） */
    checkable?: boolean
    checked?: (string | number)[]
  }>(),
  { nodes: () => [], selected: null, depth: 0, defaultExpandAll: true, defaultExpandDepth: undefined, checkable: false, checked: () => [] },
)
const nodeList = computed<SkTreeNode[]>(() => props.nodes)
const emit = defineEmits<{ select: [node: SkTreeNode]; 'update:checked': [ids: (string | number)[]] }>()

// ── 勾选态（父子联动）：checked 为勾中的节点 id 集（含因全选子代而勾中的父）；
// 父框显示态不直接读集合，而是由子代推导（全选=勾、部分=indeterminate），
// 勾/取消一个节点时整棵子树的 id 一并加入/移出集合
const descendantIds = (node: SkTreeNode, out: (string | number)[] = []): (string | number)[] => {
  for (const c of node.children ?? []) { out.push(c.id); descendantIds(c, out) }
  return out
}
const isChecked = (node: SkTreeNode): boolean => {
  const kids = node.children ?? []
  if (!kids.length) return props.checked.map(String).includes(String(node.id))
  // 父节点：全部子代（含深层）勾中才算勾中
  const all = descendantIds(node)
  return all.length > 0 && all.every(id => props.checked.map(String).includes(String(id)))
}
const isIndeterminate = (node: SkTreeNode): boolean => {
  const all = descendantIds(node)
  const set = props.checked.map(String)
  const hit = all.filter(id => set.includes(String(id)))
  return hit.length > 0 && hit.length < all.length
}
function toggleCheck(node: SkTreeNode) {
  const on = !isChecked(node)
  const ids = new Set(props.checked.map(String))
  const targets = node.children?.length ? [...descendantIds(node), node.id] : [node.id]
  targets.forEach(id => on ? ids.add(String(id)) : ids.delete(String(id)))
  // 向上联动：任一祖先的后代全勾中则补勾祖先，否则移除祖先。
  // 仅对有子级的节点推导——叶子勾选态就是自身 id 在集合中，
  // 若无差别走 all.every 判定，叶子（后代为空）恒 false 会被误删：勾任何子树最终只剩父 id
  const fixAncestors = (list: SkTreeNode[]) => {
    for (const n of list) {
      const kids = n.children ?? []
      if (kids.length) {
        const all = descendantIds(n)
        if (all.every(id => ids.has(String(id)))) ids.add(String(n.id))
        else ids.delete(String(n.id))
        fixAncestors(kids)
      }
    }
  }
  fixAncestors(nodeList.value)
  emit('update:checked', [...ids])
}

/** 显式声明插槽类型：组件自递归渲染时打断插槽类型推断的循环引用 */
defineSlots<{ ops?: (props: { node: SkTreeNode }) => void }>()

/** 按 props 计算初始展开集：depth 优先（>0 展开到指定层，<=0 全收起），其次 all，默认全展开。
 * 注意兜底不能无脑全展开——defaultExpandAll=false 单独使用（全收起）与递归子树 depth 减到 0 都依赖空集分支 */
function initialExpanded(list: SkTreeNode[]): Set<number | string> {
  if (props.defaultExpandDepth != null) {
    return props.defaultExpandDepth > 0 ? new Set(collectToDepth(list, props.defaultExpandDepth)) : new Set()
  }
  return props.defaultExpandAll ? new Set(collect(list)) : new Set()
}
const expanded = ref<Set<number | string>>(initialExpanded(nodeList.value))

function collect(nodes: SkTreeNode[], out: (number | string)[] = []): (number | string)[] {
  for (const n of nodes) {
    if (n.children?.length) {
      out.push(n.id)
      collect(n.children, out)
    }
  }
  return out
}
/** 只收前 maxDepth 层的父节点（1=根节点，其子级可见） */
function collectToDepth(nodes: SkTreeNode[], maxDepth: number, out: (number | string)[] = [], depth = 0): (number | string)[] {
  for (const n of nodes) {
    if (n.children?.length && depth < maxDepth) {
      out.push(n.id)
      collectToDepth(n.children, maxDepth, out, depth + 1)
    }
  }
  return out
}
// 异步数据修复：挂载时节点常为空（展开集定型为空集，数据到达后整棵树收起），
// 首次从空变为有数据时按初始规则重算；用户已交互过（old 非空）则不再打扰
watch(nodeList, (list, old) => {
  if (!old.length && list.length) expanded.value = initialExpanded(list)
})
function toggle(id: number | string) {
  expanded.value.has(id) ? expanded.value.delete(id) : expanded.value.add(id)
}
</script>

<style>
.sk-tree { font-size: var(--sk-font-size-sm); }
.sk-tree-check { width: 13px; height: 13px; margin-right: 2px; flex-shrink: 0; accent-color: var(--sk-primary); cursor: pointer; }
.sk-tree-row {
  display: flex; align-items: center; gap: 4px;
  padding: 4px 8px 4px 4px; cursor: pointer; user-select: none;
  /* 触屏：禁用双击缩放等待，点按立即触发 click（否则 iOS 首次点按被吞、需要点两下） */
  touch-action: manipulation;
  border-left: 3px solid transparent; color: var(--sk-text);
}
.sk-tree-row:hover { background: var(--sk-hover); }
.sk-tree-row.is-active {
  background: var(--sk-accent-soft); border-left-color: var(--sk-accent-line); font-weight: 700;
}
.sk-tree-expander {
  width: 16px; height: 16px; display: inline-flex; align-items: center; justify-content: center;
  border: none; background: transparent; color: var(--sk-text-faint); cursor: pointer; padding: 0; font-size: 12px;
  flex-shrink: 0;
}
.sk-tree-expander:hover { color: var(--sk-text); }
.sk-tree-expander .is-open { transform: rotate(90deg); }
.sk-tree-expander-placeholder { width: 16px; flex-shrink: 0; }
/* 显式宽高（不依赖全局 .sk-icon 1em 约定）：svg 只带 viewBox 时无宽高会按 SVG2 默认撑满容器 */
.sk-tree-folder-icon { width: 14px; height: 14px; color: var(--sk-warning); font-size: 14px; flex-shrink: 0; }
.sk-tree-name { flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.sk-tree-ops { display: none; gap: 2px; flex-shrink: 0; }
.sk-tree-row:hover .sk-tree-ops { display: inline-flex; }
.sk-tree-ops .sk-icon { width: 13px; height: 13px; color: var(--sk-text-faint); cursor: pointer; padding: 2px; }
.sk-tree-ops .sk-icon:hover { color: var(--sk-link); }
.sk-tree-ops .sk-icon.is-danger:hover { color: var(--sk-danger); }
</style>

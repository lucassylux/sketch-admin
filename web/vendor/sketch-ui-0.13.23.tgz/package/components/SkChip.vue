<template>
  <button
    type="button"
    class="sk-chip"
    :class="{ 'is-active': active, 'is-disabled': disabled }"
    :disabled="disabled"
    @click="$emit('update:active', !active)"
  >
    <slot />
  </button>
</template>

<script setup lang="ts">
/** 圆角筛选片（2.html filter-chip）：active 态黄底加粗，常用于筛选条。 */
defineProps<{ active?: boolean; disabled?: boolean }>()
defineEmits<{ 'update:active': [v: boolean] }>()
</script>

<style>
.sk-chip {
  font-family: var(--sk-font); font-size: var(--sk-font-size-xs);
  border: 1.5px solid var(--sk-line-input); border-radius: var(--sk-radius-pill);
  padding: 3px 10px; background: var(--sk-surface); color: var(--sk-text-muted);
  cursor: pointer; white-space: nowrap;
}
.sk-chip:hover:not(.is-disabled) { border-color: var(--sk-text-faint); }
.sk-chip.is-active {
  background: var(--sk-accent-soft); border-color: var(--sk-text-faint);
  color: var(--sk-text); font-weight: 700;
}
.sk-chip.is-disabled { opacity: 0.45; cursor: not-allowed; }
</style>

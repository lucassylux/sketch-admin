<template>
  <div class="sk-chart-donut">
    <div class="sk-chart-donut-ring" :style="{ width: size + 'px', height: size + 'px' }">
      <svg :viewBox="`0 0 ${R2} ${R2}`" role="img">
        <circle :cx="R" :cy="R" :r="r" fill="none" stroke="var(--sk-muted-soft2)" :stroke-width="thickness" />
        <circle
          v-for="(seg, i) in segs"
          :key="i"
          :cx="R" :cy="R" :r="r" fill="none"
          :stroke="colorOf(i)"
          :stroke-width="hover === i ? thickness + 3 : thickness"
          :stroke-dasharray="`${seg.len} ${CIRC - seg.len}`"
          :stroke-dashoffset="-seg.offset"
          class="sk-chart-donut-seg"
          :class="{ 'is-hot': hover === i }"
          @mouseenter="hover = i"
          @mouseleave="hover = -1"
        />
      </svg>
      <div class="sk-chart-donut-center">
        <template v-if="hover >= 0">
          <span class="sk-chart-donut-value">{{ data[hover].label }}</span>
          <span class="sk-chart-donut-label">{{ data[hover].value }} · {{ pct(hover) }}%</span>
        </template>
        <template v-else>
          <span v-if="centerValue" class="sk-chart-donut-value">{{ centerValue }}</span>
          <span v-if="centerLabel" class="sk-chart-donut-label">{{ centerLabel }}</span>
        </template>
      </div>
    </div>
    <ul class="sk-chart-donut-legend">
      <li
        v-for="(d, i) in data"
        :key="i"
        :class="{ 'is-hot': hover === i }"
        @mouseenter="hover = i"
        @mouseleave="hover = -1"
      >
        <i :style="{ background: colorOf(i) }"></i>
        <span class="sk-chart-donut-name">{{ d.label }}</span>
        <span class="sk-chart-donut-val">{{ pct(i) }}%</span>
      </li>
    </ul>
  </div>
</template>

<script setup lang="ts">
/**
 * 环形图（5/7/8.html 支出分类、销售渠道、流量来源）：
 * SVG 圆弧分段 + 图例；分段/图例 hover 联动——加粗描边且中心切换显示该项；
 * 颜色取主题图表色板。
 */
import { computed, ref } from 'vue'

const props = withDefaults(
  defineProps<{
    data: { label: string; value: number; color?: string }[]
    size?: number
    thickness?: number
    centerValue?: string
    centerLabel?: string
  }>(),
  { size: 120, thickness: 14 },
)

const R2 = 100
const R = 50
const r = 42
const CIRC = 2 * Math.PI * r

const hover = ref(-1)

const total = computed(() => props.data.reduce((a, d) => a + d.value, 0) || 1)

const segs = computed(() => {
  let acc = 0
  return props.data.map(d => {
    const len = (d.value / total.value) * CIRC
    const seg = { len, offset: acc }
    acc += len
    return seg
  })
})

function pct(i: number) {
  return Math.round((props.data[i].value / total.value) * 100)
}
function colorOf(i: number) {
  return props.data[i]?.color || `var(--sk-chart-${(i % 5) + 1})`
}
</script>

<style>
.sk-chart-donut { display: flex; align-items: center; gap: 16px; flex-wrap: wrap; }
.sk-chart-donut-ring { position: relative; flex-shrink: 0; }
.sk-chart-donut-ring svg { width: 100%; height: 100%; transform: rotate(-90deg); }
.sk-chart-donut-seg { transition: stroke-dasharray 0.3s, stroke-width 0.12s; cursor: pointer; }
.sk-chart-donut-center {
  position: absolute; inset: 0; display: flex; flex-direction: column;
  align-items: center; justify-content: center; text-align: center; pointer-events: none;
}
.sk-chart-donut-value { font-size: var(--sk-font-size-lg); font-weight: 700; line-height: 1.15; }
.sk-chart-donut-label { font-size: var(--sk-font-size-xs); color: var(--sk-text-muted); }
.sk-chart-donut-legend { list-style: none; display: flex; flex-direction: column; gap: 6px; min-width: 120px; }
.sk-chart-donut-legend li {
  display: flex; align-items: center; gap: 7px; font-size: var(--sk-font-size-sm);
  padding: 2px 4px; border-radius: var(--sk-radius); cursor: pointer;
}
.sk-chart-donut-legend li.is-hot { background: var(--sk-hover); }
.sk-chart-donut-legend i { width: 9px; height: 9px; border-radius: 2px; flex-shrink: 0; }
.sk-chart-donut-name { color: var(--sk-text); flex: 1; }
.sk-chart-donut-val { color: var(--sk-text-faint); font-variant-numeric: tabular-nums; }
</style>

<template>
  <button
    type="button"
    class="sk-switch"
    :class="{ 'is-on': modelValue, 'is-disabled': disabled }"
    role="switch"
    :aria-checked="modelValue"
    :disabled="disabled"
    @click="$emit('update:modelValue', !modelValue)"
  >
    <span class="sk-switch-knob"></span>
  </button>
</template>

<script setup lang="ts">
/** 拨动开关（2.html settings / 4.html profile 的 toggle-switch）。 */
defineProps<{ modelValue?: boolean; disabled?: boolean }>()
defineEmits<{ 'update:modelValue': [v: boolean] }>()
</script>

<style>
.sk-switch {
  width: 34px; height: 18px; padding: 0;
  border: 1.5px solid var(--sk-line-input); border-radius: 9px;
  background: var(--sk-surface); position: relative; cursor: pointer; flex-shrink: 0;
}
.sk-switch.is-disabled { opacity: 0.45; cursor: not-allowed; }
.sk-switch-knob {
  position: absolute; top: 2px; left: 2px;
  width: 11px; height: 11px; border-radius: 50%;
  background: var(--sk-text-faint); transition: left 0.15s, background 0.15s;
}
.sk-switch.is-on { background: var(--sk-ink); border-color: var(--sk-ink); }
.sk-switch.is-on .sk-switch-knob { left: 18px; background: var(--sk-surface); }
</style>

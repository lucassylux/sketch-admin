<template>
  <div class="sk-sidebar-group">
    <div v-if="label && !collapsed" class="sk-sidebar-group-label">{{ label }}</div>
    <div v-else-if="label" class="sk-sidebar-group-gap"></div>
    <slot />
  </div>
</template>

<script setup lang="ts">
/**
 * 侧边栏分组（OVERVIEW / MAIN MENU 等小节标题）；折叠时仅保留间距。
 */
import { inject, ref, type Ref } from 'vue'

defineProps<{ label?: string }>()
const collapsed = inject<Ref<boolean>>('skSidebarCollapsed', ref(false))
</script>

<style>
.sk-sidebar-group { display: flex; flex-direction: column; margin-bottom: 4px; }
.sk-sidebar-group-label {
  font-size: var(--sk-font-size-xs); color: var(--sk-sidebar-muted);
  padding: 10px 14px 3px; letter-spacing: 0.1em; text-transform: uppercase;
  white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
}
.sk-sidebar-group-gap { height: 10px; }
</style>

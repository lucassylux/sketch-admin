<template>
  <Teleport to="body">
    <div v-if="open" ref="menuRef" class="sk-dropdown" :class="{ 'sk-dropdown-icons': hasIcons }" :style="pos" @click.stop>
      <template v-for="(item, i) in items" :key="item.key ?? i">
        <div v-if="item.divider" class="sk-dropdown-divider"></div>
        <button
          v-else
          type="button"
          class="sk-dropdown-item"
          :class="{ 'is-danger': item.danger, 'is-disabled': item.disabled }"
          :disabled="item.disabled"
          @click="onSelect(item)"
        >
          <span v-if="item.icon || hasIcons" class="sk-dropdown-icon">
            <component :is="item.icon" v-if="item.icon" />
          </span>
          {{ item.label }}
        </button>
      </template>
    </div>
  </Teleport>
</template>

<script setup lang="ts">
/**
 * 右键上下文菜单：openAt(x, y) 在鼠标位置打开（右侧/底部溢出自动翻转），
 * Esc / 点击外部 / 滚动 关闭；select 事件回传 key。
 * 菜单视觉复用 .sk-dropdown* 全局样式（定义于 SkDropdown.vue，随库常驻）。
 */
import { computed, nextTick, onBeforeUnmount, ref } from 'vue'
import type { SkDropdownItem } from './SkDropdown.vue'

const props = defineProps<{ items: SkDropdownItem[] }>()
const emit = defineEmits<{ select: [key: string | number] }>()

/** 菜单内任一项带图标时，所有项保留等宽图标列，保证文字对齐 */
const hasIcons = computed(() => props.items.some(i => i.icon))

const open = ref(false)
const menuRef = ref<HTMLElement>()
const pos = ref<{ left: string; top: string }>({ left: '0px', top: '0px' })

async function openAt(x: number, y: number) {
  open.value = true
  await nextTick()
  const menuW = menuRef.value?.offsetWidth ?? 160
  const menuH = menuRef.value?.offsetHeight ?? 0
  let left = x
  if (left + menuW + 8 > window.innerWidth) left = Math.max(8, window.innerWidth - menuW - 8)
  let top = y + 4
  if (top + menuH > window.innerHeight - 8) top = Math.max(8, y - menuH - 4)
  pos.value = { left: `${Math.round(left)}px`, top: `${Math.round(top)}px` }
  document.addEventListener('mousedown', onDocDown, true)
  document.addEventListener('keydown', onKey)
  window.addEventListener('scroll', close, true)
  window.addEventListener('resize', close)
}
function close() {
  if (!open.value) return
  open.value = false
  document.removeEventListener('mousedown', onDocDown, true)
  document.removeEventListener('keydown', onKey)
  window.removeEventListener('scroll', close, true)
  window.removeEventListener('resize', close)
}
function onDocDown(e: MouseEvent) {
  if (menuRef.value?.contains(e.target as Node)) return
  close()
}
function onKey(e: KeyboardEvent) {
  if (e.key === 'Escape') close()
}
function onSelect(item: SkDropdownItem) {
  if (item.disabled) return
  close()
  if (item.key != null) emit('select', item.key)
}
onBeforeUnmount(close)
defineExpose({ openAt, close })
</script>

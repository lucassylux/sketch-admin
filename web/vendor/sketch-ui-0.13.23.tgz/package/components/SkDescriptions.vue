<template>
  <div class="sk-desc" :class="{ 'is-bordered': bordered, 'sk-desc-sm': size === 'sm' }" :style="column > 1 ? { gridTemplateColumns: `repeat(${column}, minmax(0, 1fr))` } : undefined">
    <slot />
  </div>
</template>

<script setup lang="ts">
/**
 * 描述列表：label + 内容成组展示；
 * column=1 纵向行（label 左 content 右），>1 网格平铺；bordered 加框线单元格。
 */
withDefaults(
  defineProps<{
    column?: number
    bordered?: boolean
    size?: 'sm' | 'md'
  }>(),
  { column: 1, bordered: false, size: 'md' },
)
</script>

<style>
.sk-desc { display: grid; grid-template-columns: minmax(88px, auto) 1fr; gap: 1px; align-items: stretch; }
.sk-desc-item { display: contents; }
.sk-desc-label {
  padding: 7px 10px; color: var(--sk-text-muted); font-size: var(--sk-font-size-sm);
  white-space: nowrap; background: var(--sk-muted-soft2, transparent);
}
.sk-desc-body { padding: 7px 4px 7px 0; font-size: var(--sk-font-size-base); color: var(--sk-text); min-width: 0; word-break: break-word; }
/* bordered 形态：整表框线，label 独立单元格底色 */
.sk-desc.is-bordered { border: var(--sk-border-thin); gap: 0; }
.sk-desc.is-bordered .sk-desc-label { border-right: var(--sk-border-cell); background: var(--sk-muted-soft2); }
.sk-desc.is-bordered .sk-desc-body { padding: 7px 10px; }
.sk-desc.is-bordered .sk-desc-item + .sk-desc-item .sk-desc-label,
.sk-desc.is-bordered .sk-desc-item + .sk-desc-item .sk-desc-body { border-top: var(--sk-border-cell); }
.sk-desc-sm .sk-desc-label, .sk-desc-sm .sk-desc-body { padding-top: 5px; padding-bottom: 5px; font-size: var(--sk-font-size-sm); }
</style>

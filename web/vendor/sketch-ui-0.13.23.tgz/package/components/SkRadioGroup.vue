<template>
  <div v-if="!buttons" class="sk-radio-group">
    <label v-for="o in options" :key="String(o.value)" class="sk-radio">
      <input
        type="radio"
        :name="name || groupName"
        :value="o.value"
        :checked="String(modelValue) === String(o.value)"
        :disabled="o.disabled"
        @change="$emit('update:modelValue', o.value)"
      />
      <span>{{ o.label }}</span>
    </label>
  </div>
  <div v-else class="sk-segmented" role="radiogroup">
    <button
      v-for="o in options"
      :key="String(o.value)"
      type="button"
      class="sk-segmented-item"
      :class="{ 'is-active': String(modelValue) === String(o.value) }"
      :disabled="o.disabled"
      @click="$emit('update:modelValue', o.value)"
    >
      {{ o.label }}
    </button>
  </div>
</template>

<script setup lang="ts">
/**
 * 单选组：默认平铺 radio；buttons=true 渲染为连体按钮组（线框风拼接边框，选中黄底）。
 */
const groupName = `sk-radio-${Math.random().toString(36).slice(2, 9)}`

export interface SkRadioOption { value: string | number; label: string; disabled?: boolean }

withDefaults(
  defineProps<{
    modelValue?: string | number
    options: SkRadioOption[]
    buttons?: boolean
    name?: string
  }>(),
  {},
)
defineEmits<{ 'update:modelValue': [v: string | number] }>()
</script>

<style>
.sk-radio-group { display: flex; gap: 14px; flex-wrap: wrap; }
.sk-radio {
  display: inline-flex; align-items: center; gap: 5px;
  font-family: var(--sk-font); font-size: var(--sk-font-size-sm); cursor: pointer; user-select: none;
}
.sk-radio input { accent-color: var(--sk-primary); width: 13px; height: 13px; }

.sk-segmented { display: inline-flex; }
.sk-segmented-item {
  font-family: var(--sk-font); font-size: var(--sk-font-size-sm);
  height: var(--sk-control-h-sm); padding: 0 12px;
  border: 1.5px solid var(--sk-ink); background: var(--sk-surface); color: var(--sk-text);
  cursor: pointer; margin-right: -1.5px; position: relative;
}
.sk-segmented-item:first-child { border-top-left-radius: var(--sk-radius-btn, var(--sk-radius)); border-bottom-left-radius: var(--sk-radius-btn, var(--sk-radius)); }
.sk-segmented-item:last-child { margin-right: 0; border-top-right-radius: var(--sk-radius-btn, var(--sk-radius)); border-bottom-right-radius: var(--sk-radius-btn, var(--sk-radius)); }
.sk-segmented-item.is-active { background: var(--sk-accent); z-index: 1; font-weight: 700; }
.sk-segmented-item:not(.is-active):hover { background: var(--sk-hover); }
.sk-segmented-item:disabled { color: var(--sk-text-faint); cursor: not-allowed; background: var(--sk-muted-soft2); }
</style>

<template>
  <div class="sk-setting">
    <div class="sk-setting-info">
      <div class="sk-setting-title">{{ title }}</div>
      <div v-if="desc" class="sk-setting-desc">{{ desc }}</div>
    </div>
    <slot />
  </div>
</template>

<script setup lang="ts">
/** 设置行（2.html settings-row / 4.html setting-row）：左标题描述 + 右侧控件（通常 SkSwitch）。 */
defineProps<{ title: string; desc?: string }>()
</script>

<style>
.sk-setting {
  display: flex; align-items: center; gap: 14px;
  padding: 9px 12px; border: 1.5px solid var(--sk-line-cell);
  border-radius: var(--sk-radius); background: var(--sk-surface); margin-bottom: 6px;
  font-size: var(--sk-font-size-base);
}
.sk-setting-info { flex: 1; min-width: 0; }
.sk-setting-title { font-weight: 700; }
.sk-setting-desc { font-size: var(--sk-font-size-xs); color: var(--sk-text-faint); margin-top: 2px; }
</style>

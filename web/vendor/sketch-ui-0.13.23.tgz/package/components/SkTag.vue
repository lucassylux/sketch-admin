<template>
  <span class="sk-tag" :class="color !== 'default' ? `sk-tag-${color}` : ''">
    <slot />
    <button v-if="closable" type="button" class="sk-tag-close" aria-label="移除" @click="$emit('close')">✕</button>
  </span>
</template>

<script setup lang="ts">
/**
 * 状态胶囊：软底 + 同色描边（对应线框稿 status-pill）。
 * 颜色语义化：success/warning/danger/info/muted/default。
 * closable：尾部渲染 ✕，点击 emit('close')（如选人组件已选标签的移除）。
 */
withDefaults(defineProps<{
  color?: 'default' | 'success' | 'warning' | 'danger' | 'info' | 'muted'
  closable?: boolean
}>(), {
  color: 'default',
})
defineEmits<{ (e: 'close'): void }>()
</script>

<style>
.sk-tag {
  display: inline-block; font-family: var(--sk-font); font-size: var(--sk-font-size-xs);
  padding: 1px 6px; border-radius: var(--sk-radius-pill); white-space: nowrap;
  border: 1px solid currentColor; line-height: 1.5; vertical-align: middle;
}
.sk-tag-close {
  border: none; background: none; padding: 0 0 0 4px; margin: 0;
  font: inherit; font-size: 10px; line-height: 1; color: inherit;
  cursor: pointer; opacity: .6; vertical-align: middle;
}
.sk-tag-close:hover { opacity: 1; }
.sk-tag-default { color: var(--sk-muted); background: var(--sk-muted-soft); }
.sk-tag-success { color: var(--sk-success); background: var(--sk-success-soft); }
.sk-tag-warning { color: var(--sk-warning); background: var(--sk-warning-soft2); }
.sk-tag-danger { color: var(--sk-danger); background: var(--sk-danger-soft2); }
.sk-tag-info { color: var(--sk-info); background: var(--sk-info-soft); }
.sk-tag-muted { color: var(--sk-muted); background: var(--sk-muted-soft2); }
</style>

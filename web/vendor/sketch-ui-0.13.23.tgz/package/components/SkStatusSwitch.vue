<template>
  <span class="sk-status-switch">
    <SkSwitch :model-value="on" @update:model-value="$emit('update:modelValue', $event ? 1 : 0)" />
    <span class="sk-status-hint">{{ on ? activeText : inactiveText }}</span>
  </span>
</template>

<script setup lang="ts">
/**
 * 状态开关行：SkSwitch + 右侧实时文字提示（启用/停用等）。
 * modelValue 为 0/1 数值（与后端 status 列同口径），组件内部转换布尔；
 * 文案可自定义（activeText/inactiveText），默认启用/停用。
 */
import { computed } from 'vue'
import SkSwitch from './SkSwitch.vue'

const props = withDefaults(
  defineProps<{
    /** 0/1 数值状态（true/false 亦可，内部归一） */
    modelValue: number | boolean
    activeText?: string
    inactiveText?: string
  }>(),
  { activeText: '启用', inactiveText: '停用' },
)

defineEmits<{ 'update:modelValue': [v: number] }>()

const on = computed(() => props.modelValue === 1 || props.modelValue === true)
</script>

<style>
.sk-status-switch { display: inline-flex; align-items: center; gap: 8px; }
.sk-status-hint { color: var(--sk-text-faint, #999); font-size: 13px; }
</style>

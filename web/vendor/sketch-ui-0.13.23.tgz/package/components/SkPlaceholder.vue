<template>
  <div class="sk-placeholder" :style="{ height: height + 'px' }">
    <span class="sk-placeholder-label"><slot>{{ label }}</slot></span>
  </div>
</template>

<script setup lang="ts">
/**
 * 占位框（对应线框稿 map-placeholder）：斜纹底 + 居中虚线标签，
 * 地图/图表等未实装区域的通用占位。
 */
withDefaults(
  defineProps<{
    label?: string
    height?: number
  }>(),
  { height: 180 },
)
</script>

<style>
.sk-placeholder {
  position: relative; overflow: hidden;
  border: var(--sk-border); border-radius: var(--sk-radius-card, var(--sk-radius));
  background: var(--sk-surface-dim);
  display: flex; align-items: center; justify-content: center;
}
.sk-placeholder::before {
  content: ''; position: absolute; inset: 0;
  background-image: repeating-linear-gradient(45deg,
    transparent, transparent 18px,
    color-mix(in srgb, var(--sk-ink) 6%, transparent) 18px,
    color-mix(in srgb, var(--sk-ink) 6%, transparent) 19px);
}
.sk-placeholder-label {
  position: relative; z-index: 1;
  border: 1.5px dashed var(--sk-line-input); border-radius: var(--sk-radius-card, var(--sk-radius));
  padding: 6px 16px; font-size: var(--sk-font-size-base); color: var(--sk-text-muted);
  background: color-mix(in srgb, var(--sk-paper) 80%, transparent);
}
</style>

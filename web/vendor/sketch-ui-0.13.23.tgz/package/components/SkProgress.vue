<template>
  <div class="sk-progress" :style="{ height: height + 'px' }">
    <div class="sk-progress-fill" :class="`sk-progress-${tone}`" :style="{ width: clamped + '%' }"></div>
  </div>
</template>

<script setup lang="ts">
/**
 * 进度条：斜纹填充（对应线框稿 score-bar）。tone 控制填充用色。
 */
const props = withDefaults(
  defineProps<{ value: number; tone?: 'ink' | 'success' | 'warning' | 'danger' | 'info'; height?: number }>(),
  { tone: 'ink', height: 10 },
)
import { computed } from 'vue'
const clamped = computed(() => Math.max(0, Math.min(100, props.value)))
</script>

<style>
.sk-progress {
  width: 100%; background: var(--sk-muted-soft2);
  border: 1px solid var(--sk-muted-line); border-radius: 1px; overflow: hidden;
}
.sk-progress-fill { height: 100%; transition: width 0.25s; }
.sk-progress-ink { background: repeating-linear-gradient(90deg, var(--sk-ink) 0px, var(--sk-ink) 4px, transparent 4px, transparent 7px); }
.sk-progress-success { background: repeating-linear-gradient(90deg, var(--sk-success) 0px, var(--sk-success) 4px, transparent 4px, transparent 7px); }
.sk-progress-warning { background: repeating-linear-gradient(90deg, var(--sk-warning) 0px, var(--sk-warning) 4px, transparent 4px, transparent 7px); }
.sk-progress-danger { background: repeating-linear-gradient(90deg, var(--sk-danger) 0px, var(--sk-danger) 4px, transparent 4px, transparent 7px); }
.sk-progress-info { background: repeating-linear-gradient(90deg, var(--sk-info) 0px, var(--sk-info) 4px, transparent 4px, transparent 7px); }
</style>

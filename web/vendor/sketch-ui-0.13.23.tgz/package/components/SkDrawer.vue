<template>
  <Teleport to="body">
    <Transition name="sk-drawer">
      <div v-if="open" class="sk-drawer-root" @click.self="onMask">
        <div class="sk-drawer" :style="{ width: typeof width === 'number' ? width + 'px' : width }" role="dialog" aria-modal="true">
          <div class="sk-drawer-head">
            <div class="sk-drawer-title"><slot name="title">{{ title }}</slot></div>
            <button type="button" class="sk-modal-close" title="关闭" @click="requestClose">
              <SkIconClose />
            </button>
          </div>
          <div class="sk-drawer-body"><slot /></div>
          <div v-if="$slots.footer" class="sk-drawer-foot"><slot name="footer" /></div>
        </div>
      </div>
    </Transition>
  </Teleport>
</template>

<script setup lang="ts">
/**
 * 抽屉：右侧滑入面板（版本历史等），行为对齐 SkModal。
 */
import { onBeforeUnmount, watch } from 'vue'
import { SkIconClose } from '../icons'

const props = withDefaults(
  defineProps<{
    open: boolean
    title?: string
    width?: number | string
    maskClosable?: boolean
  }>(),
  { width: 520, maskClosable: true },
)
const emit = defineEmits<{ 'update:open': [v: boolean]; close: [] }>()

function requestClose() {
  emit('update:open', false)
  emit('close')
}
function onMask() {
  if (props.maskClosable) requestClose()
}
function onKey(e: KeyboardEvent) {
  if (e.key === 'Escape' && props.open) requestClose()
}
watch(
  () => props.open,
  v => {
    document.removeEventListener('keydown', onKey)
    if (v) {
      document.addEventListener('keydown', onKey)
      document.body.style.overflow = 'hidden'
    } else {
      document.body.style.overflow = ''
    }
  },
)
onBeforeUnmount(() => {
  document.removeEventListener('keydown', onKey)
  document.body.style.overflow = ''
})
</script>

<style>
.sk-drawer-root {
  position: fixed; inset: 0; z-index: 2000;
  display: flex; justify-content: flex-end;
  background: var(--sk-mask);
}
.sk-drawer {
  height: 100%; display: flex; flex-direction: column;
  background: var(--sk-paper); border-left: var(--sk-border);
  box-shadow: var(--sk-shadow-overlay); max-width: 100%;
}
.sk-drawer-head {
  display: flex; align-items: center; justify-content: space-between; gap: 10px;
  padding: 10px 14px; border-bottom: var(--sk-border); background: var(--sk-surface-dim); flex-shrink: 0;
}
.sk-drawer-title { font-size: var(--sk-font-size-md); font-weight: 700; letter-spacing: 0.03em; }
.sk-drawer-body { flex: 1; overflow: auto; padding: 14px 16px; }
.sk-drawer-foot {
  display: flex; justify-content: flex-end; gap: 8px;
  padding: 12px 16px; border-top: var(--sk-border-divider); flex-shrink: 0;
}

.sk-drawer-enter-active, .sk-drawer-leave-active { transition: opacity 0.18s; }
.sk-drawer-enter-active .sk-drawer, .sk-drawer-leave-active .sk-drawer { transition: transform 0.18s ease-out; }
.sk-drawer-enter-from, .sk-drawer-leave-to { opacity: 0; }
.sk-drawer-enter-from .sk-drawer, .sk-drawer-leave-to .sk-drawer { transform: translateX(40px); }
</style>

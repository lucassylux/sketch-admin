<template>
  <div class="sk-calendar">
    <div class="sk-cal-head" v-for="w in weekHeads" :key="w">{{ w }}</div>
    <template v-for="(cell, i) in cells" :key="i">
      <div
        class="sk-cal-cell"
        :class="{ 'is-today': cell.isToday, 'is-other': !cell.inMonth }"
        @click="$emit('pick', cell)"
      >
        <span class="sk-cal-day">{{ cell.day }}</span>
        <div v-for="(ev, j) in cell.events" :key="j" class="sk-cal-event" :class="{ 'is-accent': j === 0 }">{{ ev }}</div>
      </div>
    </template>
  </div>
</template>

<script setup lang="ts">
/**
 * 月历（4.html cal-grid）：7 列格；今日黄底粗框；跨月日弱化；
 * events 按 'YYYY-MM-DD' 键传入，pick 事件回传单元格。
 */
import { computed } from 'vue'

const props = withDefaults(
  defineProps<{
    year?: number
    month?: number
    events?: Record<string, string[]>
  }>(),
  {},
)
defineEmits<{ pick: [cell: { date: string; day: number; inMonth: boolean; isToday: boolean; events: string[] }] }>()

const weekHeads = ['一', '二', '三', '四', '五', '六', '日']
const now = new Date()
const year = props.year ?? now.getFullYear()
const month = props.month ?? now.getMonth() + 1

interface Cell { date: string; day: number; inMonth: boolean; isToday: boolean; events: string[] }

const cells = computed<Cell[]>(() => {
  const first = new Date(year, month - 1, 1)
  // 周一为一周起点：JS getDay() 周日=0 → 偏移 (day+6)%7
  const offset = (first.getDay() + 6) % 7
  const start = new Date(first)
  start.setDate(1 - offset)
  const todayKey = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`
  return Array.from({ length: 42 }, (_, i) => {
    const d = new Date(start)
    d.setDate(start.getDate() + i)
    const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`
    return {
      date: key,
      day: d.getDate(),
      inMonth: d.getMonth() + 1 === month,
      isToday: key === todayKey,
      events: props.events?.[key] ?? [],
    }
  })
})
</script>

<style>
.sk-calendar { display: grid; grid-template-columns: repeat(7, 1fr); gap: 3px; }
.sk-cal-head {
  text-align: center; font-size: var(--sk-font-size-xs); font-weight: 700;
  color: var(--sk-text-muted); padding: 3px 0;
}
.sk-cal-cell {
  min-height: 56px; border: 1.5px solid var(--sk-line-cell);
  border-radius: var(--sk-radius); padding: 3px 4px;
  background: var(--sk-surface); font-size: var(--sk-font-size-xs);
  color: var(--sk-text-muted); cursor: pointer; overflow: hidden;
}
.sk-cal-cell:hover { background: var(--sk-hover); }
.sk-cal-cell.is-today { border: 2px solid var(--sk-ink); background: var(--sk-accent); color: var(--sk-text); font-weight: 700; }
.sk-cal-cell.is-other { color: var(--sk-text-faint); background: var(--sk-surface-alt); opacity: 0.55; }
.sk-cal-event {
  background: var(--sk-surface-dim); border-radius: 2px; font-size: 8px;
  padding: 1px 3px; margin-top: 2px; white-space: nowrap;
  overflow: hidden; text-overflow: ellipsis; color: var(--sk-text-muted);
}
.sk-cal-event.is-accent { background: var(--sk-ink); color: var(--sk-surface); }
</style>

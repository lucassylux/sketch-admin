<template>
  <span class="sk-tooltip" :data-tip="title" tabindex="0">
    <slot />
  </span>
</template>

<script setup lang="ts">
/**
 * 悬停提示：
 * CSS ::after 实现，无 JS 依赖；title 支持多行（\n 换行）。
 * 包裹子元素，hover/focus 时在上方弹出。
 */
defineProps<{ title?: string }>()
</script>

<style>
.sk-tooltip { position: relative; display: inline-flex; cursor: help; }
.sk-tooltip::after {
  content: attr(data-tip);
  position: absolute;
  bottom: calc(100% + 6px);
  left: 50%;
  transform: translateX(-50%);
  padding: 5px 10px;
  background: var(--sk-ink);
  color: var(--sk-surface);
  font-size: var(--sk-font-size-xs);
  line-height: 1.5;
  border-radius: var(--sk-radius-btn, var(--sk-radius));
  box-shadow: var(--sk-shadow-pop);
  white-space: pre;
  pointer-events: none;
  opacity: 0;
  transition: opacity 0.15s;
  z-index: 100;
  max-width: 320px;
  overflow: hidden;
  text-overflow: ellipsis;
}
/* 上方放不下时往下弹 */
.sk-tooltip::after { top: auto; }
.sk-tooltip:hover::after,
.sk-tooltip:focus::after { opacity: 1; }
/* 尾巴 */
.sk-tooltip::before {
  content: '';
  position: absolute;
  bottom: calc(100% + 1px);
  left: 50%;
  transform: translateX(-50%);
  border: 5px solid transparent;
  border-top-color: var(--sk-ink);
  opacity: 0;
  transition: opacity 0.15s;
  z-index: 101;
  pointer-events: none;
}
.sk-tooltip:hover::before,
.sk-tooltip:focus::before { opacity: 1; }
</style>

<template>
  <div class="sk-card" :class="{ 'sk-card-flush': flush }">
    <div v-if="title || $slots.title || $slots.extra" class="sk-card-title">
      <slot name="title">{{ title }}</slot>
      <span v-if="$slots.extra" class="sk-card-extra"><slot name="extra" /></span>
    </div>
    <slot />
  </div>
</template>

<script setup lang="ts">
/**
 * 卡片：墨色 2px 实线边框 + 白底（对应线框稿 detail-card）。
 * title 走属性或 #title 插槽（可放状态图标）；flush 去内边距（内部自排时用）。
 */
withDefaults(defineProps<{ title?: string; flush?: boolean }>(), {})
</script>

<style>
.sk-card {
  border: var(--sk-border); border-radius: var(--sk-radius-card, var(--sk-radius));
  background: var(--sk-surface); padding: 12px 14px;
}
.sk-card-flush { padding: 0; }
.sk-card-title {
  font-family: var(--sk-font); font-size: var(--sk-font-size-sm); font-weight: 700;
  text-transform: uppercase; letter-spacing: 0.08em; color: var(--sk-text-muted);
  /* 行高+盒高锁整数 px：卡片标题在页签上方，extra 文本字形行高会把盒子撑出小数（27.52 实录），
   * 进而把下方页签底线推到亚像素相位 */
  line-height: 20px; height: 26px; align-items: center;
  margin: 0 0 10px; padding-bottom: 6px;
  border-bottom: var(--sk-border-divider);
  display: flex; align-items: center; gap: 8px;
}
.sk-card-flush .sk-card-title { margin: 0; padding: 10px 14px; }
.sk-card-extra { margin-left: auto; font-weight: 400; text-transform: none; letter-spacing: 0; }
</style>

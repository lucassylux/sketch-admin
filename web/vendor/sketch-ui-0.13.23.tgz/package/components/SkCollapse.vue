<template>
  <div class="sk-collapse">
    <div v-for="(item, i) in items" :key="item.key ?? i" class="sk-collapse-panel" :class="{ 'is-open': isOpen(item) }">
      <button type="button" class="sk-collapse-head" :aria-expanded="isOpen(item)" @click="toggle(item)">
        <span class="sk-collapse-arrow" aria-hidden="true">›</span>
        <span class="sk-collapse-title">{{ item.title }}</span>
        <span v-if="item.extra" class="sk-collapse-extra">{{ item.extra }}</span>
      </button>
      <div v-show="isOpen(item)" class="sk-collapse-body">
        <slot :name="item.key ?? String(i)" :item="item" />
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
/**
 * 折叠面板：items 驱动；accordion 时仅一开；
 * 面板内容用具名插槽（key）。支持 v-model:activeKey（数组；accordion 时取首个）。
 */
import { computed } from 'vue'

export interface SkCollapseItem {
  key?: string
  title: string
  extra?: string
  disabled?: boolean
}

const props = withDefaults(
  defineProps<{
    items: SkCollapseItem[]
    modelValue?: (string | number)[]
    accordion?: boolean
  }>(),
  { modelValue: () => [], accordion: false },
)
const emit = defineEmits<{ 'update:modelValue': [v: (string | number)[]] }>()

const keyOf = (item: SkCollapseItem, i: number) => item.key ?? String(i)

const isOpen = (item: SkCollapseItem) => {
  const i = props.items.indexOf(item)
  return props.modelValue.includes(keyOf(item, i))
}

function toggle(item: SkCollapseItem) {
  if (item.disabled) return
  const i = props.items.indexOf(item)
  const k = keyOf(item, i)
  if (props.accordion) {
    emit('update:modelValue', isOpen(item) ? [] : [k])
    return
  }
  emit('update:modelValue', isOpen(item) ? props.modelValue.filter(x => x !== k) : [...props.modelValue, k])
}

const openCount = computed(() => props.items.filter(isOpen).length)
defineExpose({ openCount })
</script>

<style>
.sk-collapse { display: flex; flex-direction: column; gap: 6px; }
.sk-collapse-panel { border: var(--sk-border-thin); border-radius: var(--sk-radius-card, var(--sk-radius)); background: var(--sk-surface); overflow: hidden; }
.sk-collapse-head {
  width: 100%; display: flex; align-items: center; gap: 8px;
  padding: 9px 12px; cursor: pointer; border: none; background: none;
  font-family: var(--sk-font); font-size: var(--sk-font-size-base); color: var(--sk-text); text-align: left;
}
.sk-collapse-head:hover { background: var(--sk-hover); }
.sk-collapse-arrow { display: inline-block; transition: transform 0.18s; color: var(--sk-text-faint); font-size: 13px; }
.sk-collapse-panel.is-open .sk-collapse-arrow { transform: rotate(90deg); }
.sk-collapse-title { font-weight: 600; flex: 1; min-width: 0; }
.sk-collapse-extra { font-size: var(--sk-font-size-xs); color: var(--sk-text-faint); font-weight: 400; }
.sk-collapse-body { padding: 4px 12px 12px; border-top: var(--sk-border-divider); }
</style>

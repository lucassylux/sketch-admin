<template>
  <div class="sk-section-label"><slot /></div>
</template>

<script setup lang="ts">
/** 区块标签：小节标题 + 尾随虚线（对应线框稿 section-label）。 */
</script>

<style>
.sk-section-label {
  display: flex; align-items: center; gap: 6px;
  font-size: var(--sk-font-size-xs); font-weight: 700;
  text-transform: uppercase; letter-spacing: 0.1em; color: var(--sk-text-faint);
  margin-bottom: 8px;
}
.sk-section-label::after {
  content: ''; flex: 1; height: 1px;
  background: repeating-linear-gradient(90deg, var(--sk-line-cell) 0px, var(--sk-line-cell) 4px, transparent 4px, transparent 8px);
}
</style>

<template>
  <span class="sk-member-chip">
    <SkAvatar :char="name.charAt(0)" size="sm" />
    <span class="sk-member-chip-name">{{ name }}</span>
    <SkIconClose v-if="closable" class="sk-member-chip-close" @click="$emit('close')" />
  </span>
</template>

<script setup lang="ts">
/** 成员芯片（4.html member-chip）：圆角胶囊 = 小头像 + 名字，可关闭。 */
import { SkIconClose } from '../icons'

defineProps<{ name: string; closable?: boolean }>()
defineEmits<{ close: [] }>()
</script>

<style>
.sk-member-chip {
  display: inline-flex; align-items: center; gap: 6px;
  border: 1.5px solid var(--sk-line-faint); border-radius: var(--sk-radius-pill);
  padding: 2px 10px 2px 4px; background: var(--sk-surface);
  font-size: var(--sk-font-size-sm); margin: 3px;
}
.sk-member-chip-close { width: 11px; height: 11px; color: var(--sk-text-faint); cursor: pointer; }
.sk-member-chip-close:hover { color: var(--sk-danger); }
</style>

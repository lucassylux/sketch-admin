<template>
  <div class="sk-desc-item">
    <div class="sk-desc-label">{{ label }}</div>
    <div class="sk-desc-body"><slot /></div>
  </div>
</template>

<script setup lang="ts">
/** 描述列表项：label + 内容插槽（父级 SkDescriptions 决定布局形态） */
defineProps<{ label?: string }>()
</script>

<template>
  <div class="sk-member-card" :class="{ 'is-highlight': highlight }">
    <SkAvatar :char="name.charAt(0)" size="lg" />
    <div class="sk-member-name">{{ name }}</div>
    <div class="sk-member-role">{{ role }}</div>
    <div v-if="meta" class="sk-member-meta">{{ meta }}</div>
  </div>
</template>

<script setup lang="ts">
/** 成员卡（3.html member-card）：头像 + 姓名 + 角色 + 底部统计，highlight 黄底。 */
defineProps<{ name: string; role?: string; meta?: string; highlight?: boolean }>()
</script>

<style>
.sk-member-card {
  width: 180px; padding: 12px;
  border: 1.5px solid var(--sk-line-faint); border-radius: var(--sk-radius);
  background: var(--sk-surface); box-shadow: var(--sk-shadow-pop);
  display: flex; flex-direction: column; gap: 2px;
}
.sk-member-card.is-highlight { background: var(--sk-accent-faint); border-color: var(--sk-line-input); }
.sk-member-name { font-size: var(--sk-font-size-base); font-weight: 700; margin-top: 6px; }
.sk-member-role { font-size: var(--sk-font-size-xs); color: var(--sk-text-faint); }
.sk-member-meta {
  font-size: var(--sk-font-size-xs); color: var(--sk-text-faint); margin-top: 6px;
  border-top: 1px dashed var(--sk-line-cell); padding-top: 5px;
}
</style>

<template>
  <div class="sk-chart-line">
    <div v-if="title" class="sk-chart-line-head">
      <span class="sk-chart-line-title">{{ title }}</span>
      <span v-if="tag" class="sk-chart-line-tag">{{ tag }}</span>
    </div>
    <div class="sk-chart-line-legend">
      <span v-for="(s, i) in series" :key="i" class="sk-chart-line-legend-item">
        <i :style="{ background: colorOf(i) }"></i>{{ s.name }}
      </span>
    </div>
    <div class="sk-chart-line-stage" @mouseleave="hover = -1">
      <svg
        :viewBox="`0 0 ${W} ${H}`"
        class="sk-chart-line-svg"
        :style="{ height: height + 'px' }"
        preserveAspectRatio="none"
        role="img"
        @mousemove="onMove"
      >
        <!-- 横向网格线 -->
        <line v-for="g in gridYs" :key="g" x1="0" :x2="W" :y1="g" :y2="g" class="sk-chart-line-grid" />
        <!-- hover 参考线 -->
        <line v-if="hover >= 0" :x1="hoverX" :x2="hoverX" y1="0" :y2="H" class="sk-chart-line-guide" />
        <!-- 面积 + 折线 -->
        <g v-for="(s, i) in series" :key="'s' + i">
          <path v-if="area" :d="areaPath(s.data)" :fill="colorOf(i)" class="sk-chart-line-area" />
          <path :d="linePath(s.data)" fill="none" :stroke="colorOf(i)" class="sk-chart-line-line" />
          <circle v-for="(p, j) in points(s.data)" :key="j" :cx="p.x" :cy="p.y" r="3" :fill="colorOf(i)" class="sk-chart-line-dot" :class="{ 'is-hot': j === hover }" />
        </g>
      </svg>
      <!-- hover 数值气泡 -->
      <div v-if="hover >= 0" class="sk-chart-line-tip" :style="{ left: tipX }">
        <div v-if="labels[hover]" class="sk-chart-line-tip-label">{{ labels[hover] }}</div>
        <div v-for="(s, i) in series" :key="i" class="sk-chart-line-tip-row">
          <i :style="{ background: colorOf(i) }"></i>{{ s.name }}<b>{{ s.data[hover] }}</b>
        </div>
      </div>
    </div>
    <div v-if="labels.length" class="sk-chart-line-labels">
      <span v-for="(l, i) in labels" :key="i">{{ l }}</span>
    </div>
  </div>
</template>

<script setup lang="ts">
/**
 * 折线/面积图（5/6/7/8.html 收入支出、营收趋势类图表）：
 * 多系列 SVG 折线，area 开启面积填充；hover 显示参考线 + 各系列数值气泡。
 * 颜色默认取主题图表色板 --sk-chart-1..5。
 */
import { computed, ref } from 'vue'

const props = withDefaults(
  defineProps<{
    series: { name: string; data: number[]; color?: string }[]
    labels?: string[]
    title?: string
    tag?: string
    height?: number
    area?: boolean
  }>(),
  { labels: () => [], height: 150, area: true },
)

const W = 600
const H = 170
const PAD = 6

const hover = ref(-1)

const n = computed(() => Math.max(...props.series.map(s => s.data.length), 1))
const max = computed(() => Math.max(...props.series.flatMap(s => s.data), 1))

const gridYs = computed(() => [H * 0.25, H * 0.5, H * 0.75])

function xAt(j: number) {
  return n.value <= 1 ? W / 2 : PAD + (j * (W - PAD * 2)) / (n.value - 1)
}
function yAt(v: number) {
  return H - PAD - (v / max.value) * (H - PAD * 2)
}
function points(data: number[]) {
  return data.map((v, j) => ({ x: xAt(j), y: yAt(v) }))
}
function linePath(data: number[]) {
  return points(data).map((p, j) => `${j === 0 ? 'M' : 'L'}${p.x.toFixed(1)},${p.y.toFixed(1)}`).join(' ')
}
function areaPath(data: number[]) {
  const pts = points(data)
  if (!pts.length) return ''
  const d = linePath(data)
  return `${d} L${pts[pts.length - 1].x.toFixed(1)},${H} L${pts[0].x.toFixed(1)},${H} Z`
}
function colorOf(i: number) {
  return props.series[i]?.color || `var(--sk-chart-${(i % 5) + 1})`
}

function onMove(e: MouseEvent) {
  const stage = (e.currentTarget as SVGElement).parentElement
  if (!stage) return
  const rect = stage.getBoundingClientRect()
  const ratio = (e.clientX - rect.left) / rect.width
  hover.value = Math.max(0, Math.min(n.value - 1, Math.round(ratio * (n.value - 1))))
}

const hoverX = computed(() => (hover.value >= 0 ? xAt(hover.value).toFixed(1) : 0))
const tipX = computed(() => {
  if (hover.value < 0) return '0'
  const half = n.value - 1
  const ratio = half > 0 ? hover.value / half : 0.5
  // 边缘翻转，避免气泡溢出
  const left = ratio > 0.72
  return left ? `calc(${(ratio * 100).toFixed(1)}% - 158px)` : `calc(${(ratio * 100).toFixed(1)}% + 10px)`
})
</script>

<style>
.sk-chart-line { width: 100%; }
.sk-chart-line-head { display: flex; align-items: center; gap: 6px; margin-bottom: 6px; }
.sk-chart-line-title { font-size: var(--sk-font-size-md); font-weight: 700; }
.sk-chart-line-tag {
  font-size: var(--sk-font-size-xs); color: var(--sk-text-faint); font-weight: 400;
  border: 1px solid var(--sk-line-faint); padding: 1px 5px; border-radius: var(--sk-radius);
}
.sk-chart-line-legend { display: flex; gap: 12px; margin-bottom: 6px; flex-wrap: wrap; }
.sk-chart-line-legend-item {
  display: inline-flex; align-items: center; gap: 5px;
  font-size: var(--sk-font-size-xs); color: var(--sk-text-muted);
}
.sk-chart-line-legend-item i { width: 8px; height: 8px; border-radius: 2px; display: inline-block; }
.sk-chart-line-stage { position: relative; }
.sk-chart-line-svg { width: 100%; display: block; cursor: crosshair; }
.sk-chart-line-grid { stroke: var(--sk-line-cell); stroke-width: 1; }
.sk-chart-line-guide { stroke: var(--sk-text-faint); stroke-width: 1; stroke-dasharray: 3 3; }
.sk-chart-line-area { opacity: 0.14; }
.sk-chart-line-line { stroke-width: 2; stroke-linejoin: round; stroke-linecap: round; }
.sk-chart-line-dot { stroke: var(--sk-surface); stroke-width: 1.5; transition: r 0.1s; }
.sk-chart-line-dot.is-hot { r: 4.5; }
.sk-chart-line-tip {
  position: absolute; top: 6px; pointer-events: none; min-width: 118px;
  background: var(--sk-surface); border: var(--sk-border-thin);
  border-radius: var(--sk-radius); box-shadow: var(--sk-shadow-pop);
  padding: 6px 9px; font-size: var(--sk-font-size-xs); color: var(--sk-text-muted);
}
.sk-chart-line-tip-label { font-weight: 700; color: var(--sk-text); margin-bottom: 3px; }
.sk-chart-line-tip-row { display: flex; align-items: center; gap: 5px; line-height: 1.7; }
.sk-chart-line-tip-row i { width: 7px; height: 7px; border-radius: 2px; flex-shrink: 0; }
.sk-chart-line-tip-row b { margin-left: auto; color: var(--sk-text); font-variant-numeric: tabular-nums; padding-left: 10px; }
.sk-chart-line-labels {
  display: flex; justify-content: space-between; margin-top: 4px;
  font-size: var(--sk-font-size-xs); color: var(--sk-text-faint);
}
</style>

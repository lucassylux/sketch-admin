<template>
  <div class="sk-swatch" :style="{ width: width ? width + 'px' : undefined }">
    <div class="sk-swatch-chip" :style="{ background: color, height: chipHeight + 'px' }">
      <span v-if="code" class="sk-swatch-code">{{ code }}</span>
    </div>
    <div v-if="name || note" class="sk-swatch-meta">
      <span v-if="name" class="sk-swatch-name">{{ name }}</span>
      <span v-if="note" class="sk-swatch-note">{{ note }}</span>
    </div>
  </div>
</template>

<script setup lang="ts">
/**
 * 色样卡（6.html Materials 材质库：木色/金属/石材色板）：
 * 色块 + 编号角标 + 名称/备注；点击通过原生事件向上冒泡，可包在卡片里用。
 */
withDefaults(
  defineProps<{
    color: string
    name?: string
    code?: string
    note?: string
    width?: number
    chipHeight?: number
  }>(),
  { chipHeight: 56 },
)
</script>

<style>
.sk-swatch { display: flex; flex-direction: column; gap: 6px; }
.sk-swatch-chip {
  position: relative; border-radius: var(--sk-radius);
  border: 1px solid var(--sk-line-faint); overflow: hidden;
}
.sk-swatch-code {
  position: absolute; right: 6px; bottom: 4px;
  font-size: var(--sk-font-size-xs); color: rgba(255, 255, 255, 0.92);
  text-shadow: 0 1px 2px rgba(0, 0, 0, 0.5);
}
.sk-swatch-meta { display: flex; flex-direction: column; gap: 1px; }
.sk-swatch-name { font-size: var(--sk-font-size-sm); font-weight: 600; }
.sk-swatch-note { font-size: var(--sk-font-size-xs); color: var(--sk-text-faint); }
</style>

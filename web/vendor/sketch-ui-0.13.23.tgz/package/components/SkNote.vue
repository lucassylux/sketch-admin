<template>
  <aside class="sk-note">
    <div v-if="title" class="sk-note-title">{{ title }}</div>
    <div class="sk-note-body"><slot /></div>
  </aside>
</template>

<script setup lang="ts">
/** 便签：黄底 + 硬投影（对应线框稿 sticky-note），用于提示/备忘。 */
defineProps<{ title?: string }>()
</script>

<style>
.sk-note {
  position: relative; background: var(--sk-accent);
  border: 1.5px solid var(--sk-accent-line); border-radius: var(--sk-radius-card, var(--sk-radius));
  padding: 10px 14px; font-size: var(--sk-font-size-sm); line-height: 1.7;
  max-width: 320px; box-shadow: var(--sk-shadow-pop);
}
.sk-note-title {
  font-weight: 700; font-size: var(--sk-font-size-xs);
  text-transform: uppercase; letter-spacing: 0.08em; margin-bottom: 5px; color: var(--sk-accent-line);
}
.sk-note-body { color: var(--sk-text); }
</style>

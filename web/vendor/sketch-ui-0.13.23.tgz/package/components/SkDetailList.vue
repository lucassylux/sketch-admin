<template>
  <dl class="sk-detail-list">
    <div v-for="(item, i) in items" :key="i" class="sk-detail-row">
      <dt class="sk-detail-key">{{ item.label }}</dt>
      <dd class="sk-detail-val">
        <slot name="value" :item="item" :index="i">{{ item.value }}</slot>
      </dd>
    </div>
  </dl>
</template>

<script setup lang="ts">
/**
 * 键值明细列表（对应线框稿 detail-row/detail-key/detail-val）：
 * 左弱标签右粗值；value 插槽可放链接/胶囊等富内容。
 */
export interface SkDetailItem {
  label: string
  value?: string | number
}

defineProps<{ items: SkDetailItem[] }>()
</script>

<style>
.sk-detail-list { display: flex; flex-direction: column; gap: 6px; }
.sk-detail-row {
  display: flex; justify-content: space-between; align-items: flex-start; gap: 8px;
}
.sk-detail-key { font-size: var(--sk-font-size-sm); color: var(--sk-text-muted); white-space: nowrap; flex-shrink: 0; }
.sk-detail-val { font-size: var(--sk-font-size-sm); font-weight: 600; text-align: right; word-break: break-all; }
</style>

<template>
  <div v-if="$slots.default" class="sk-divider is-text"><span class="sk-divider-label"><slot /></span></div>
  <hr v-else class="sk-divider" />
</template>

<script setup lang="ts">
/** 虚线分隔线；传入默认插槽时渲染为分组标题（文字 + 右侧延伸线）。 */
</script>

<style>
.sk-divider { border: none; border-top: var(--sk-border-divider); margin: 14px 0; }
/* 带文字：标题嵌线首（此前组件不接受插槽，调用方写的分组标题被静默丢弃） */
.sk-divider.is-text { border-top: none; display: flex; align-items: center; gap: 10px; margin: 14px 0; }
.sk-divider.is-text::after { content: ''; flex: 1; border-top: var(--sk-border-divider); }
.sk-divider-label { font-size: var(--sk-font-size-xs); font-weight: 600; color: var(--sk-text-muted); letter-spacing: 0.05em; }
</style>

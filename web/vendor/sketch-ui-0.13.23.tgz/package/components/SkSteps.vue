<template>
  <div class="sk-steps">
    <template v-for="(s, i) in steps" :key="i">
      <div class="sk-steps-node" :class="`sk-steps-node-${s.state || 'pending'}`">
        <div class="sk-steps-title">{{ s.title }}</div>
        <div v-if="s.sub" class="sk-steps-sub">{{ s.sub }}</div>
      </div>
      <div v-if="i < steps.length - 1" class="sk-steps-arrow" :class="{ 'is-done': s.state === 'done' }"></div>
    </template>
  </div>
</template>

<script setup lang="ts">
/**
 * 步骤条（对应线框稿 flow-node/flow-arrow）：实线节点 + 箭头连接。
 * state：done 绿 / current 黄加粗 / pending 灰。
 */
export interface SkStepItem { state?: 'done' | 'current' | 'pending'; title: string; sub?: string }

defineProps<{ steps: SkStepItem[] }>()
</script>

<style>
.sk-steps { display: flex; align-items: center; flex-wrap: wrap; gap: 0; }
.sk-steps-node {
  border: var(--sk-border); border-radius: var(--sk-radius);
  padding: 6px 14px; background: var(--sk-surface); text-align: center; white-space: nowrap;
  font-size: var(--sk-font-size-sm);
}
.sk-steps-title { font-weight: 600; }
.sk-steps-sub { font-size: var(--sk-font-size-xs); color: var(--sk-text-faint); margin-top: 2px; }
.sk-steps-node-done { background: var(--sk-success-soft2); border-color: var(--sk-success); }
.sk-steps-node-current { background: var(--sk-warning-soft2); border-color: var(--sk-warning); font-weight: 700; }
.sk-steps-node-pending { background: var(--sk-muted-soft2); color: var(--sk-text-faint); }
.sk-steps-arrow { width: 24px; height: 2px; background: var(--sk-ink); position: relative; flex-shrink: 0; }
.sk-steps-arrow::after {
  content: ''; position: absolute; right: -1px; top: -4px;
  border: 5px solid transparent; border-left-color: var(--sk-ink);
}
.sk-steps-arrow.is-done { background: var(--sk-success); }
.sk-steps-arrow.is-done::after { border-left-color: var(--sk-success); }
</style>

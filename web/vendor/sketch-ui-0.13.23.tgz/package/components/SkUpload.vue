<template>
  <div
    class="sk-upload"
    :class="{ 'is-over': dragOver }"
    @dragover.prevent="dragOver = true"
    @dragleave.prevent="dragOver = false"
    @drop.prevent="onDrop"
    @click="inputRef?.click()"
  >
    <div class="sk-upload-glyph" aria-hidden="true">⬆</div>
    <div class="sk-upload-text">{{ text }}</div>
    <div v-if="hint" class="sk-upload-hint">{{ hint }}</div>
    <div v-if="$slots.default" class="sk-upload-ops" @click.stop><slot /></div>
    <input ref="inputRef" type="file" multiple hidden :accept="accept" @change="onChange" />
  </div>
</template>

<script setup lang="ts">
/**
 * 上传区（对应线框稿 upload-zone）：整区可点/可拖拽，文件经 files 事件交业务；
 * 附带操作按钮插槽（本地上传/云端导入等，点击不触发选框）。
 */
import { ref } from 'vue'

withDefaults(
  defineProps<{
    text?: string
    hint?: string
    accept?: string
  }>(),
  { text: '拖拽文件到此处，或点击选择上传' },
)
const emit = defineEmits<{ files: [list: File[]] }>()

const dragOver = ref(false)
const inputRef = ref<HTMLInputElement>()

function emitFiles(list: File[]) {
  if (list.length) emit('files', list)
}
function onDrop(e: DragEvent) {
  dragOver.value = false
  emitFiles(Array.from(e.dataTransfer?.files ?? []))
}
function onChange(e: Event) {
  const input = e.target as HTMLInputElement
  emitFiles(Array.from(input.files ?? []))
  input.value = ''
}
</script>

<style>
.sk-upload {
  border: 2px dashed var(--sk-line-input); border-radius: var(--sk-radius);
  background: var(--sk-paper); padding: 28px 20px; text-align: center;
  cursor: pointer; transition: border-color 0.12s, background 0.12s;
}
.sk-upload.is-over { border-color: var(--sk-accent-line); background: var(--sk-accent-faint); }
.sk-upload-glyph { font-size: 28px; opacity: 0.4; margin-bottom: 8px; }
.sk-upload-text { font-size: var(--sk-font-size-sm); color: var(--sk-text-muted); }
.sk-upload-hint { font-size: var(--sk-font-size-xs); color: var(--sk-text-faint); margin-top: 4px; }
.sk-upload-ops { margin-top: 12px; display: flex; gap: 10px; justify-content: center; }
</style>

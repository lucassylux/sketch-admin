<template>
  <span class="sk-avatar" :class="`sk-avatar-${size}`" aria-hidden="true">{{ char }}</span>
</template>

<script setup lang="ts">
/** 头像：方形墨框 + 等宽粗体首字（线框稿 nav-checkbox / chrome-user 风）。 */
withDefaults(defineProps<{ char: string; size?: 'sm' | 'md' | 'lg' }>(), { size: 'md' })
</script>

<style>
.sk-avatar {
  display: inline-flex; align-items: center; justify-content: center; flex-shrink: 0;
  border: var(--sk-border-thin); border-radius: var(--sk-radius);
  background: var(--sk-surface-dim); color: var(--sk-text);
  font-weight: 700; text-transform: uppercase;
}
.sk-avatar-sm { width: 20px; height: 20px; font-size: var(--sk-font-size-xs); }
.sk-avatar-md { width: 26px; height: 26px; font-size: var(--sk-font-size-sm); }
.sk-avatar-lg { width: 34px; height: 34px; font-size: var(--sk-font-size-md); }
</style>

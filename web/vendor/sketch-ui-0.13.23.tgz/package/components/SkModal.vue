<template>
  <Teleport to="body">
    <Transition name="sk-modal">
      <div v-if="open" class="sk-modal-root" :style="{ zIndex: layer || undefined }" @click.self="onMask">
        <div class="sk-modal" :style="{ width: typeof width === 'number' ? width + 'px' : width }" role="dialog" aria-modal="true">
          <div class="sk-modal-head">
            <div class="sk-modal-title"><slot name="title">{{ title }}</slot></div>
            <button type="button" class="sk-modal-close" title="关闭" @click="requestClose">
              <SkIconClose />
            </button>
          </div>
          <div class="sk-modal-body"><slot /></div>
          <!-- 页脚：#footer 插槽优先；未传且 footer 未禁用时渲染默认 取消/确定（@ok 写法依赖内置按钮） -->
          <div v-if="$slots.footer" class="sk-modal-foot"><slot name="footer" /></div>
          <div v-else-if="footer !== null" class="sk-modal-foot">
            <SkButton @click="requestClose">{{ cancelText }}</SkButton>
            <SkButton variant="primary" :loading="confirmLoading || okLoading" @click="emit('ok')">{{ okText }}</SkButton>
          </div>
        </div>
      </div>
    </Transition>
  </Teleport>
</template>

<script lang="ts">
// 模块级状态（普通 script 块每个模块只执行一次；script setup 顶层是每实例执行，放那里会每弹窗各一份）：
// 弹窗层级种子——每次打开取递增 z-index（基座 2000），后开者恒在已开者之上，
// 弹窗中再开弹窗（如表单里选负责人）不会按 DOM 挂载顺序错压在下层
let layerSeed = 0
const BASE_LAYER = 2000
// body 滚动锁引用计数：多层弹窗叠开时，关闭其一不能提前解锁背景滚动
let openCount = 0
</script>

<script setup lang="ts">
/**
 * 对话框（便签放大版）：墨框 + 硬投影 + 遮罩；Esc/点遮罩可关（可关开关）。
 * 页脚：#footer 插槽优先；未传插槽且 footer !== null 时渲染默认 取消/确定 按钮
 * （确定触发 ok 事件，confirm-loading/ok-loading 置加载态）；:footer="null" 完全去页脚。
 */
import { onBeforeUnmount, ref, watch } from 'vue'
import { SkIconClose } from '../icons'
import SkButton from './SkButton.vue'

const props = withDefaults(
  defineProps<{
    open: boolean
    title?: string
    width?: number | string
    maskClosable?: boolean
    /** null = 不渲染页脚（缺省渲染内置 取消/确定） */
    footer?: { [k: string]: unknown } | null
    okText?: string
    cancelText?: string
    /** 确定按钮加载态（confirm-loading 为同义别名） */
    okLoading?: boolean
    confirmLoading?: boolean
  }>(),
  { width: 480, maskClosable: true, footer: undefined, okText: '确定', cancelText: '取消', okLoading: false, confirmLoading: false },
)
const emit = defineEmits<{ 'update:open': [v: boolean]; close: []; ok: [] }>()

function requestClose() {
  emit('update:open', false)
  emit('close')
}
function onMask() {
  if (props.maskClosable) requestClose()
}
function onKey(e: KeyboardEvent) {
  if (e.key === 'Escape' && props.open) requestClose()
}
const layer = ref(0)
const holdingLock = ref(false)
watch(
  () => props.open,
  v => {
    document.removeEventListener('keydown', onKey)
    if (v) {
      layer.value = BASE_LAYER + layerSeed++
      document.addEventListener('keydown', onKey)
      if (++openCount === 1) document.body.style.overflow = 'hidden'
      holdingLock.value = true
    } else {
      releaseLock()
    }
  },
)
function releaseLock() {
  if (!holdingLock.value) return
  holdingLock.value = false
  if (--openCount === 0) document.body.style.overflow = ''
}
onBeforeUnmount(() => {
  document.removeEventListener('keydown', onKey)
  releaseLock()
})
</script>

<style>
.sk-modal-root {
  position: fixed; inset: 0; z-index: 2000;
  display: flex; align-items: flex-start; justify-content: center;
  padding: 8vh 16px 16px; overflow: auto;
  background: var(--sk-mask);
}
.sk-modal {
  background: var(--sk-surface); border: var(--sk-border); border-radius: var(--sk-radius-card, var(--sk-radius));
  box-shadow: var(--sk-shadow-overlay); max-width: 100%;
}
.sk-modal-head {
  display: flex; align-items: center; justify-content: space-between; gap: 10px;
  padding: 10px 14px; border-bottom: var(--sk-border-divider);
}
.sk-modal-title { font-size: var(--sk-font-size-md); font-weight: 700; letter-spacing: 0.03em; }
.sk-modal-close {
  width: 24px; height: 24px; display: inline-flex; align-items: center; justify-content: center;
  border: 1.5px solid transparent; background: transparent; color: var(--sk-text-muted);
  cursor: pointer; border-radius: var(--sk-radius-card, var(--sk-radius)); font-size: 14px;
}
.sk-modal-close:hover { border-color: var(--sk-ink); color: var(--sk-text); background: var(--sk-hover); }
.sk-modal-body { padding: 16px 18px; }
.sk-modal-foot {
  display: flex; justify-content: flex-end; gap: 8px;
  padding: 12px 18px; border-top: var(--sk-border-divider);
}

.sk-modal-enter-active, .sk-modal-leave-active { transition: opacity 0.15s; }
.sk-modal-enter-active .sk-modal, .sk-modal-leave-active .sk-modal { transition: transform 0.15s, box-shadow 0.15s; }
.sk-modal-enter-from, .sk-modal-leave-to { opacity: 0; }
.sk-modal-enter-from .sk-modal, .sk-modal-leave-to .sk-modal { transform: translate(-6px, -6px); }
</style>

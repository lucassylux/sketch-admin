<template>
  <!-- 无 href 也按可点文字渲染（SPA 页内动作）；禁用态去指针并降透明度 -->
  <a
    class="sk-link"
    :class="{ 'is-danger': danger, 'is-disabled': disabled }"
    :href="href || undefined"
    :target="href ? (target || '_self') : undefined"
    :rel="href ? 'noopener noreferrer' : undefined"
    :aria-disabled="disabled || undefined"
    @click="onClick"
  >
    <slot />
  </a>
</template>

<script setup lang="ts">
/**
 * 文字链接（行内动作/外部跳转二合一）：
 * 与裸 &lt;a&gt; 的差别是**常显下划线**——部分主题的 --sk-link 与正文同色（marker 的 #1a1a1a 等），
 * 裸链接只剩颜色差无辨识度；本组件的下划线在所有主题下都是稳定可感知的点击示意。
 * 页内动作不传 href（渲染可点文字），外链传 href + 可选 target。
 */
withDefaults(
  defineProps<{
    /** 外部地址：传入则按真实链接渲染（新窗口传 '_blank'）；页内动作不传 */
    href?: string
    target?: string
    disabled?: boolean
    danger?: boolean
  }>(),
  { disabled: false, danger: false },
)
const emit = defineEmits<{ click: [e: MouseEvent] }>()
const onClick = (e: MouseEvent) => {
  // 无 href 时阻止默认行为（裸 a 点击会跳转/改 hash）；禁用态由 pointer-events 拦截
  if (!(e.currentTarget instanceof HTMLAnchorElement) || !e.currentTarget.getAttribute('href')) {
    e.preventDefault()
  }
}
</script>

<style>
/* 常显点状下划线（hover 变实线）——组件的核心承诺：不依赖主题配色也有点击示意 */
.sk-link {
  color: var(--sk-link);
  cursor: pointer;
  text-decoration: underline dotted;
  text-underline-offset: 3px;
}
.sk-link:hover {
  text-decoration-style: solid;
}
.sk-link.is-danger {
  color: var(--sk-danger);
}
.sk-link.is-disabled {
  pointer-events: none;
  opacity: 0.45;
}
</style>

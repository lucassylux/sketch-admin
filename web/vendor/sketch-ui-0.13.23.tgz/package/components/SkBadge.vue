<template>
  <span class="sk-badge" :class="`sk-badge-${tone}`"><slot /></span>
</template>

<script setup lang="ts">
/** 独立角标/小徽章（对应线框稿 kpi-badge + badge-* 五色）。 */
withDefaults(
  defineProps<{ tone?: 'success' | 'warning' | 'danger' | 'info' | 'muted' }>(),
  { tone: 'muted' },
)
</script>

<style>
.sk-badge {
  display: inline-block; font-size: var(--sk-font-size-xs);
  padding: 1px 5px; border: 1px solid currentColor; border-radius: var(--sk-radius-pill);
  white-space: nowrap; line-height: 1.5; vertical-align: middle;
}
.sk-badge-success { color: var(--sk-success); background: var(--sk-success-soft); }
.sk-badge-warning { color: var(--sk-warning); background: var(--sk-warning-soft2); }
.sk-badge-danger { color: var(--sk-danger); background: var(--sk-danger-soft2); }
.sk-badge-info { color: var(--sk-info); background: var(--sk-info-soft); }
.sk-badge-muted { color: var(--sk-muted); background: var(--sk-muted-soft); }
</style>

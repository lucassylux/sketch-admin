<template>
  <div class="sk-spin" :class="{ 'sk-spin-block': block }" role="status">
    <span class="sk-spin-ring" :style="size ? { width: size + 'px', height: size + 'px' } : undefined"></span>
    <span v-if="tip" class="sk-spin-tip">{{ tip }}</span>
  </div>
</template>

<script setup lang="ts">
/**
 * 加载指示：虚线圆环旋转（贴合线框风）。block=true 时块级居中。
 */
withDefaults(defineProps<{ tip?: string; size?: number; block?: boolean }>(), { block: false })
</script>

<style>
.sk-spin { display: inline-flex; align-items: center; gap: 10px; color: var(--sk-text-muted); }
.sk-spin-block { display: flex; justify-content: center; padding: 40px 0; width: 100%; flex-direction: column; gap: 12px; }
.sk-spin-ring {
  width: 18px; height: 18px; border-radius: 50%; flex-shrink: 0;
  border: 2px dashed currentColor; animation: sk-spin-ring 0.9s linear infinite;
}
@keyframes sk-spin-ring { to { transform: rotate(360deg); } }
.sk-spin-tip { font-size: var(--sk-font-size-sm); letter-spacing: 0.04em; }
</style>

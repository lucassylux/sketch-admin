<template>
  <div class="sk-chat-msg" :class="{ 'is-self': self }">
    <div class="sk-chat-meta">
      <strong>{{ sender }}</strong>
      <span v-if="time">{{ time }}</span>
    </div>
    <div class="sk-chat-bubble"><slot /></div>
  </div>
</template>

<script setup lang="ts">
/** 消息气泡（4.html msg-bubble/chat-msg）：self 为本人（黄底右对齐）。 */
defineProps<{ sender: string; time?: string; self?: boolean }>()
</script>

<style>
.sk-chat-msg { display: flex; flex-direction: column; align-items: flex-start; gap: 2px; max-width: 80%; }
.sk-chat-msg.is-self { align-self: flex-end; align-items: flex-end; }
.sk-chat-meta {
  font-size: var(--sk-font-size-xs); color: var(--sk-text-faint); display: flex; gap: 6px; align-items: baseline;
}
.sk-chat-meta strong { color: var(--sk-text-muted); font-size: var(--sk-font-size-xs); }
.sk-chat-bubble {
  padding: 6px 10px; border-radius: var(--sk-radius);
  border: 1.5px solid var(--sk-line-faint); background: var(--sk-surface);
  font-size: var(--sk-font-size-base); line-height: 1.6; color: var(--sk-text);
}
.is-self .sk-chat-bubble { background: var(--sk-accent); border-color: var(--sk-accent-line); }
</style>

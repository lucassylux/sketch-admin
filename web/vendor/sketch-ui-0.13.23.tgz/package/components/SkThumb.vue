<template>
  <div class="sk-thumb" :class="{ 'is-empty': empty }">
    <div class="sk-thumb-body"><slot /></div>
    <div v-if="label" class="sk-thumb-label">{{ label }}</div>
    <span v-if="checked" class="sk-thumb-check" aria-hidden="true">✓</span>
  </div>
</template>

<script setup lang="ts">
/**
 * 缩略图格（对应线框稿 evidence-thumb）：正方形格 + 名称 + 右上角勾选标；
 * empty 为虚线空位（默认插槽内容放图标/加号）。
 * 外层网格用配套工具类 .sk-thumb-grid。
 */
withDefaults(
  defineProps<{
    label?: string
    checked?: boolean
    empty?: boolean
  }>(),
  {},
)
</script>

<style>
.sk-thumb-grid {
  display: grid; grid-template-columns: repeat(auto-fill, minmax(96px, 1fr));
  gap: 10px;
}
.sk-thumb {
  position: relative; aspect-ratio: 1;
  border: var(--sk-border); border-radius: var(--sk-radius-card, var(--sk-radius));
  background: var(--sk-surface-dim);
  display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 4px;
  padding: 6px;
}
.sk-thumb.is-empty { border-style: dashed; opacity: 0.5; background: transparent; }
.sk-thumb-body { font-size: 22px; opacity: 0.35; line-height: 1; }
.sk-thumb-label {
  font-size: var(--sk-font-size-xs); color: var(--sk-text-muted);
  text-align: center; max-width: 100%; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
}
.sk-thumb-check {
  position: absolute; top: 4px; right: 4px;
  width: 16px; height: 16px; border-radius: 50%;
  border: 1.5px solid var(--sk-success); background: var(--sk-success-soft2); color: var(--sk-success);
  display: flex; align-items: center; justify-content: center; font-size: 9px;
}
</style>

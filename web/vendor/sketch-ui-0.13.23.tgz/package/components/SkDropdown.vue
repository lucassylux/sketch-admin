<template>
  <span ref="triggerRef" class="sk-dropdown-trigger" @click.stop="toggle">
    <slot />
  </span>
  <Teleport to="body">
    <div v-if="open" ref="menuRef" class="sk-dropdown" :class="{ 'sk-dropdown-icons': hasIcons }" :style="pos" @click.stop>
      <template v-for="(item, i) in items" :key="item.key ?? i">
        <div v-if="item.divider" class="sk-dropdown-divider"></div>
        <button
          v-else
          type="button"
          class="sk-dropdown-item"
          :class="{ 'is-danger': item.danger, 'is-disabled': item.disabled }"
          :disabled="item.disabled"
          @click="onSelect(item)"
        >
          <span v-if="item.icon || hasIcons" class="sk-dropdown-icon">
            <component :is="item.icon" v-if="item.icon" />
          </span>
          {{ item.label }}
        </button>
      </template>
    </div>
  </Teleport>
</template>

<script setup lang="ts">
/**
 * 下拉菜单：触发器包裹 + Teleport 定位浮层（表格内也不被裁剪）；
 * 点击外部 / 滚动 / Esc 关闭。items 支持 divider / danger / disabled / icon。
 */
import { computed, nextTick, onBeforeUnmount, ref, type Component } from 'vue'

export interface SkDropdownItem {
  key?: string | number
  label?: string
  danger?: boolean
  disabled?: boolean
  divider?: boolean
  icon?: Component
}

const props = defineProps<{ items: SkDropdownItem[] }>()
const emit = defineEmits<{ select: [key: string | number] }>()

/** 菜单内任一项带图标时，所有项保留等宽图标列，保证文字对齐 */
const hasIcons = computed(() => props.items.some(i => i.icon))

const open = ref(false)
const triggerRef = ref<HTMLElement>()
const menuRef = ref<HTMLElement>()
const pos = ref<{ left: string; top: string }>({ left: '0px', top: '0px' })

async function toggle() {
  open.value ? close() : await show()
}
async function show() {
  open.value = true
  await nextTick()
  const rect = triggerRef.value?.getBoundingClientRect()
  const menuW = menuRef.value?.offsetWidth ?? 160
  const menuH = menuRef.value?.offsetHeight ?? 0
  if (!rect) return
  let left = rect.left
  if (left + menuW + 8 > window.innerWidth) left = Math.max(8, window.innerWidth - menuW - 8)
  let top = rect.bottom + 4
  // 下方空间不足时向上弹出（侧栏底部等场景）
  if (top + menuH > window.innerHeight - 8) top = Math.max(8, rect.top - menuH - 4)
  pos.value = { left: `${Math.round(left)}px`, top: `${Math.round(top)}px` }
  document.addEventListener('mousedown', onDocDown, true)
  window.addEventListener('scroll', close, true)
  window.addEventListener('resize', close)
}
function close() {
  if (!open.value) return
  open.value = false
  document.removeEventListener('mousedown', onDocDown, true)
  window.removeEventListener('scroll', close, true)
  window.removeEventListener('resize', close)
}
function onDocDown(e: MouseEvent) {
  const t = e.target as Node
  if (menuRef.value?.contains(t) || triggerRef.value?.contains(t)) return
  close()
}
function onSelect(item: SkDropdownItem) {
  if (item.disabled) return
  close()
  if (item.key != null) emit('select', item.key)
}
onBeforeUnmount(close)
</script>

<style>
.sk-dropdown-trigger { display: inline-flex; cursor: pointer; }
.sk-dropdown {
  position: fixed; z-index: 2100; min-width: 150px; padding: 4px;
  background: var(--sk-surface); border: var(--sk-border); border-radius: var(--sk-radius-card, var(--sk-radius));
  box-shadow: var(--sk-shadow-overlay);
}
.sk-dropdown-item {
  display: flex; align-items: center; gap: 8px; width: 100%; text-align: left;
  font-family: var(--sk-font); font-size: var(--sk-font-size-sm); color: var(--sk-text);
  padding: 6px 10px; border: none; background: transparent; cursor: pointer;
  border-radius: var(--sk-radius-card, var(--sk-radius)); white-space: nowrap;
}
.sk-dropdown-item:hover:not(.is-disabled) { background: var(--sk-accent-faint); }
.sk-dropdown-item.is-danger { color: var(--sk-danger); }
.sk-dropdown-item.is-danger:hover:not(.is-disabled) { background: var(--sk-danger-soft2); }
.sk-dropdown-item.is-disabled { color: var(--sk-text-faint); cursor: not-allowed; }
.sk-dropdown-icon { display: inline-flex; font-size: 14px; flex-shrink: 0; }
.sk-dropdown-icons .sk-dropdown-icon { width: 16px; justify-content: center; }
.sk-dropdown-divider { border-top: var(--sk-border-divider); margin: 4px 2px; }
</style>

<template>
  <div class="sk-filter-bar">
    <span v-if="label" class="sk-filter-label">{{ label }}</span>
    <slot />
  </div>
</template>

<script setup lang="ts">
/** 筛选条（对应线框稿 filter-bar）：虚线容器 + 前置标签，控件走默认插槽。 */
defineProps<{ label?: string }>()
</script>

<style>
.sk-filter-bar {
  display: flex; gap: 8px; align-items: center; flex-wrap: wrap;
  margin-bottom: 14px; padding: 10px 12px;
  border: 1.5px dashed var(--sk-line-faint); border-radius: var(--sk-radius-btn, var(--sk-radius));
  background: var(--sk-paper);
}
.sk-filter-label { font-size: var(--sk-font-size-xs); color: var(--sk-text-muted); }
</style>

<template>
  <div class="sk-pagination">
    <span class="sk-pagination-total">共 {{ total }} 个</span>
    <div class="sk-pagination-btns">
      <button type="button" class="sk-btn sk-btn-sm" :disabled="page <= 1" @click="go(page - 1)">«</button>
      <button
        v-for="(p, i) in pages"
        :key="i"
        type="button"
        class="sk-btn sk-btn-sm"
        :class="{ 'sk-btn-primary': p === page }"
        :disabled="p === '…'"
        @click="typeof p === 'number' && go(p)"
      >
        {{ p }}
      </button>
      <button type="button" class="sk-btn sk-btn-sm" :disabled="page >= pageCount" @click="go(page + 1)">»</button>
    </div>
    <select class="sk-select sk-select-sm sk-pagination-size" :value="pageSize" @change="onSize">
      <option v-for="s in sizes" :key="s" :value="s">{{ s }} / 页</option>
    </select>
  </div>
</template>

<script setup lang="ts">
/**
 * 分页（对应线框稿页脚分页）：« 1 … n » + 每页条数。
 */
import { computed } from 'vue'

const props = withDefaults(
  defineProps<{
    page: number
    pageSize: number
    total: number
    sizes?: number[]
  }>(),
  { sizes: () => [20, 50, 100] },
)
const emit = defineEmits<{ change: [v: { page: number; pageSize: number }] }>()

const pageCount = computed(() => Math.max(1, Math.ceil(props.total / props.pageSize)))

/** 页码窗口：1 … p-1 p p+1 … 末页 */
const pages = computed<(number | '…')[]>(() => {
  const last = pageCount.value
  const cur = Math.min(Math.max(1, props.page), last)
  if (last <= 7) return Array.from({ length: last }, (_, i) => i + 1)
  const set = new Set<number>([1, last, cur - 1, cur, cur + 1])
  const nums = [...set].filter(n => n >= 1 && n <= last).sort((a, b) => a - b)
  const out: (number | '…')[] = []
  let prev = 0
  for (const n of nums) {
    if (n - prev > 1) out.push('…')
    out.push(n)
    prev = n
  }
  return out
})

function go(p: number) {
  if (p < 1 || p > pageCount.value || p === props.page) return
  emit('change', { page: p, pageSize: props.pageSize })
}
function onSize(e: Event) {
  const size = Number((e.target as HTMLSelectElement).value)
  emit('change', { page: 1, pageSize: size })
}
</script>

<style>
.sk-pagination {
  display: flex; align-items: center; gap: 12px; flex-wrap: wrap;
  /* 水平内距与单元格 padding 同档（10px）：有盒主题（记号纸）下分页不贴盒的左右边框，
   * 无盒主题下"共 N 个"与表头首列文字对齐——间距归组件，主题无需各自补偿 */
  /* 底距 token 化（默认 0）：wrap 带不带盒是主题自由——无盒主题的底距由卡片 padding
   * 唯一提供（组件再加一段就叠加变空）；有盒主题在自己的 css 里设 --sk-table-page-gap
   * 声明盒内留白（记号纸 10px）——"间距在谁的盒子内就由谁负责" */
  margin-top: 12px; margin-bottom: var(--sk-table-page-gap, 0px); padding: 10px 10px 0; border-top: var(--sk-border-divider);
}
/* 通栏表格卡片（.sk-card-flush）内：表格贴边、分页脚退让出卡片边缘 */
.sk-card-flush .sk-pagination { margin-top: 0; margin-bottom: 0; padding: 5px; }
.sk-pagination-total { font-size: var(--sk-font-size-sm); color: var(--sk-text-faint); }
/* 页码钮靠右（与每页条数选择器连成一组），总数留左侧 */
.sk-pagination-btns { display: flex; gap: 4px; margin-left: auto; }
.sk-pagination-size { }
</style>

<template>
  <div class="sk-comment">
    <SkAvatar :char="author.charAt(0)" size="sm" />
    <div class="sk-comment-body">
      <div class="sk-comment-head">
        <span class="sk-comment-author">{{ author }}</span>
        <span v-if="time" class="sk-comment-time">{{ time }}</span>
      </div>
      <div class="sk-comment-text"><slot /></div>
    </div>
  </div>
</template>

<script setup lang="ts">
/** 评论条目（3.html drawer-comment / 4.html comment）。 */
defineProps<{ author: string; time?: string }>()
</script>

<style>
.sk-comment { display: flex; gap: 8px; align-items: flex-start; }
.sk-comment-body { flex: 1; min-width: 0; }
.sk-comment-head { display: flex; align-items: baseline; gap: 8px; }
.sk-comment-author { font-size: var(--sk-font-size-base); font-weight: 700; }
.sk-comment-time { font-size: var(--sk-font-size-xs); color: var(--sk-text-faint); }
.sk-comment-text { font-size: var(--sk-font-size-base); color: var(--sk-text-muted); margin-top: 2px; line-height: 1.6; }
</style>

<template>
  <div class="sk-page-header">
    <div class="sk-page-header-main">
      <slot name="title">
        <span class="sk-page-header-title">{{ title }}</span>
      </slot>
      <slot name="extra" />
    </div>
    <div class="sk-page-header-actions"><slot name="actions" /></div>
  </div>
</template>

<script setup lang="ts">
/**
 * 内容区标题栏（对应线框稿 content-titlebar）：标题 + 附加信息 + 右侧操作区，底虚线。
 */
defineProps<{ title?: string }>()
</script>

<style>
.sk-page-header {
  display: flex; align-items: center; justify-content: space-between; gap: 12px;
  margin-bottom: 14px; padding-bottom: 10px; border-bottom: var(--sk-border-divider);
}
.sk-page-header-main { display: flex; align-items: center; gap: 10px; min-width: 0; flex-wrap: wrap; }
.sk-page-header-title { font-size: var(--sk-font-size-lg); font-weight: 700; letter-spacing: 0.03em; }
.sk-page-header-actions { display: flex; gap: 8px; align-items: center; flex-shrink: 0; flex-wrap: wrap; }
</style>

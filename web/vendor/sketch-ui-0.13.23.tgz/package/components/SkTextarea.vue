<template>
  <textarea
    class="sk-textarea"
    :value="modelValue"
    :placeholder="placeholder"
    :rows="rows"
    :disabled="disabled"
    :readonly="readonly"
    v-bind="attrs"
    @input="$emit('update:modelValue', ($event.target as HTMLTextAreaElement).value)"
  ></textarea>
</template>

<script setup lang="ts">
/**
 * 多行文本域：结构层组件，尺寸/留白由使用处控制（rows 或 style）。
 */
import { useAttrs } from 'vue'

withDefaults(
  defineProps<{
    modelValue?: string
    placeholder?: string
    rows?: number
    disabled?: boolean
    readonly?: boolean
  }>(),
  { rows: 3 },
)
defineEmits<{ 'update:modelValue': [v: string] }>()
const attrs = useAttrs()
</script>

<style>
.sk-textarea {
  width: 100%; font-family: var(--sk-font); font-size: var(--sk-font-size-base); color: var(--sk-text);
  padding: 7px var(--sk-control-px); border: var(--sk-border-input); border-radius: var(--sk-radius-btn, var(--sk-radius));
  background: var(--sk-surface); resize: vertical; line-height: 1.6;
}
.sk-textarea::placeholder { color: var(--sk-text-faint); }
.sk-textarea:disabled { background: var(--sk-muted-soft2); color: var(--sk-text-faint); }
</style>

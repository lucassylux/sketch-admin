/**
 * 主题注册表与切换。
 * 主题 = 一份 token 赋值（themes/*.css，作用域 html[data-theme='xxx']）；
 * 组件层只消费 var(--sk-*)，新增主题只加 token 文件 + 这里注册一行，不改组件。
 * html[data-theme] 单一事实源；localStorage['docgoose_theme'] 持久化（兼容旧 light/dark 值）。
 */
import { ref } from 'vue'

export interface SkThemeDef {
  key: string
  label: string
  dark: boolean
}

export const SK_THEMES: SkThemeDef[] = [
  { key: 'sketch', label: '线框纸', dark: false },
  { key: 'marker', label: '记号纸', dark: false },
  { key: 'highlight', label: '荧光纸', dark: false },
  { key: 'bold', label: '粗线纸', dark: false },
  { key: 'night', label: '暗夜紫', dark: true },
  { key: 'atelier', label: '暖木坊', dark: false },
  { key: 'lumina', label: '鎏金夜', dark: true },
  { key: 'indigo', label: '靛蓝云', dark: false },
]

const THEME_KEY = 'docgoose_theme'

function normalizeSaved(v: string | null): string | null {
  if (v === 'light' || v === 'dark' || v === 'sketch-dark') return 'sketch'  // 兼容旧值（含已删除的夜间主题）
  return v && SK_THEMES.some(t => t.key === v) ? v : null
}

const DEFAULT_THEME_KEY = 'docgoose_theme_default'

function initial(): string {
  const saved = normalizeSaved(localStorage.getItem(THEME_KEY))
  if (saved) return saved
  // 用户从未手动改过：应用注册的默认主题 > 列表第一项
  const def = normalizeSaved(localStorage.getItem(DEFAULT_THEME_KEY))
  return def ?? SK_THEMES[0].key
}

const theme = ref<string>(initial())

function apply() {
  document.documentElement.dataset.theme = theme.value
}
apply()

/** 设置应用级默认主题：仅当用户从未手动切换过时生效（一旦手动切换，永远以用户值为准） */
export function setDefaultTheme(key: string) {
  if (!SK_THEMES.some(t => t.key === key)) return
  if (normalizeSaved(localStorage.getItem(THEME_KEY))) return  // 用户已改过
  localStorage.setItem(DEFAULT_THEME_KEY, key)
  theme.value = key
  apply()
}

export function useSkTheme() {
  const setTheme = (key: string) => {
    if (!SK_THEMES.some(t => t.key === key)) return
    theme.value = key
    localStorage.setItem(THEME_KEY, key)
    apply()
  }
  return { theme, setTheme }
}

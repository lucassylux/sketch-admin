/**
 * ECharts 封装（可选能力，不进全局注册）：
 *   import { SkEcharts } from '@xzsoft/sketch-ui/echarts'
 * 需要消费者自行安装 echarts（>=5）。
 */
export { default as SkEcharts } from './components/SkEcharts.vue'
